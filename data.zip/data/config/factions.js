export const FACTIONS = {
  CONSTRUCT: {
    id: "construct",
    name: "Constructos"
  },
  BRAZIL: {
    id: "brazil",
    name: "Brasileiro"
  },
  ALIEN: {
    id: "alien",
    name: "Alien"
  }
};

export const FACTION_RELATIONS = {
  construct: {
    construct: "neutral",
    brazil: "neutral",
    alien: "neutral"
  },
  brazil: {
    construct: "neutral",
    brazil: "friendly",
    alien: "hostile"
  },
  alien: {
    construct: "neutral",
    brazil: "hostile",
    alien: "friendly"
  }
};

export function getFactionRelation(a, b) {
  if (a === b) return 'friendly';
  const row = FACTION_RELATIONS[a];
  if (row && row[b]) return row[b];
  return 'hostile';
}

export const FACTION_ORDER = [
  "construct",
  "brazil",
  "alien"
];
