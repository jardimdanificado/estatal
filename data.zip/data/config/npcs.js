export default {
  VILLAGER: {
    id: 1,
    name: "Aldeao",
    texture: "npc",
    width: 0.8,
    height: 1.6,
    interactable: true,
    faction: "village",
    isHostile: false,
    maxHP: 100,
    dialogue: "Ola, viajante! Bem-vindo a vila!"
  },
  VILLAGER_TRADER: {
    id: 676,
    name: "Mercador",
    texture: "npc",
    width: 0.8,
    height: 1.6,
    interactable: true,
    faction: "village",
    isHostile: false,
    maxHP: 110,
    dialogue: "Caro, mas justo. O que deseja comprar?"
  },
  VILLAGER_ELDER: {
    id: 677,
    name: "Ancião",
    texture: "npc",
    width: 0.8,
    height: 1.6,
    interactable: true,
    faction: "village",
    isHostile: false,
    maxHP: 120,
    dialogue: "A sabedoria da vila previne muitos perigos."
  },
  GUARD: {
    id: 2,
    name: "Guarda",
    texture: "npc",
    width: 0.8,
    height: 1.6,
    interactable: true,
    faction: "guard",
    isHostile: false,
    maxHP: 150,
    dialogue: "Mantenha a paz por aqui!"
  },
  GUARD_SOLDIER: {
    id: 678,
    name: "Soldado",
    texture: "npc",
    width: 0.8,
    height: 1.6,
    interactable: true,
    faction: "guard",
    isHostile: false,
    maxHP: 160,
    dialogue: "Não passe sem autorização."
  },
  GUARD_RANGER: {
    id: 679,
    name: "Patrulheiro",
    texture: "npc",
    width: 0.8,
    height: 1.6,
    interactable: true,
    faction: "guard",
    isHostile: false,
    maxHP: 140,
    dialogue: "Olho vivo e flecha pronta."
  },
  OUTLAW: {
    id: 3,
    name: "Bandido",
    texture: "npc",
    width: 0.8,
    height: 1.6,
    interactable: true,
    faction: "outlaw",
    isHostile: true,
    maxHP: 80,
    dialogue: "Fique fora do meu caminho."
  },
  OUTLAW_RUFFIAN: {
    id: 680,
    name: "Brigão",
    texture: "npc",
    width: 0.8,
    height: 1.6,
    interactable: true,
    faction: "outlaw",
    isHostile: true,
    maxHP: 90,
    dialogue: "Tento grosso, meu amigo."
  },
  OUTLAW_SNIPER: {
    id: 681,
    name: "Atirador",
    texture: "npc",
    width: 0.8,
    height: 1.6,
    interactable: true,
    faction: "outlaw",
    isHostile: true,
    maxHP: 85,
    dialogue: "Nada de movimentos bruscos."
  },
  PROP_CHEST: {
    id: 4,
    name: "Chest",
    texture: "prop_chest",
    width: 0.9,
    height: 0.9,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 120,
    isControllable: false,
    itemDrops: {
      medkit: 1
    }
  },
  PROP_CHEST_2_CLOSED: {
    id: 5,
    name: "Chest 2 Closed",
    texture: "prop_chest_2_closed",
    width: 0.9,
    height: 0.9,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 120,
    isControllable: false,
    itemDrops: {
      medkit: 1
    }
  },
  PROP_LARGE_BOX: {
    id: 6,
    name: "Large Box",
    texture: "prop_large_box",
    width: 0.9,
    height: 0.9,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 80,
    isControllable: false,
    itemDrops: {
      medkit: 1
    }
  },
  PROP_MISC_BOX: {
    id: 7,
    name: "Misc Box",
    texture: "prop_misc_box",
    width: 0.9,
    height: 0.9,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 80,
    isControllable: false,
    itemDrops: {
      medkit: 1
    }
  },
  MONSTER_MONSTER_UNSEEN_HORROR: {
    id: 8,
    name: "Unseen Horror",
    texture: "monster_unseen_horror",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ANCIENT_ZYME: {
    id: 9,
    name: "Ancient Zyme",
    texture: "monster_ancient_zyme",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_APOCALYPSE_CRAB: {
    id: 10,
    name: "Apocalypse Crab",
    texture: "monster_apocalypse_crab",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_LURKING_HORROR: {
    id: 11,
    name: "Lurking Horror",
    texture: "monster_lurking_horror",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SILVER_STAR: {
    id: 12,
    name: "Silver Star",
    texture: "monster_silver_star",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_STARCURSED_MASS: {
    id: 13,
    name: "Starcursed Mass",
    texture: "monster_starcursed_mass",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_TENTACLED_STARSPAWN: {
    id: 14,
    name: "Tentacled Starspawn",
    texture: "monster_tentacled_starspawn",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_WORLDBINDER: {
    id: 15,
    name: "Worldbinder",
    texture: "monster_worldbinder",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_WRETCHED_STAR: {
    id: 16,
    name: "Wretched Star",
    texture: "monster_wretched_star",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ACID_BLOB: {
    id: 17,
    name: "Acid Blob",
    texture: "monster_acid_blob",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_AZURE_JELLY: {
    id: 18,
    name: "Azure Jelly",
    texture: "monster_azure_jelly",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEATH_OOZE: {
    id: 19,
    name: "Death Ooze",
    texture: "monster_death_ooze",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JELLY: {
    id: 338,
    name: "Jelly",
    texture: "monster_jelly",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OOZE: {
    id: 21,
    name: "Ooze",
    texture: "monster_ooze",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ADDER: {
    id: 22,
    name: "Adder",
    texture: "monster_adder",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ALLIGATOR: {
    id: 23,
    name: "Alligator",
    texture: "monster_alligator",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ALLIGATOR_BABY: {
    id: 24,
    name: "Alligator Baby",
    texture: "monster_alligator_baby",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ALLIGATOR_SNAPPING_TURTLE: {
    id: 25,
    name: "Alligator Snapping Turtle",
    texture: "monster_alligator_snapping_turtle",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ALLIGATOR_SNAPPING_TURTLE_SHELL: {
    id: 26,
    name: "Alligator Snapping Turtle Shell",
    texture: "monster_alligator_snapping_turtle_shell",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ANACONDA: {
    id: 27,
    name: "Anaconda",
    texture: "monster_anaconda",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BALL_PYTHON: {
    id: 28,
    name: "Ball Python",
    texture: "monster_ball_python",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BASILISK: {
    id: 29,
    name: "Basilisk",
    texture: "monster_basilisk",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BAT: {
    id: 30,
    name: "Bat",
    texture: "monster_bat",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BEAR: {
    id: 31,
    name: "Bear",
    texture: "monster_bear",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BIG_FISH: {
    id: 32,
    name: "Big Fish",
    texture: "monster_big_fish",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BLACK_BEAR: {
    id: 33,
    name: "Black Bear",
    texture: "monster_black_bear",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BLACK_MAMBA: {
    id: 34,
    name: "Black Mamba",
    texture: "monster_black_mamba",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BLACK_SHEEP: {
    id: 35,
    name: "Black Sheep",
    texture: "monster_black_sheep",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BLINK_FROG: {
    id: 36,
    name: "Blink Frog",
    texture: "monster_blink_frog",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BORING_BEETLE: {
    id: 37,
    name: "Boring Beetle",
    texture: "monster_boring_beetle",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BOULDER_BEETLE: {
    id: 38,
    name: "Boulder Beetle",
    texture: "monster_boulder_beetle",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BRAIN_WORM: {
    id: 39,
    name: "Brain Worm",
    texture: "monster_brain_worm",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUMBLEBEE: {
    id: 40,
    name: "Bumblebee",
    texture: "monster_bumblebee",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY_10: {
    id: 41,
    name: "Butterfly 10",
    texture: "monster_butterfly_10",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY_1: {
    id: 42,
    name: "Butterfly 1",
    texture: "monster_butterfly_1",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY_2: {
    id: 43,
    name: "Butterfly 2",
    texture: "monster_butterfly_2",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY_3: {
    id: 44,
    name: "Butterfly 3",
    texture: "monster_butterfly_3",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY_4: {
    id: 45,
    name: "Butterfly 4",
    texture: "monster_butterfly_4",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY_5: {
    id: 46,
    name: "Butterfly 5",
    texture: "monster_butterfly_5",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY_6: {
    id: 47,
    name: "Butterfly 6",
    texture: "monster_butterfly_6",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY_7: {
    id: 48,
    name: "Butterfly 7",
    texture: "monster_butterfly_7",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY_8: {
    id: 49,
    name: "Butterfly 8",
    texture: "monster_butterfly_8",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY_9: {
    id: 50,
    name: "Butterfly 9",
    texture: "monster_butterfly_9",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BUTTERFLY: {
    id: 51,
    name: "Butterfly",
    texture: "monster_butterfly",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CATOBLEPAS: {
    id: 52,
    name: "Catoblepas",
    texture: "monster_catoblepas",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CAUSTIC_SHRIKE: {
    id: 53,
    name: "Caustic Shrike",
    texture: "monster_caustic_shrike",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CROCODILE: {
    id: 54,
    name: "Crocodile",
    texture: "monster_crocodile",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEATH_YAK: {
    id: 55,
    name: "Death Yak",
    texture: "monster_death_yak",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ELEPHANT_DEMONIC: {
    id: 56,
    name: "Elephant Demonic",
    texture: "monster_elephant_demonic",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ELEPHANT_DIRE: {
    id: 57,
    name: "Elephant Dire",
    texture: "monster_elephant_dire",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ELEPHANT: {
    id: 58,
    name: "Elephant",
    texture: "monster_elephant",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ELEPHANT_SLUG: {
    id: 59,
    name: "Elephant Slug",
    texture: "monster_elephant_slug",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_EMPEROR_SCORPION: {
    id: 60,
    name: "Emperor Scorpion",
    texture: "monster_emperor_scorpion",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FIRE_BAT: {
    id: 61,
    name: "Fire Bat",
    texture: "monster_fire_bat",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FIRE_CRAB: {
    id: 62,
    name: "Fire Crab",
    texture: "monster_fire_crab",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GHOST_MOTH: {
    id: 63,
    name: "Ghost Moth",
    texture: "monster_ghost_moth",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_ANT: {
    id: 64,
    name: "Giant Ant",
    texture: "monster_giant_ant",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_BAT: {
    id: 65,
    name: "Giant Bat",
    texture: "monster_giant_bat",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_BEETLE: {
    id: 66,
    name: "Giant Beetle",
    texture: "monster_giant_beetle",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_BLOWFLY: {
    id: 67,
    name: "Giant Blowfly",
    texture: "monster_giant_blowfly",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_CENTIPEDE: {
    id: 68,
    name: "Giant Centipede",
    texture: "monster_giant_centipede",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_COCKROACH: {
    id: 69,
    name: "Giant Cockroach",
    texture: "monster_giant_cockroach",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_FIREFLY: {
    id: 70,
    name: "Giant Firefly",
    texture: "monster_giant_firefly",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_FROG: {
    id: 71,
    name: "Giant Frog",
    texture: "monster_giant_frog",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_GECKO: {
    id: 72,
    name: "Giant Gecko",
    texture: "monster_giant_gecko",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_GOLDFISH: {
    id: 73,
    name: "Giant Goldfish",
    texture: "monster_giant_goldfish",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_LEECH: {
    id: 74,
    name: "Giant Leech",
    texture: "monster_giant_leech",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_LIZARD: {
    id: 75,
    name: "Giant Lizard",
    texture: "monster_giant_lizard",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_MITE: {
    id: 76,
    name: "Giant Mite",
    texture: "monster_giant_mite",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_MOSQUITO: {
    id: 77,
    name: "Giant Mosquito",
    texture: "monster_giant_mosquito",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_NEWT: {
    id: 78,
    name: "Giant Newt",
    texture: "monster_giant_newt",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_SCORPION: {
    id: 79,
    name: "Giant Scorpion",
    texture: "monster_giant_scorpion",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_SLUG: {
    id: 80,
    name: "Giant Slug",
    texture: "monster_giant_slug",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_SNAIL: {
    id: 81,
    name: "Giant Snail",
    texture: "monster_giant_snail",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_TOAD: {
    id: 82,
    name: "Giant Toad",
    texture: "monster_giant_toad",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GILA_MONSTER: {
    id: 83,
    name: "Gila Monster",
    texture: "monster_gila_monster",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GREEN_RAT: {
    id: 84,
    name: "Green Rat",
    texture: "monster_green_rat",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GREY_RAT: {
    id: 85,
    name: "Grey Rat",
    texture: "monster_grey_rat",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GREY_SNAKE: {
    id: 86,
    name: "Grey Snake",
    texture: "monster_grey_snake",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GRIZZLY_BEAR: {
    id: 87,
    name: "Grizzly Bear",
    texture: "monster_grizzly_bear",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HELL_HOG: {
    id: 88,
    name: "Hell Hog",
    texture: "monster_hell_hog",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_HELL_HOUND: {
    id: 89,
    name: "Hell Hound",
    texture: "monster_hell_hound",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_HOG: {
    id: 90,
    name: "Hog",
    texture: "monster_hog",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HOLY_SWINE: {
    id: 91,
    name: "Holy Swine",
    texture: "monster_holy_swine",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HOUND: {
    id: 92,
    name: "Hound",
    texture: "monster_hound",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ICE_BEAST: {
    id: 333,
    name: "Ice Beast",
    texture: "monster_ice_beast",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_IGUANA: {
    id: 94,
    name: "Iguana",
    texture: "monster_iguana",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JACKAL: {
    id: 95,
    name: "Jackal",
    texture: "monster_jackal",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JELLYFISH: {
    id: 96,
    name: "Jellyfish",
    texture: "monster_jellyfish",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JUMPING_SPIDER: {
    id: 97,
    name: "Jumping Spider",
    texture: "monster_jumping_spider",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KILLER_BEE: {
    id: 98,
    name: "Killer Bee",
    texture: "monster_killer_bee",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KILLER_BEE_LARVA: {
    id: 99,
    name: "Killer Bee Larva",
    texture: "monster_killer_bee_larva",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KOMODO_DRAGON: {
    id: 100,
    name: "Komodo Dragon",
    texture: "monster_komodo_dragon",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LAVA_FISH: {
    id: 101,
    name: "Lava Fish",
    texture: "monster_lava_fish",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LAVA_WORM: {
    id: 350,
    name: "Lava Worm",
    texture: "monster_lava_worm",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MANA_VIPER: {
    id: 103,
    name: "Mana Viper",
    texture: "monster_mana_viper",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MOTH_OF_WRATH: {
    id: 104,
    name: "Moth Of Wrath",
    texture: "monster_moth_of_wrath",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORANGE_RAT: {
    id: 105,
    name: "Orange Rat",
    texture: "monster_orange_rat",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORB_SPIDER: {
    id: 106,
    name: "Orb Spider",
    texture: "monster_orb_spider",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_POLAR_BEAR: {
    id: 107,
    name: "Polar Bear",
    texture: "monster_polar_bear",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_QUEEN_ANT: {
    id: 108,
    name: "Queen Ant",
    texture: "monster_queen_ant",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_QUEEN_BEE: {
    id: 109,
    name: "Queen Bee",
    texture: "monster_queen_bee",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_QUOKKA: {
    id: 110,
    name: "Quokka",
    texture: "monster_quokka",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_RAIJU: {
    id: 111,
    name: "Raiju",
    texture: "monster_raiju",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_RAT: {
    id: 112,
    name: "Rat",
    texture: "monster_rat",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_RED_WASP: {
    id: 113,
    name: "Red Wasp",
    texture: "monster_red_wasp",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_REDBACK: {
    id: 114,
    name: "Redback",
    texture: "monster_redback",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ROCK_WORM: {
    id: 115,
    name: "Rock Worm",
    texture: "monster_rock_worm",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SALAMANDER: {
    id: 468,
    name: "Salamander",
    texture: "monster_salamander",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SCORPION: {
    id: 117,
    name: "Scorpion",
    texture: "monster_scorpion",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SEA_SNAKE: {
    id: 118,
    name: "Sea Snake",
    texture: "monster_sea_snake",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SHEEP: {
    id: 119,
    name: "Sheep",
    texture: "monster_sheep",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SHOCK_SERPENT: {
    id: 120,
    name: "Shock Serpent",
    texture: "monster_shock_serpent",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SMALL_SNAKE: {
    id: 121,
    name: "Small Snake",
    texture: "monster_small_snake",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SNAKE: {
    id: 122,
    name: "Snake",
    texture: "monster_snake",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SNAPPING_TURTLE: {
    id: 123,
    name: "Snapping Turtle",
    texture: "monster_snapping_turtle",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SNAPPING_TURTLE_SHELL: {
    id: 124,
    name: "Snapping Turtle Shell",
    texture: "monster_snapping_turtle_shell",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SOLDIER_ANT: {
    id: 125,
    name: "Soldier Ant",
    texture: "monster_soldier_ant",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPIDER: {
    id: 126,
    name: "Spider",
    texture: "monster_spider",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPINY_FROG: {
    id: 127,
    name: "Spiny Frog",
    texture: "monster_spiny_frog",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPINY_WORM: {
    id: 128,
    name: "Spiny Worm",
    texture: "monster_spiny_worm",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TARANTELLA: {
    id: 129,
    name: "Tarantella",
    texture: "monster_tarantella",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TRAPDOOR_SPIDER: {
    id: 130,
    name: "Trapdoor Spider",
    texture: "monster_trapdoor_spider",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TURTLE: {
    id: 131,
    name: "Turtle",
    texture: "monster_turtle",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_VIPER: {
    id: 132,
    name: "Viper",
    texture: "monster_viper",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_WAR_DOG: {
    id: 133,
    name: "War Dog",
    texture: "monster_war_dog",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_WARG: {
    id: 134,
    name: "Warg",
    texture: "monster_warg",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_WATER_MOCCASIN: {
    id: 135,
    name: "Water Moccasin",
    texture: "monster_water_moccasin",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_WOLF: {
    id: 136,
    name: "Wolf",
    texture: "monster_wolf",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_WOLF_SPIDER: {
    id: 137,
    name: "Wolf Spider",
    texture: "monster_wolf_spider",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_WORKER_ANT: {
    id: 138,
    name: "Worker Ant",
    texture: "monster_worker_ant",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_WORM: {
    id: 139,
    name: "Worm",
    texture: "monster_worm",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_YAK: {
    id: 140,
    name: "Yak",
    texture: "monster_yak",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_YELLOW_SNAKE: {
    id: 141,
    name: "Yellow Snake",
    texture: "monster_yellow_snake",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_YELLOW_WASP: {
    id: 142,
    name: "Yellow Wasp",
    texture: "monster_yellow_wasp",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ANUBIS_GUARD: {
    id: 143,
    name: "Anubis Guard",
    texture: "monster_anubis_guard",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BIG_KOBOLD: {
    id: 144,
    name: "Big Kobold",
    texture: "monster_big_kobold",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BOGGART: {
    id: 145,
    name: "Boggart",
    texture: "monster_boggart",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BROWN_OOZE: {
    id: 146,
    name: "Brown Ooze",
    texture: "monster_brown_ooze",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CENTAUR_MELEE: {
    id: 147,
    name: "Centaur-Melee",
    texture: "monster_centaur-melee",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CENTAUR: {
    id: 148,
    name: "Centaur",
    texture: "monster_centaur",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CENTAUR_WARRIOR_MELEE: {
    id: 149,
    name: "Centaur Warrior-Melee",
    texture: "monster_centaur_warrior-melee",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CENTAUR_WARRIOR: {
    id: 150,
    name: "Centaur Warrior",
    texture: "monster_centaur_warrior",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CYCLOPS: {
    id: 151,
    name: "Cyclops",
    texture: "monster_cyclops",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DAEVA: {
    id: 321,
    name: "Daeva",
    texture: "monster_daeva",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEATH_DRAKE: {
    id: 153,
    name: "Death Drake",
    texture: "monster_death_drake",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEATH_KNIGHT: {
    id: 154,
    name: "Death Knight",
    texture: "monster_death_knight",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_DWARF: {
    id: 155,
    name: "Deep Dwarf",
    texture: "monster_deep_dwarf",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_DWARF_ARTIFICER: {
    id: 156,
    name: "Deep Dwarf Artificer",
    texture: "monster_deep_dwarf_artificer",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_DWARF_BERSERKER: {
    id: 157,
    name: "Deep Dwarf Berserker",
    texture: "monster_deep_dwarf_berserker",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_DWARF_DEATH_KNIGHT: {
    id: 158,
    name: "Deep Dwarf Death Knight",
    texture: "monster_deep_dwarf_death_knight",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_ANNIHILATOR: {
    id: 159,
    name: "Deep Elf Annihilator",
    texture: "monster_deep_elf_annihilator",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_BLADEMASTER: {
    id: 160,
    name: "Deep Elf Blademaster",
    texture: "monster_deep_elf_blademaster",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_CONJURER: {
    id: 161,
    name: "Deep Elf Conjurer",
    texture: "monster_deep_elf_conjurer",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_DEATH_MAGE: {
    id: 162,
    name: "Deep Elf Death Mage",
    texture: "monster_deep_elf_death_mage",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_DEMONOLOGIST: {
    id: 163,
    name: "Deep Elf Demonologist",
    texture: "monster_deep_elf_demonologist",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_FIGHTER: {
    id: 164,
    name: "Deep Elf Fighter",
    texture: "monster_deep_elf_fighter",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_HIGH_PRIEST: {
    id: 165,
    name: "Deep Elf High Priest",
    texture: "monster_deep_elf_high_priest",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_KNIGHT: {
    id: 166,
    name: "Deep Elf Knight",
    texture: "monster_deep_elf_knight",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_MAGE: {
    id: 167,
    name: "Deep Elf Mage",
    texture: "monster_deep_elf_mage",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_MASTER_ARCHER: {
    id: 168,
    name: "Deep Elf Master Archer",
    texture: "monster_deep_elf_master_archer",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_PRIEST: {
    id: 169,
    name: "Deep Elf Priest",
    texture: "monster_deep_elf_priest",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_SOLDIER: {
    id: 170,
    name: "Deep Elf Soldier",
    texture: "monster_deep_elf_soldier",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_SORCERER: {
    id: 171,
    name: "Deep Elf Sorcerer",
    texture: "monster_deep_elf_sorcerer",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_ELF_SUMMONER: {
    id: 172,
    name: "Deep Elf Summoner",
    texture: "monster_deep_elf_summoner",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_TROLL: {
    id: 173,
    name: "Deep Troll",
    texture: "monster_deep_troll",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_TROLL_BERSERKER: {
    id: 174,
    name: "Deep Troll Berserker",
    texture: "monster_deep_troll_berserker",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_TROLL_EARTH_MAGE: {
    id: 175,
    name: "Deep Troll Earth Mage",
    texture: "monster_deep_troll_earth_mage",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEEP_TROLL_SHAMAN: {
    id: 176,
    name: "Deep Troll Shaman",
    texture: "monster_deep_troll_shaman",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ABOMINATION_LARGE: {
    id: 177,
    name: "Abomination Large",
    texture: "monster_abomination_large",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ABOMINATION_LARGE_1: {
    id: 178,
    name: "Abomination Large 1",
    texture: "monster_abomination_large_1",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ABOMINATION_LARGE_2: {
    id: 179,
    name: "Abomination Large 2",
    texture: "monster_abomination_large_2",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ABOMINATION_LARGE_3: {
    id: 180,
    name: "Abomination Large 3",
    texture: "monster_abomination_large_3",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ABOMINATION_LARGE_4: {
    id: 181,
    name: "Abomination Large 4",
    texture: "monster_abomination_large_4",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ABOMINATION_LARGE_5: {
    id: 182,
    name: "Abomination Large 5",
    texture: "monster_abomination_large_5",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ABOMINATION_LARGE_6: {
    id: 183,
    name: "Abomination Large 6",
    texture: "monster_abomination_large_6",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ABOMINATION_SMALL: {
    id: 184,
    name: "Abomination Small",
    texture: "monster_abomination_small",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ABOMINATION_SMALL_1: {
    id: 185,
    name: "Abomination Small 1",
    texture: "monster_abomination_small_1",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_BALRUG: {
    id: 186,
    name: "Balrug",
    texture: "monster_balrug",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_BEAST: {
    id: 187,
    name: "Beast",
    texture: "monster_beast",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_BLIZZARD_DEMON: {
    id: 188,
    name: "Blizzard Demon",
    texture: "monster_blizzard_demon",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_BLUE_DEATH: {
    id: 189,
    name: "Blue Death",
    texture: "monster_blue_death",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_BLUE_DEVIL: {
    id: 190,
    name: "Blue Devil",
    texture: "monster_blue_devil",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_CACODEMON: {
    id: 191,
    name: "Cacodemon",
    texture: "monster_cacodemon",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_CHAOS_SPAWN: {
    id: 192,
    name: "Chaos Spawn",
    texture: "monster_chaos_spawn",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_CHAOS_SPAWN_1: {
    id: 193,
    name: "Chaos Spawn 1",
    texture: "monster_chaos_spawn_1",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_CHAOS_SPAWN_2: {
    id: 194,
    name: "Chaos Spawn 2",
    texture: "monster_chaos_spawn_2",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_CHAOS_SPAWN_3: {
    id: 195,
    name: "Chaos Spawn 3",
    texture: "monster_chaos_spawn_3",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_CHAOS_SPAWN_4: {
    id: 196,
    name: "Chaos Spawn 4",
    texture: "monster_chaos_spawn_4",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_CHAOS_SPAWN_5: {
    id: 197,
    name: "Chaos Spawn 5",
    texture: "monster_chaos_spawn_5",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_CIGOTUVIS_MONSTER: {
    id: 198,
    name: "Cigotuvis Monster",
    texture: "monster_cigotuvis_monster",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMONIC_CRAWLER: {
    id: 199,
    name: "Demonic Crawler",
    texture: "monster_demonic_crawler",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DIMME: {
    id: 200,
    name: "Dimme",
    texture: "monster_dimme",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_EFREET: {
    id: 201,
    name: "Efreet",
    texture: "monster_efreet",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_EXECUTIONER: {
    id: 202,
    name: "Executioner",
    texture: "monster_executioner",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_FIEND: {
    id: 203,
    name: "Fiend",
    texture: "monster_fiend",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_GREEN_DEATH: {
    id: 204,
    name: "Green Death",
    texture: "monster_green_death",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_HAIRY_DEVIL: {
    id: 205,
    name: "Hairy Devil",
    texture: "monster_hairy_devil",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_HELL_SENTINEL: {
    id: 206,
    name: "Hell Sentinel",
    texture: "monster_hell_sentinel",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_HELLION: {
    id: 207,
    name: "Hellion",
    texture: "monster_hellion",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_HELLWING: {
    id: 208,
    name: "Hellwing",
    texture: "monster_hellwing",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ICE_DEVIL: {
    id: 209,
    name: "Ice Devil",
    texture: "monster_ice_devil",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ICE_FIEND: {
    id: 210,
    name: "Ice Fiend",
    texture: "monster_ice_fiend",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_IMP: {
    id: 211,
    name: "Imp",
    texture: "monster_imp",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_IRON_DEVIL: {
    id: 212,
    name: "Iron Devil",
    texture: "monster_iron_devil",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_IRON_IMP: {
    id: 213,
    name: "Iron Imp",
    texture: "monster_iron_imp",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_LEMURE: {
    id: 214,
    name: "Lemure",
    texture: "monster_lemure",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_LOROCYPROCA: {
    id: 215,
    name: "Lorocyproca",
    texture: "monster_lorocyproca",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_MIDGE: {
    id: 216,
    name: "Midge",
    texture: "monster_midge",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_NEQOXEC: {
    id: 217,
    name: "Neqoxec",
    texture: "monster_neqoxec",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ORANGE_DEMON: {
    id: 218,
    name: "Orange Demon",
    texture: "monster_orange_demon",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_PIT_FIEND: {
    id: 219,
    name: "Pit Fiend",
    texture: "monster_pit_fiend",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_QUASIT: {
    id: 220,
    name: "Quasit",
    texture: "monster_quasit",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_RAKSHASA: {
    id: 221,
    name: "Rakshasa",
    texture: "monster_rakshasa",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_REAPER: {
    id: 222,
    name: "Reaper",
    texture: "monster_reaper",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_RED_DEVIL: {
    id: 223,
    name: "Red Devil",
    texture: "monster_red_devil",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_ROTTING_DEVIL: {
    id: 224,
    name: "Rotting Devil",
    texture: "monster_rotting_devil",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_RUST_DEVIL: {
    id: 225,
    name: "Rust Devil",
    texture: "monster_rust_devil",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SHADOW_DEMON: {
    id: 226,
    name: "Shadow Demon",
    texture: "monster_shadow_demon",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SHADOW_FIEND: {
    id: 227,
    name: "Shadow Fiend",
    texture: "monster_shadow_fiend",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SHADOW_IMP: {
    id: 228,
    name: "Shadow Imp",
    texture: "monster_shadow_imp",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SIXFIRHY: {
    id: 229,
    name: "Sixfirhy",
    texture: "monster_sixfirhy",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SMOKE_DEMON: {
    id: 230,
    name: "Smoke Demon",
    texture: "monster_smoke_demon",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SOUL_EATER: {
    id: 231,
    name: "Soul Eater",
    texture: "monster_soul_eater",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SUN_DEMON: {
    id: 232,
    name: "Sun Demon",
    texture: "monster_sun_demon",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_TENTACLED_MONSTROSITY: {
    id: 233,
    name: "Tentacled Monstrosity",
    texture: "monster_tentacled_monstrosity",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_TORMENTOR: {
    id: 234,
    name: "Tormentor",
    texture: "monster_tormentor",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_UFETUBUS: {
    id: 235,
    name: "Ufetubus",
    texture: "monster_ufetubus",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_UGLY_THING: {
    id: 236,
    name: "Ugly Thing",
    texture: "monster_ugly_thing",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_UGLY_THING_1: {
    id: 237,
    name: "Ugly Thing 1",
    texture: "monster_ugly_thing_1",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_UGLY_THING_2: {
    id: 238,
    name: "Ugly Thing 2",
    texture: "monster_ugly_thing_2",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_UGLY_THING_3: {
    id: 239,
    name: "Ugly Thing 3",
    texture: "monster_ugly_thing_3",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_UGLY_THING_4: {
    id: 240,
    name: "Ugly Thing 4",
    texture: "monster_ugly_thing_4",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_UGLY_THING_5: {
    id: 241,
    name: "Ugly Thing 5",
    texture: "monster_ugly_thing_5",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_UNSPEAKABLE_BOTTOM: {
    id: 242,
    name: "Unspeakable Bottom",
    texture: "monster_unspeakable_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_UNSPEAKABLE_TOP: {
    id: 243,
    name: "Unspeakable Top",
    texture: "monster_unspeakable_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_VERY_UGLY_THING: {
    id: 244,
    name: "Very Ugly Thing",
    texture: "monster_very_ugly_thing",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_VERY_UGLY_THING_1: {
    id: 245,
    name: "Very Ugly Thing 1",
    texture: "monster_very_ugly_thing_1",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_VERY_UGLY_THING_2: {
    id: 246,
    name: "Very Ugly Thing 2",
    texture: "monster_very_ugly_thing_2",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_VERY_UGLY_THING_3: {
    id: 247,
    name: "Very Ugly Thing 3",
    texture: "monster_very_ugly_thing_3",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_VERY_UGLY_THING_4: {
    id: 248,
    name: "Very Ugly Thing 4",
    texture: "monster_very_ugly_thing_4",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_VERY_UGLY_THING_5: {
    id: 249,
    name: "Very Ugly Thing 5",
    texture: "monster_very_ugly_thing_5",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_WHITE_IMP: {
    id: 250,
    name: "White Imp",
    texture: "monster_white_imp",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_YNOXINUL: {
    id: 251,
    name: "Ynoxinul",
    texture: "monster_ynoxinul",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_BLACK_SUN: {
    id: 252,
    name: "Black Sun",
    texture: "monster_black_sun",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_BLOOD_SAINT: {
    id: 253,
    name: "Blood Saint",
    texture: "monster_blood_saint",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_CHAOS_CHAMPION: {
    id: 254,
    name: "Chaos Champion",
    texture: "monster_chaos_champion",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_CORRUPTER: {
    id: 255,
    name: "Corrupter",
    texture: "monster_corrupter",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMONSPAWN: {
    id: 263,
    name: "Demonspawn",
    texture: "monster_demonspawn",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_GELID: {
    id: 257,
    name: "Gelid",
    texture: "monster_gelid",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_INFERNAL: {
    id: 258,
    name: "Infernal",
    texture: "monster_infernal",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_MONSTROUS: {
    id: 259,
    name: "Monstrous",
    texture: "monster_monstrous",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_PUTRID: {
    id: 260,
    name: "Putrid",
    texture: "monster_putrid",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_TORTUROUS: {
    id: 261,
    name: "Torturous",
    texture: "monster_torturous",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_WARMONGER: {
    id: 262,
    name: "Warmonger",
    texture: "monster_warmonger",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DRYAD: {
    id: 264,
    name: "Dryad",
    texture: "monster_dryad",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DWARF: {
    id: 265,
    name: "Dwarf",
    texture: "monster_dwarf",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ELF: {
    id: 266,
    name: "Elf",
    texture: "monster_elf",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ENCHANTRESS_HUMAN: {
    id: 267,
    name: "Enchantress Human",
    texture: "monster_enchantress_human",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ENTROPY_WEAVER: {
    id: 268,
    name: "Entropy Weaver",
    texture: "monster_entropy_weaver",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ETTIN: {
    id: 269,
    name: "Ettin",
    texture: "monster_ettin",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_EYE_OF_DEVASTATION: {
    id: 270,
    name: "Eye Of Devastation",
    texture: "monster_eye_of_devastation",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_EYE_OF_DRAINING: {
    id: 271,
    name: "Eye Of Draining",
    texture: "monster_eye_of_draining",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_EYEBALL: {
    id: 272,
    name: "Giant Eyeball",
    texture: "monster_giant_eyeball",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GOLDEN_EYE: {
    id: 273,
    name: "Golden Eye",
    texture: "monster_golden_eye",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GREAT_ORB_OF_EYES: {
    id: 274,
    name: "Great Orb Of Eyes",
    texture: "monster_great_orb_of_eyes",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SHINING_EYE: {
    id: 275,
    name: "Shining Eye",
    texture: "monster_shining_eye",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FAUN: {
    id: 276,
    name: "Faun",
    texture: "monster_faun",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FIRE_DRAKE: {
    id: 277,
    name: "Fire Drake",
    texture: "monster_fire_drake",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FIRE_GIANT: {
    id: 278,
    name: "Fire Giant",
    texture: "monster_fire_giant",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FOREST_DRAKE: {
    id: 279,
    name: "Forest Drake",
    texture: "monster_forest_drake",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FORMICID: {
    id: 280,
    name: "Formicid",
    texture: "monster_formicid",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FORMICID_VENOM_MAGE: {
    id: 281,
    name: "Formicid Venom Mage",
    texture: "monster_formicid_venom_mage",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FROST_GIANT: {
    id: 282,
    name: "Frost Giant",
    texture: "monster_frost_giant",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BRIAR_PATCH: {
    id: 283,
    name: "Briar Patch",
    texture: "monster_briar_patch",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_DEATHCAP: {
    id: 284,
    name: "Deathcap",
    texture: "monster_deathcap",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_GIANT_SPORE: {
    id: 285,
    name: "Giant Spore",
    texture: "monster_giant_spore",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_HYPERACTIVE_BALLISTOMYCETE: {
    id: 286,
    name: "Hyperactive Ballistomycete",
    texture: "monster_hyperactive_ballistomycete",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_OKLOB_PLANT: {
    id: 287,
    name: "Oklob Plant",
    texture: "monster_oklob_plant",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_PLANT: {
    id: 288,
    name: "Plant",
    texture: "monster_plant",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_PLANT_CRYPT: {
    id: 289,
    name: "Plant Crypt",
    texture: "monster_plant_crypt",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_PLANT_DEMONIC: {
    id: 290,
    name: "Plant Demonic",
    texture: "monster_plant_demonic",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_THORN_HUNTER: {
    id: 291,
    name: "Thorn Hunter",
    texture: "monster_thorn_hunter",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_THORN_LOTUS: {
    id: 292,
    name: "Thorn Lotus",
    texture: "monster_thorn_lotus",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_TREANT: {
    id: 293,
    name: "Treant",
    texture: "monster_treant",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_VINE_STALKER: {
    id: 294,
    name: "Vine Stalker",
    texture: "monster_vine_stalker",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_WANDERING_MUSHROOM: {
    id: 295,
    name: "Wandering Mushroom",
    texture: "monster_wandering_mushroom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "plant",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_fruit: 1
    }
  },
  MONSTER_MONSTER_GIANT_AMOEBA: {
    id: 296,
    name: "Giant Amoeba",
    texture: "monster_giant_amoeba",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIANT_ORANGE_BRAIN: {
    id: 297,
    name: "Giant Orange Brain",
    texture: "monster_giant_orange_brain",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GLOWING_SHAPESHIFTER: {
    id: 298,
    name: "Glowing Shapeshifter",
    texture: "monster_glowing_shapeshifter",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GNOLL: {
    id: 299,
    name: "Gnoll",
    texture: "monster_gnoll",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GNOLL_SERGEANT: {
    id: 300,
    name: "Gnoll Sergeant",
    texture: "monster_gnoll_sergeant",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GNOLL_SHAMAN: {
    id: 301,
    name: "Gnoll Shaman",
    texture: "monster_gnoll_shaman",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GNOME: {
    id: 302,
    name: "Gnome",
    texture: "monster_gnome",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GOBLIN: {
    id: 303,
    name: "Goblin",
    texture: "monster_goblin",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GOLDEN_DRAGON: {
    id: 304,
    name: "Golden Dragon",
    texture: "monster_golden_dragon",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GRAND_AVATAR: {
    id: 305,
    name: "Grand Avatar",
    texture: "monster_grand_avatar",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GREATER_NAGA: {
    id: 306,
    name: "Greater Naga",
    texture: "monster_greater_naga",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GRIFFON: {
    id: 307,
    name: "Griffon",
    texture: "monster_griffon",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GUARDIAN_NAGA: {
    id: 308,
    name: "Guardian Naga",
    texture: "monster_guardian_naga",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GUARDIAN_SERPENT: {
    id: 309,
    name: "Guardian Serpent",
    texture: "monster_guardian_serpent",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HALFLING: {
    id: 310,
    name: "Halfling",
    texture: "monster_halfling",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HARPY: {
    id: 311,
    name: "Harpy",
    texture: "monster_harpy",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HELL_KNIGHT: {
    id: 312,
    name: "Hell Knight",
    texture: "monster_hell_knight",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_HILL_GIANT: {
    id: 313,
    name: "Hill Giant",
    texture: "monster_hill_giant",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HIPPOGRIFF: {
    id: 314,
    name: "Hippogriff",
    texture: "monster_hippogriff",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HOBGOBLIN: {
    id: 315,
    name: "Hobgoblin",
    texture: "monster_hobgoblin",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ANGEL_MACE: {
    id: 316,
    name: "Angel Mace",
    texture: "monster_angel_mace",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ANGEL: {
    id: 317,
    name: "Angel",
    texture: "monster_angel",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_APIS: {
    id: 318,
    name: "Apis",
    texture: "monster_apis",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CENTAUR_PALADIN: {
    id: 319,
    name: "Centaur Paladin",
    texture: "monster_centaur_paladin",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CHERUB: {
    id: 320,
    name: "Cherub",
    texture: "monster_cherub",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_EASTERN_DRAGON: {
    id: 322,
    name: "Eastern Dragon",
    texture: "monster_eastern_dragon",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HOLY_DRAGON: {
    id: 323,
    name: "Holy Dragon",
    texture: "monster_holy_dragon",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OPHAN: {
    id: 324,
    name: "Ophan",
    texture: "monster_ophan",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_PALADIN: {
    id: 325,
    name: "Paladin",
    texture: "monster_paladin",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SERAPH_BOTTOM: {
    id: 326,
    name: "Seraph Bottom",
    texture: "monster_seraph_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SERAPH_TOP: {
    id: 327,
    name: "Seraph Top",
    texture: "monster_seraph_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SHEDU: {
    id: 328,
    name: "Shedu",
    texture: "monster_shedu",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HUMAN_MONK_GHOST: {
    id: 329,
    name: "Human Monk Ghost",
    texture: "monster_human_monk_ghost",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HUMAN: {
    id: 330,
    name: "Human",
    texture: "monster_human",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HUMAN_SLAVE: {
    id: 331,
    name: "Human Slave",
    texture: "monster_human_slave",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HYDRATAUR: {
    id: 332,
    name: "Hydrataur",
    texture: "monster_hydrataur",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_IRON_TROLL: {
    id: 334,
    name: "Iron Troll",
    texture: "monster_iron_troll",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_IRON_TROLL_MONK_GHOST: {
    id: 335,
    name: "Iron Troll Monk Ghost",
    texture: "monster_iron_troll_monk_ghost",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_IRONBRAND_CONVOKER: {
    id: 336,
    name: "Ironbrand Convoker",
    texture: "monster_ironbrand_convoker",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_IRONHEART_PRESERVER: {
    id: 337,
    name: "Ironheart Preserver",
    texture: "monster_ironheart_preserver",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JUGGERNAUT: {
    id: 339,
    name: "Juggernaut",
    texture: "monster_juggernaut",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KENKU_WINGED: {
    id: 340,
    name: "Kenku Winged",
    texture: "monster_kenku_winged",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KILLER_KLOWN: {
    id: 341,
    name: "Killer Klown",
    texture: "monster_killer_klown",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KILLER_KLOWN_BLUE: {
    id: 342,
    name: "Killer Klown Blue",
    texture: "monster_killer_klown_blue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KILLER_KLOWN_GREEN: {
    id: 343,
    name: "Killer Klown Green",
    texture: "monster_killer_klown_green",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KILLER_KLOWN_PURPLE: {
    id: 344,
    name: "Killer Klown Purple",
    texture: "monster_killer_klown_purple",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KILLER_KLOWN_RED: {
    id: 345,
    name: "Killer Klown Red",
    texture: "monster_killer_klown_red",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KILLER_KLOWN_YELLOW: {
    id: 346,
    name: "Killer Klown Yellow",
    texture: "monster_killer_klown_yellow",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KOBOLD_DEMONOLOGIST: {
    id: 347,
    name: "Kobold Demonologist",
    texture: "monster_kobold_demonologist",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_KOBOLD: {
    id: 348,
    name: "Kobold",
    texture: "monster_kobold",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LABRAT_UNSEEN: {
    id: 349,
    name: "Labrat Unseen",
    texture: "monster_labrat_unseen",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LINDWURM: {
    id: 351,
    name: "Lindwurm",
    texture: "monster_lindwurm",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MANTICORE: {
    id: 352,
    name: "Manticore",
    texture: "monster_manticore",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MERFOLK: {
    id: 353,
    name: "Merfolk",
    texture: "monster_merfolk",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_AQUAMANCER: {
    id: 354,
    name: "Merfolk Aquamancer",
    texture: "monster_merfolk_aquamancer",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_AQUAMANCER_WATER: {
    id: 355,
    name: "Merfolk Aquamancer Water",
    texture: "monster_merfolk_aquamancer_water",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_AVATAR: {
    id: 356,
    name: "Merfolk Avatar",
    texture: "monster_merfolk_avatar",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_AVATAR_WATER: {
    id: 357,
    name: "Merfolk Avatar Water",
    texture: "monster_merfolk_avatar_water",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_FIGHTER: {
    id: 358,
    name: "Merfolk Fighter",
    texture: "monster_merfolk_fighter",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_FIGHTER_WATER: {
    id: 359,
    name: "Merfolk Fighter Water",
    texture: "monster_merfolk_fighter_water",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_IMPALER: {
    id: 360,
    name: "Merfolk Impaler",
    texture: "monster_merfolk_impaler",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_IMPALER_WATER: {
    id: 361,
    name: "Merfolk Impaler Water",
    texture: "monster_merfolk_impaler_water",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_JAVELINEER: {
    id: 362,
    name: "Merfolk Javelineer",
    texture: "monster_merfolk_javelineer",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_JAVELINEER_WATER: {
    id: 363,
    name: "Merfolk Javelineer Water",
    texture: "monster_merfolk_javelineer_water",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_PLAIN: {
    id: 364,
    name: "Merfolk Plain",
    texture: "monster_merfolk_plain",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_PLAIN_WATER: {
    id: 365,
    name: "Merfolk Plain Water",
    texture: "monster_merfolk_plain_water",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_MERFOLK_WATER: {
    id: 366,
    name: "Merfolk Water",
    texture: "monster_merfolk_water",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_MERMAID: {
    id: 367,
    name: "Mermaid",
    texture: "monster_mermaid",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MERMAID_WATER: {
    id: 368,
    name: "Mermaid Water",
    texture: "monster_mermaid_water",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_MINOTAUR: {
    id: 369,
    name: "Minotaur",
    texture: "monster_minotaur",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MOTH_OF_SUPPRESSION: {
    id: 370,
    name: "Moth Of Suppression",
    texture: "monster_moth_of_suppression",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MUTANT_BEAST: {
    id: 371,
    name: "Mutant Beast",
    texture: "monster_mutant_beast",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NAGA: {
    id: 372,
    name: "Naga",
    texture: "monster_naga",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NAGA_MAGE: {
    id: 373,
    name: "Naga Mage",
    texture: "monster_naga_mage",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NAGA_RITUALIST: {
    id: 374,
    name: "Naga Ritualist",
    texture: "monster_naga_ritualist",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NAGA_SHARPSHOOTER: {
    id: 375,
    name: "Naga Sharpshooter",
    texture: "monster_naga_sharpshooter",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NAGA_WARRIOR: {
    id: 376,
    name: "Naga Warrior",
    texture: "monster_naga_warrior",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NAGA_WARRIOR_UNIQUE: {
    id: 377,
    name: "Naga Warrior Unique",
    texture: "monster_naga_warrior_unique",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NECROMANCER: {
    id: 378,
    name: "Necromancer",
    texture: "monster_necromancer",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OGRE_MAGE: {
    id: 379,
    name: "Ogre Mage",
    texture: "monster_ogre_mage",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OGRE: {
    id: 380,
    name: "Ogre",
    texture: "monster_ogre",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORB_GUARDIAN: {
    id: 381,
    name: "Orb Guardian",
    texture: "monster_orb_guardian",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORC_HIGH_PRIEST: {
    id: 382,
    name: "Orc High Priest",
    texture: "monster_orc_high_priest",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORC_KNIGHT: {
    id: 383,
    name: "Orc Knight",
    texture: "monster_orc_knight",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORC: {
    id: 384,
    name: "Orc",
    texture: "monster_orc",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORC_PRIEST: {
    id: 385,
    name: "Orc Priest",
    texture: "monster_orc_priest",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORC_SORCERER: {
    id: 386,
    name: "Orc Sorcerer",
    texture: "monster_orc_sorcerer",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORC_WARLORD: {
    id: 387,
    name: "Orc Warlord",
    texture: "monster_orc_warlord",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORC_WARRIOR: {
    id: 388,
    name: "Orc Warrior",
    texture: "monster_orc_warrior",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORC_WIZARD: {
    id: 389,
    name: "Orc Wizard",
    texture: "monster_orc_wizard",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_ARMOR_BOTTOM: {
    id: 390,
    name: "Demon Body Armor Bottom",
    texture: "monster_demon_body_armor_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_ARMOR_TOP: {
    id: 391,
    name: "Demon Body Armor Top",
    texture: "monster_demon_body_armor_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_CATERPILLAR_BOTTOM: {
    id: 392,
    name: "Demon Body Caterpillar Bottom",
    texture: "monster_demon_body_caterpillar_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_CATERPILLAR_TOP: {
    id: 393,
    name: "Demon Body Caterpillar Top",
    texture: "monster_demon_body_caterpillar_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_CROUCH_BOTTOM: {
    id: 394,
    name: "Demon Body Crouch Bottom",
    texture: "monster_demon_body_crouch_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_CROUCH_TOP: {
    id: 395,
    name: "Demon Body Crouch Top",
    texture: "monster_demon_body_crouch_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_FAT_BOTTOM: {
    id: 396,
    name: "Demon Body Fat Bottom",
    texture: "monster_demon_body_fat_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_FAT_TOP: {
    id: 397,
    name: "Demon Body Fat Top",
    texture: "monster_demon_body_fat_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_FATTER_BOTTOM: {
    id: 398,
    name: "Demon Body Fatter Bottom",
    texture: "monster_demon_body_fatter_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_FATTER_TOP: {
    id: 399,
    name: "Demon Body Fatter Top",
    texture: "monster_demon_body_fatter_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_MANTIS_BOTTOM: {
    id: 400,
    name: "Demon Body Mantis Bottom",
    texture: "monster_demon_body_mantis_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_MANTIS_TOP: {
    id: 401,
    name: "Demon Body Mantis Top",
    texture: "monster_demon_body_mantis_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_NORMAL_BOTTOM: {
    id: 402,
    name: "Demon Body Normal Bottom",
    texture: "monster_demon_body_normal_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_NORMAL_TOP: {
    id: 403,
    name: "Demon Body Normal Top",
    texture: "monster_demon_body_normal_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_SKELETAL_BOTTOM: {
    id: 404,
    name: "Demon Body Skeletal Bottom",
    texture: "monster_demon_body_skeletal_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_SKELETAL_TOP: {
    id: 405,
    name: "Demon Body Skeletal Top",
    texture: "monster_demon_body_skeletal_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_SPIKED_BOTTOM: {
    id: 406,
    name: "Demon Body Spiked Bottom",
    texture: "monster_demon_body_spiked_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_SPIKED_TOP: {
    id: 407,
    name: "Demon Body Spiked Top",
    texture: "monster_demon_body_spiked_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_SPOTTY_BOTTOM: {
    id: 408,
    name: "Demon Body Spotty Bottom",
    texture: "monster_demon_body_spotty_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_SPOTTY_TOP: {
    id: 409,
    name: "Demon Body Spotty Top",
    texture: "monster_demon_body_spotty_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_SUCCUBUS_BOTTOM: {
    id: 410,
    name: "Demon Body Succubus Bottom",
    texture: "monster_demon_body_succubus_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_SUCCUBUS_TOP: {
    id: 411,
    name: "Demon Body Succubus Top",
    texture: "monster_demon_body_succubus_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_TENTACLEY_BOTTOM: {
    id: 412,
    name: "Demon Body Tentacley Bottom",
    texture: "monster_demon_body_tentacley_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_TENTACLEY_TOP: {
    id: 413,
    name: "Demon Body Tentacley Top",
    texture: "monster_demon_body_tentacley_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_THIN_BOTTOM: {
    id: 414,
    name: "Demon Body Thin Bottom",
    texture: "monster_demon_body_thin_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_BODY_THIN_TOP: {
    id: 415,
    name: "Demon Body Thin Top",
    texture: "monster_demon_body_thin_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_BIRD_TOP: {
    id: 416,
    name: "Demon Head Bird Top",
    texture: "monster_demon_head_bird_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_BOXES_TOP: {
    id: 417,
    name: "Demon Head Boxes Top",
    texture: "monster_demon_head_boxes_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_BRAIN_TOP: {
    id: 418,
    name: "Demon Head Brain Top",
    texture: "monster_demon_head_brain_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_BUTTERFLY_TOP: {
    id: 419,
    name: "Demon Head Butterfly Top",
    texture: "monster_demon_head_butterfly_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_COW_SKULL_TOP: {
    id: 420,
    name: "Demon Head Cow Skull Top",
    texture: "monster_demon_head_cow_skull_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_CTHULHU_TOP: {
    id: 421,
    name: "Demon Head Cthulhu Top",
    texture: "monster_demon_head_cthulhu_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_ELEPHANT_TOP: {
    id: 422,
    name: "Demon Head Elephant Top",
    texture: "monster_demon_head_elephant_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_EYEBALL_TOP: {
    id: 423,
    name: "Demon Head Eyeball Top",
    texture: "monster_demon_head_eyeball_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_FLY_TOP: {
    id: 424,
    name: "Demon Head Fly Top",
    texture: "monster_demon_head_fly_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_FROG_TOP: {
    id: 425,
    name: "Demon Head Frog Top",
    texture: "monster_demon_head_frog_top",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_FUNGUS_TOP: {
    id: 426,
    name: "Demon Head Fungus Top",
    texture: "monster_demon_head_fungus_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_HAIR_TOP: {
    id: 427,
    name: "Demon Head Hair Top",
    texture: "monster_demon_head_hair_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_HEADS_TOP: {
    id: 428,
    name: "Demon Head Heads Top",
    texture: "monster_demon_head_heads_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_HELMET_TOP: {
    id: 429,
    name: "Demon Head Helmet Top",
    texture: "monster_demon_head_helmet_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_HORN_TOP: {
    id: 430,
    name: "Demon Head Horn Top",
    texture: "monster_demon_head_horn_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_HORNS_TOP: {
    id: 431,
    name: "Demon Head Horns Top",
    texture: "monster_demon_head_horns_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_HORSE_TOP: {
    id: 432,
    name: "Demon Head Horse Top",
    texture: "monster_demon_head_horse_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_INCUBUS_TOP: {
    id: 433,
    name: "Demon Head Incubus Top",
    texture: "monster_demon_head_incubus_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_MEDUSA_TOP: {
    id: 434,
    name: "Demon Head Medusa Top",
    texture: "monster_demon_head_medusa_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_MONKEY_TOP: {
    id: 435,
    name: "Demon Head Monkey Top",
    texture: "monster_demon_head_monkey_top",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_MOUSE_TOP: {
    id: 436,
    name: "Demon Head Mouse Top",
    texture: "monster_demon_head_mouse_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_RAM_TOP: {
    id: 437,
    name: "Demon Head Ram Top",
    texture: "monster_demon_head_ram_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_RHINO_TOP: {
    id: 438,
    name: "Demon Head Rhino Top",
    texture: "monster_demon_head_rhino_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_SKULL_TOP: {
    id: 439,
    name: "Demon Head Skull Top",
    texture: "monster_demon_head_skull_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_SUCCUBUS_TOP: {
    id: 440,
    name: "Demon Head Succubus Top",
    texture: "monster_demon_head_succubus_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_TEETH_TOP: {
    id: 441,
    name: "Demon Head Teeth Top",
    texture: "monster_demon_head_teeth_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_TENTACLES_TOP: {
    id: 442,
    name: "Demon Head Tentacles Top",
    texture: "monster_demon_head_tentacles_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_HEAD_WORM_TOP: {
    id: 443,
    name: "Demon Head Worm Top",
    texture: "monster_demon_head_worm_top",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_BAT_TOP: {
    id: 444,
    name: "Demon Wings Bat Top",
    texture: "monster_demon_wings_bat_top",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_BONES_BOTTOM: {
    id: 445,
    name: "Demon Wings Bones Bottom",
    texture: "monster_demon_wings_bones_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_BONES_TOP: {
    id: 446,
    name: "Demon Wings Bones Top",
    texture: "monster_demon_wings_bones_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_BUTTERFLY_BOTTOM: {
    id: 447,
    name: "Demon Wings Butterfly Bottom",
    texture: "monster_demon_wings_butterfly_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_BUTTERFLY_SMALL_TOP: {
    id: 448,
    name: "Demon Wings Butterfly Small Top",
    texture: "monster_demon_wings_butterfly_small_top",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_BUTTERFLY_TOP: {
    id: 449,
    name: "Demon Wings Butterfly Top",
    texture: "monster_demon_wings_butterfly_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_DEMONIC_TOP: {
    id: 450,
    name: "Demon Wings Demonic Top",
    texture: "monster_demon_wings_demonic_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_DRAGONFLY_TOP: {
    id: 451,
    name: "Demon Wings Dragonfly Top",
    texture: "monster_demon_wings_dragonfly_top",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_HOOKED_TOP: {
    id: 452,
    name: "Demon Wings Hooked Top",
    texture: "monster_demon_wings_hooked_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_KNOBS_TOP: {
    id: 453,
    name: "Demon Wings Knobs Top",
    texture: "monster_demon_wings_knobs_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_LARGE_BOTTOM: {
    id: 454,
    name: "Demon Wings Large Bottom",
    texture: "monster_demon_wings_large_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_LARGE_TOP: {
    id: 455,
    name: "Demon Wings Large Top",
    texture: "monster_demon_wings_large_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_MEDIUM_BOTTOM: {
    id: 456,
    name: "Demon Wings Medium Bottom",
    texture: "monster_demon_wings_medium_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_MEDIUM_TOP: {
    id: 457,
    name: "Demon Wings Medium Top",
    texture: "monster_demon_wings_medium_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_RED_BOTTOM: {
    id: 458,
    name: "Demon Wings Red Bottom",
    texture: "monster_demon_wings_red_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_RED_TOP: {
    id: 459,
    name: "Demon Wings Red Top",
    texture: "monster_demon_wings_red_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_SPARROW_TOP: {
    id: 460,
    name: "Demon Wings Sparrow Top",
    texture: "monster_demon_wings_sparrow_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_DEMON_WINGS_TORN_TOP: {
    id: 461,
    name: "Demon Wings Torn Top",
    texture: "monster_demon_wings_torn_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_PANDEMONIUM_DEMON: {
    id: 462,
    name: "Pandemonium Demon",
    texture: "monster_pandemonium_demon",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_PHOENIX: {
    id: 463,
    name: "Phoenix",
    texture: "monster_phoenix",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_PULSATING_LUMP: {
    id: 464,
    name: "Pulsating Lump",
    texture: "monster_pulsating_lump",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_RAVEN: {
    id: 465,
    name: "Raven",
    texture: "monster_raven",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ROCK_TROLL: {
    id: 466,
    name: "Rock Troll",
    texture: "monster_rock_troll",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ROCK_TROLL_MONK_GHOST: {
    id: 467,
    name: "Rock Troll Monk Ghost",
    texture: "monster_rock_troll_monk_ghost",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SALAMANDER_FIREBRAND: {
    id: 469,
    name: "Salamander Firebrand",
    texture: "monster_salamander_firebrand",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SALAMANDER_MYSTIC: {
    id: 470,
    name: "Salamander Mystic",
    texture: "monster_salamander_mystic",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SALAMANDER_STORMCALLER: {
    id: 471,
    name: "Salamander Stormcaller",
    texture: "monster_salamander_stormcaller",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SATYR: {
    id: 472,
    name: "Satyr",
    texture: "monster_satyr",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SHAPESHIFTER: {
    id: 473,
    name: "Shapeshifter",
    texture: "monster_shapeshifter",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SIREN: {
    id: 474,
    name: "Siren",
    texture: "monster_siren",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SIREN_WATER: {
    id: 475,
    name: "Siren Water",
    texture: "monster_siren_water",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_SLAVE_FREED: {
    id: 476,
    name: "Slave Freed",
    texture: "monster_slave_freed",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPHINX: {
    id: 477,
    name: "Sphinx",
    texture: "monster_sphinx",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPRIGGAN: {
    id: 478,
    name: "Spriggan",
    texture: "monster_spriggan",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPRIGGAN_AIR_MAGE: {
    id: 479,
    name: "Spriggan Air Mage",
    texture: "monster_spriggan_air_mage",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPRIGGAN_DEFENDER: {
    id: 480,
    name: "Spriggan Defender",
    texture: "monster_spriggan_defender",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPRIGGAN_DRUID: {
    id: 481,
    name: "Spriggan Druid",
    texture: "monster_spriggan_druid",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPRIGGAN_RIDER: {
    id: 486,
    name: "Spriggan Rider",
    texture: "monster_spriggan_rider",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPRIGGAN_BERSERKER: {
    id: 483,
    name: "Spriggan Berserker",
    texture: "monster_spriggan_berserker",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPRIGGAN_DEFENDER_SHIELDLESS: {
    id: 484,
    name: "Spriggan Defender Shieldless",
    texture: "monster_spriggan_defender_shieldless",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPRIGGAN_ENCHANTER: {
    id: 485,
    name: "Spriggan Enchanter",
    texture: "monster_spriggan_enchanter",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_AIR_ELEMENTALIST_STATUE: {
    id: 487,
    name: "Air Elementalist Statue",
    texture: "monster_air_elementalist_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BLOCK_OF_ICE: {
    id: 488,
    name: "Block Of Ice",
    texture: "monster_block_of_ice",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BLOCK_OF_ICE_2: {
    id: 489,
    name: "Block Of Ice 2",
    texture: "monster_block_of_ice_2",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CHILLING_STATUE: {
    id: 490,
    name: "Chilling Statue",
    texture: "monster_chilling_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DARK_VINE_STATUE_BASE: {
    id: 491,
    name: "Dark Vine Statue Base",
    texture: "monster_dark_vine_statue_base",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_EARTH_ELEMENTALIST_STATUE: {
    id: 492,
    name: "Earth Elementalist Statue",
    texture: "monster_earth_elementalist_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FIRE_ELEMENTALIST_STATUE: {
    id: 493,
    name: "Fire Elementalist Statue",
    texture: "monster_fire_elementalist_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FIRESPITTER_STATUE: {
    id: 494,
    name: "Firespitter Statue",
    texture: "monster_firespitter_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GUARDIAN_EYECLOSED_FLAME_1: {
    id: 495,
    name: "Guardian-Eyeclosed-Flame 1",
    texture: "monster_guardian-eyeclosed-flame_1",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GUARDIAN_EYECLOSED_FLAME_2: {
    id: 496,
    name: "Guardian-Eyeclosed-Flame 2",
    texture: "monster_guardian-eyeclosed-flame_2",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GUARDIAN_EYECLOSED_FLAME_3: {
    id: 497,
    name: "Guardian-Eyeclosed-Flame 3",
    texture: "monster_guardian-eyeclosed-flame_3",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GUARDIAN_EYECLOSED_FLAME_4: {
    id: 498,
    name: "Guardian-Eyeclosed-Flame 4",
    texture: "monster_guardian-eyeclosed-flame_4",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GUARDIAN_EYEOPEN_FLAME_1: {
    id: 499,
    name: "Guardian-Eyeopen-Flame 1",
    texture: "monster_guardian-eyeopen-flame_1",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GUARDIAN_EYEOPEN_FLAME_2: {
    id: 500,
    name: "Guardian-Eyeopen-Flame 2",
    texture: "monster_guardian-eyeopen-flame_2",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GUARDIAN_EYEOPEN_FLAME_3: {
    id: 501,
    name: "Guardian-Eyeopen-Flame 3",
    texture: "monster_guardian-eyeopen-flame_3",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GUARDIAN_EYEOPEN_FLAME_4: {
    id: 502,
    name: "Guardian-Eyeopen-Flame 4",
    texture: "monster_guardian-eyeopen-flame_4",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ICE_STATUE: {
    id: 503,
    name: "Ice Statue",
    texture: "monster_ice_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LIGHT_VINE_STATUE_BASE: {
    id: 504,
    name: "Light Vine Statue Base",
    texture: "monster_light_vine_statue_base",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OBELISK: {
    id: 505,
    name: "Obelisk",
    texture: "monster_obelisk",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ORANGE_CRYSTAL_STATUE: {
    id: 506,
    name: "Orange Crystal Statue",
    texture: "monster_orange_crystal_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OVERLAY_AXE: {
    id: 507,
    name: "Overlay Axe",
    texture: "monster_overlay_axe",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OVERLAY_BOW: {
    id: 508,
    name: "Overlay Bow",
    texture: "monster_overlay_bow",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OVERLAY_CROSSBOW: {
    id: 509,
    name: "Overlay Crossbow",
    texture: "monster_overlay_crossbow",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OVERLAY_MACE: {
    id: 510,
    name: "Overlay Mace",
    texture: "monster_overlay_mace",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OVERLAY_MAGE: {
    id: 511,
    name: "Overlay Mage",
    texture: "monster_overlay_mage",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OVERLAY_MAGE_HAT: {
    id: 512,
    name: "Overlay Mage Hat",
    texture: "monster_overlay_mage_hat",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OVERLAY_SCYTHE: {
    id: 513,
    name: "Overlay Scythe",
    texture: "monster_overlay_scythe",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OVERLAY_SWORD: {
    id: 514,
    name: "Overlay Sword",
    texture: "monster_overlay_sword",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_OVERLAY_WHIP: {
    id: 515,
    name: "Overlay Whip",
    texture: "monster_overlay_whip",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_PILLAR_OF_SALT: {
    id: 516,
    name: "Pillar Of Salt",
    texture: "monster_pillar_of_salt",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SILVER_STATUE: {
    id: 517,
    name: "Silver Statue",
    texture: "monster_silver_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SNAIL_STATUE: {
    id: 518,
    name: "Snail Statue",
    texture: "monster_snail_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SPOOKY_STATUE: {
    id: 519,
    name: "Spooky Statue",
    texture: "monster_spooky_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_STATUE_BASE: {
    id: 520,
    name: "Statue Base",
    texture: "monster_statue_base",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TRAINING_DUMMY: {
    id: 521,
    name: "Training Dummy",
    texture: "monster_training_dummy",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_WATER_ELEMENTALIST_STATUE: {
    id: 522,
    name: "Water Elementalist Statue",
    texture: "monster_water_elementalist_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_WUCAD_MU_STATUE: {
    id: 523,
    name: "Wucad Mu Statue",
    texture: "monster_wucad_mu_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ZOT_STATUE: {
    id: 524,
    name: "Zot Statue",
    texture: "monster_zot_statue",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "construct",
    isHostile: false,
    maxHP: 200,
    isControllable: false,
    blockDrops: {
      STONE: 6
    },
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_STONE_GIANT: {
    id: 525,
    name: "Stone Giant",
    texture: "monster_stone_giant",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SWAMP_DRAKE: {
    id: 526,
    name: "Swamp Drake",
    texture: "monster_swamp_drake",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_TENGU: {
    id: 527,
    name: "Tengu",
    texture: "monster_tengu",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TENGU_CONJURER: {
    id: 528,
    name: "Tengu Conjurer",
    texture: "monster_tengu_conjurer",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TENGU_REAVER: {
    id: 529,
    name: "Tengu Reaver",
    texture: "monster_tengu_reaver",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TENGU_WARRIOR: {
    id: 530,
    name: "Tengu Warrior",
    texture: "monster_tengu_warrior",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TITAN: {
    id: 531,
    name: "Titan",
    texture: "monster_titan",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TROLL: {
    id: 532,
    name: "Troll",
    texture: "monster_troll",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TWO_HEADED_OGRE: {
    id: 533,
    name: "Two Headed Ogre",
    texture: "monster_two_headed_ogre",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_AGNES: {
    id: 534,
    name: "Agnes",
    texture: "monster_agnes",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_AIZUL: {
    id: 535,
    name: "Aizul",
    texture: "monster_aizul",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ANTAEUS: {
    id: 536,
    name: "Antaeus",
    texture: "monster_antaeus",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ASMODEUS: {
    id: 537,
    name: "Asmodeus",
    texture: "monster_asmodeus",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ASMODEUS_BOTTOM: {
    id: 538,
    name: "Asmodeus Bottom",
    texture: "monster_asmodeus_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ASMODEUS_SMALL: {
    id: 539,
    name: "Asmodeus Small",
    texture: "monster_asmodeus_small",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ASMODEUS_TOP: {
    id: 540,
    name: "Asmodeus Top",
    texture: "monster_asmodeus_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_AZRAEL: {
    id: 541,
    name: "Azrael",
    texture: "monster_azrael",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BLORK_THE_ORC: {
    id: 542,
    name: "Blork The Orc",
    texture: "monster_blork_the_orc",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_BORIS: {
    id: 543,
    name: "Boris",
    texture: "monster_boris",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CEREBOV: {
    id: 544,
    name: "Cerebov",
    texture: "monster_cerebov",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CEREBOV_BOTTOM: {
    id: 545,
    name: "Cerebov Bottom",
    texture: "monster_cerebov_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CEREBOV_TOP: {
    id: 546,
    name: "Cerebov Top",
    texture: "monster_cerebov_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CHUCK: {
    id: 547,
    name: "Chuck",
    texture: "monster_chuck",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_CRAZY_YIUF: {
    id: 548,
    name: "Crazy Yiuf",
    texture: "monster_crazy_yiuf",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DISPATER: {
    id: 549,
    name: "Dispater",
    texture: "monster_dispater",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DISPATER_BOTTOM: {
    id: 550,
    name: "Dispater Bottom",
    texture: "monster_dispater_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DISPATER_SMALL: {
    id: 551,
    name: "Dispater Small",
    texture: "monster_dispater_small",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DISPATER_TOP: {
    id: 552,
    name: "Dispater Top",
    texture: "monster_dispater_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DISSOLUTION: {
    id: 553,
    name: "Dissolution",
    texture: "monster_dissolution",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DONALD: {
    id: 554,
    name: "Donald",
    texture: "monster_donald",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_DUANE: {
    id: 555,
    name: "Duane",
    texture: "monster_duane",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_EDMUND: {
    id: 556,
    name: "Edmund",
    texture: "monster_edmund",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ENCHANTRESS: {
    id: 557,
    name: "Enchantress",
    texture: "monster_enchantress",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ERESHKIGAL: {
    id: 558,
    name: "Ereshkigal",
    texture: "monster_ereshkigal",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ERESHKIGAL_BOTTOM: {
    id: 559,
    name: "Ereshkigal Bottom",
    texture: "monster_ereshkigal_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ERESHKIGAL_SMALL: {
    id: 560,
    name: "Ereshkigal Small",
    texture: "monster_ereshkigal_small",
    width: 0.6,
    height: 0.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 60,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ERESHKIGAL_TOP: {
    id: 561,
    name: "Ereshkigal Top",
    texture: "monster_ereshkigal_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ERICA: {
    id: 562,
    name: "Erica",
    texture: "monster_erica",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_EROLCHA: {
    id: 563,
    name: "Erolcha",
    texture: "monster_erolcha",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_EUSTACHIO: {
    id: 564,
    name: "Eustachio",
    texture: "monster_eustachio",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FANNAR: {
    id: 565,
    name: "Fannar",
    texture: "monster_fannar",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FRANCES: {
    id: 566,
    name: "Frances",
    texture: "monster_frances",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FRANCES_MALE: {
    id: 567,
    name: "Frances Male",
    texture: "monster_frances_male",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FRANCIS: {
    id: 568,
    name: "Francis",
    texture: "monster_francis",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_FREDERICK: {
    id: 569,
    name: "Frederick",
    texture: "monster_frederick",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GASTRONOK: {
    id: 570,
    name: "Gastronok",
    texture: "monster_gastronok",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GERYON: {
    id: 571,
    name: "Geryon",
    texture: "monster_geryon",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GIAGGOSTUONO: {
    id: 572,
    name: "Giaggostuono",
    texture: "monster_giaggostuono",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GLOORX_VLOQ: {
    id: 573,
    name: "Gloorx Vloq",
    texture: "monster_gloorx_vloq",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GLOORX_VLOQ_BOTTOM: {
    id: 574,
    name: "Gloorx Vloq Bottom",
    texture: "monster_gloorx_vloq_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GLOORX_VLOQ_TOP: {
    id: 575,
    name: "Gloorx Vloq Top",
    texture: "monster_gloorx_vloq_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GRINDER_CLEAVER: {
    id: 576,
    name: "Grinder Cleaver",
    texture: "monster_grinder_cleaver",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GRINDER: {
    id: 577,
    name: "Grinder",
    texture: "monster_grinder",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_GRUM: {
    id: 578,
    name: "Grum",
    texture: "monster_grum",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_HAROLD: {
    id: 579,
    name: "Harold",
    texture: "monster_harold",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_IGNACIO: {
    id: 580,
    name: "Ignacio",
    texture: "monster_ignacio",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_IJYB: {
    id: 581,
    name: "Ijyb",
    texture: "monster_ijyb",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ILSUIW: {
    id: 582,
    name: "Ilsuiw",
    texture: "monster_ilsuiw",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ILSUIW_WATER: {
    id: 583,
    name: "Ilsuiw Water",
    texture: "monster_ilsuiw_water",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_IRON_GIANT: {
    id: 584,
    name: "Iron Giant",
    texture: "monster_iron_giant",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JESSICA: {
    id: 585,
    name: "Jessica",
    texture: "monster_jessica",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JORGRUN: {
    id: 586,
    name: "Jorgrun",
    texture: "monster_jorgrun",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JORMUNGANDR: {
    id: 587,
    name: "Jormungandr",
    texture: "monster_jormungandr",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JORY: {
    id: 588,
    name: "Jory",
    texture: "monster_jory",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JOSEPH: {
    id: 589,
    name: "Joseph",
    texture: "monster_joseph",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JOSEPHINE: {
    id: 590,
    name: "Josephine",
    texture: "monster_josephine",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_JOZEF: {
    id: 591,
    name: "Jozef",
    texture: "monster_jozef",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_KIRKE: {
    id: 592,
    name: "Kirke",
    texture: "monster_kirke",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LAMIA: {
    id: 593,
    name: "Lamia",
    texture: "monster_lamia",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA: {
    id: 594,
    name: "Lernaean Hydra",
    texture: "monster_lernaean_hydra",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_10_TOP: {
    id: 595,
    name: "Lernaean Hydra 10 Top",
    texture: "monster_lernaean_hydra_10_top",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_1_BOTTOM: {
    id: 596,
    name: "Lernaean Hydra 1 Bottom",
    texture: "monster_lernaean_hydra_1_bottom",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_1_TOP: {
    id: 597,
    name: "Lernaean Hydra 1 Top",
    texture: "monster_lernaean_hydra_1_top",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_2_TOP: {
    id: 598,
    name: "Lernaean Hydra 2 Top",
    texture: "monster_lernaean_hydra_2_top",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_3_TOP: {
    id: 599,
    name: "Lernaean Hydra 3 Top",
    texture: "monster_lernaean_hydra_3_top",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_4_TOP: {
    id: 600,
    name: "Lernaean Hydra 4 Top",
    texture: "monster_lernaean_hydra_4_top",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_5_BOTTOM: {
    id: 601,
    name: "Lernaean Hydra 5 Bottom",
    texture: "monster_lernaean_hydra_5_bottom",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_5_TOP: {
    id: 602,
    name: "Lernaean Hydra 5 Top",
    texture: "monster_lernaean_hydra_5_top",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_6_TOP: {
    id: 603,
    name: "Lernaean Hydra 6 Top",
    texture: "monster_lernaean_hydra_6_top",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_7_BOTTOM: {
    id: 604,
    name: "Lernaean Hydra 7 Bottom",
    texture: "monster_lernaean_hydra_7_bottom",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_7_TOP: {
    id: 605,
    name: "Lernaean Hydra 7 Top",
    texture: "monster_lernaean_hydra_7_top",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_8_BOTTOM: {
    id: 606,
    name: "Lernaean Hydra 8 Bottom",
    texture: "monster_lernaean_hydra_8_bottom",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_9_BOTTOM: {
    id: 607,
    name: "Lernaean Hydra 9 Bottom",
    texture: "monster_lernaean_hydra_9_bottom",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LERNAEAN_HYDRA_9_TOP: {
    id: 608,
    name: "Lernaean Hydra 9 Top",
    texture: "monster_lernaean_hydra_9_top",
    width: 1.6,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 180,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LESHY: {
    id: 609,
    name: "Leshy",
    texture: "monster_leshy",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LOM_LOBON: {
    id: 610,
    name: "Lom Lobon",
    texture: "monster_lom_lobon",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LOM_LOBON_BOTTOM: {
    id: 611,
    name: "Lom Lobon Bottom",
    texture: "monster_lom_lobon_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LOM_LOBON_TOP: {
    id: 612,
    name: "Lom Lobon Top",
    texture: "monster_lom_lobon_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_LOUISE: {
    id: 613,
    name: "Louise",
    texture: "monster_louise",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MARA: {
    id: 614,
    name: "Mara",
    texture: "monster_mara",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MARGERY: {
    id: 615,
    name: "Margery",
    texture: "monster_margery",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MAUD: {
    id: 616,
    name: "Maud",
    texture: "monster_maud",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MAURICE: {
    id: 617,
    name: "Maurice",
    texture: "monster_maurice",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MENKAURE: {
    id: 618,
    name: "Menkaure",
    texture: "monster_menkaure",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MENNAS: {
    id: 619,
    name: "Mennas",
    texture: "monster_mennas",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MICHAEL: {
    id: 620,
    name: "Michael",
    texture: "monster_michael",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MNOLEG: {
    id: 621,
    name: "Mnoleg",
    texture: "monster_mnoleg",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MNOLEG_BOTTOM: {
    id: 622,
    name: "Mnoleg Bottom",
    texture: "monster_mnoleg_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MNOLEG_TOP: {
    id: 623,
    name: "Mnoleg Top",
    texture: "monster_mnoleg_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_MURRAY: {
    id: 624,
    name: "Murray",
    texture: "monster_murray",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NATASHA: {
    id: 625,
    name: "Natasha",
    texture: "monster_natasha",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NELLIE: {
    id: 626,
    name: "Nellie",
    texture: "monster_nellie",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NERGALLE: {
    id: 627,
    name: "Nergalle",
    texture: "monster_nergalle",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NESSOS: {
    id: 628,
    name: "Nessos",
    texture: "monster_nessos",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NORBERT: {
    id: 629,
    name: "Norbert",
    texture: "monster_norbert",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NORRIS: {
    id: 630,
    name: "Norris",
    texture: "monster_norris",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_NORRIS_WITH_BOARD: {
    id: 631,
    name: "Norris With Board",
    texture: "monster_norris_with_board",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_POLYPHEMUS: {
    id: 632,
    name: "Polyphemus",
    texture: "monster_polyphemus",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_PRINCE_RIBBIT: {
    id: 633,
    name: "Prince Ribbit",
    texture: "monster_prince_ribbit",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_PSYCHE: {
    id: 634,
    name: "Psyche",
    texture: "monster_psyche",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_PURGY: {
    id: 635,
    name: "Purgy",
    texture: "monster_purgy",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ROBIN: {
    id: 636,
    name: "Robin",
    texture: "monster_robin",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ROXANNE: {
    id: 637,
    name: "Roxanne",
    texture: "monster_roxanne",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ROYAL_JELLY: {
    id: 638,
    name: "Royal Jelly",
    texture: "monster_royal_jelly",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ROYAL_JELLY_BOTTOM: {
    id: 639,
    name: "Royal Jelly Bottom",
    texture: "monster_royal_jelly_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_ROYAL_JELLY_TOP: {
    id: 640,
    name: "Royal Jelly Top",
    texture: "monster_royal_jelly_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_RUPERT: {
    id: 641,
    name: "Rupert",
    texture: "monster_rupert",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SAINT_ROKA: {
    id: 642,
    name: "Saint Roka",
    texture: "monster_saint_roka",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SERPENT_OF_HELL_COC_BOTTOM: {
    id: 643,
    name: "Serpent Of Hell-Coc Bottom",
    texture: "monster_serpent_of_hell-coc_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SERPENT_OF_HELL_COC_TOP: {
    id: 644,
    name: "Serpent Of Hell-Coc Top",
    texture: "monster_serpent_of_hell-coc_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SERPENT_OF_HELL_DIS_BOTTOM: {
    id: 645,
    name: "Serpent Of Hell-Dis Bottom",
    texture: "monster_serpent_of_hell-dis_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SERPENT_OF_HELL_DIS_TOP: {
    id: 646,
    name: "Serpent Of Hell-Dis Top",
    texture: "monster_serpent_of_hell-dis_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SERPENT_OF_HELL_GEH_BOTTOM: {
    id: 647,
    name: "Serpent Of Hell-Geh Bottom",
    texture: "monster_serpent_of_hell-geh_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SERPENT_OF_HELL_GEH_TOP: {
    id: 648,
    name: "Serpent Of Hell-Geh Top",
    texture: "monster_serpent_of_hell-geh_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SERPENT_OF_HELL_TAR_BOTTOM: {
    id: 649,
    name: "Serpent Of Hell-Tar Bottom",
    texture: "monster_serpent_of_hell-tar_bottom",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SERPENT_OF_HELL_TAR_TOP: {
    id: 650,
    name: "Serpent Of Hell-Tar Top",
    texture: "monster_serpent_of_hell-tar_top",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SERPENT_OF_HELL: {
    id: 651,
    name: "Serpent Of Hell",
    texture: "monster_serpent_of_hell",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "demon",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_piece_of_ambrosia: 1
    }
  },
  MONSTER_MONSTER_SIGMUND: {
    id: 652,
    name: "Sigmund",
    texture: "monster_sigmund",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SNORG: {
    id: 653,
    name: "Snorg",
    texture: "monster_snorg",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SOJOBO: {
    id: 654,
    name: "Sojobo",
    texture: "monster_sojobo",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_SONJA: {
    id: 655,
    name: "Sonja",
    texture: "monster_sonja",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TERENCE: {
    id: 656,
    name: "Terence",
    texture: "monster_terence",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TIAMAT: {
    id: 657,
    name: "Tiamat",
    texture: "monster_tiamat",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TIAMAT_BLACK: {
    id: 658,
    name: "Tiamat Black",
    texture: "monster_tiamat_black",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TIAMAT_GREEN: {
    id: 659,
    name: "Tiamat Green",
    texture: "monster_tiamat_green",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TIAMAT_GREY: {
    id: 660,
    name: "Tiamat Grey",
    texture: "monster_tiamat_grey",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TIAMAT_MOTTLED: {
    id: 661,
    name: "Tiamat Mottled",
    texture: "monster_tiamat_mottled",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TIAMAT_PALE: {
    id: 662,
    name: "Tiamat Pale",
    texture: "monster_tiamat_pale",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TIAMAT_RED: {
    id: 663,
    name: "Tiamat Red",
    texture: "monster_tiamat_red",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TIAMAT_WHITE: {
    id: 664,
    name: "Tiamat White",
    texture: "monster_tiamat_white",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_TIAMAT_YELLOW: {
    id: 665,
    name: "Tiamat Yellow",
    texture: "monster_tiamat_yellow",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_URUG: {
    id: 666,
    name: "Urug",
    texture: "monster_urug",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_VASHNIA: {
    id: 667,
    name: "Vashnia",
    texture: "monster_vashnia",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_WIGLAF: {
    id: 668,
    name: "Wiglaf",
    texture: "monster_wiglaf",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_XTAHUA: {
    id: 669,
    name: "Xtahua",
    texture: "monster_xtahua",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_WATER_NYMPH: {
    id: 670,
    name: "Water Nymph",
    texture: "monster_water_nymph",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "aquatic",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_chunk: 1
    }
  },
  MONSTER_MONSTER_WIZARD: {
    id: 671,
    name: "Wizard",
    texture: "monster_wizard",
    width: 0.8,
    height: 1.6,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_YAKTAUR_MELEE: {
    id: 672,
    name: "Yaktaur-Melee",
    texture: "monster_yaktaur-melee",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_YAKTAUR_CAPTAIN_MELEE: {
    id: 673,
    name: "Yaktaur Captain-Melee",
    texture: "monster_yaktaur_captain-melee",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_YAKTAUR_CAPTAIN: {
    id: 674,
    name: "Yaktaur Captain",
    texture: "monster_yaktaur_captain",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  },
  MONSTER_MONSTER_YAKTAUR: {
    id: 675,
    name: "Yaktaur",
    texture: "monster_yaktaur",
    width: 0.9,
    height: 1.2,
    interactable: false,
    faction: "beast",
    isHostile: true,
    maxHP: 120,
    itemDrops: {
      food_meat_ration: 1
    }
  }
};
