export default {
  TITLE: "discos voadores",
  VERSION: "0.2.4",
  MOVE_SPEED: 0.1,
  CROUCH_SPEED_MULTIPLIER: 0.5,
  LOOK_SPEED: 0.002,
  JUMP_FORCE: 0.15,
  GRAVITY: 0.008,
  EDITOR_FLY_SPEED: 0.2,
  ENTITY_HEIGHT: 1.7,
  ENTITY_HEIGHT_CROUCHED: 1,
  ENTITY_RADIUS: 0.3,
  BLOCK_SIZE: 1,
  INTERACTION_RANGE: 3,
  PLACEMENT_RANGE: 5,
  ITEM_PICKUP_RANGE: 1,
  WORLD_MAX_RADIUS: 30,
  WORLD_MIN_Y: -10,
  MAX_JUMP_HEIGHT: 1,
  MAX_JUMP_DISTANCE: 1,
  PATH_UPDATE_INTERVAL: 60,
  MAX_PATH_ITERATIONS: 200,
  HOSTILE_DETECTION_RANGE: 10,
  HOSTILE_ATTACK_RANGE: 8,
  HOSTILE_SHOOT_COOLDOWN: 60,
  SHOT_DETECTION_RANGE: 20,
  VISION_RANGE: 12,
  VISION_FOV_DEG: 90,
  PROXIMITY_DETECT_RANGE: 2.4,
  FALL_DAMAGE_THRESHOLD: 3,
  FALL_DAMAGE_MULTIPLIER: 10,
  MELEE_RANGE: 2,
  MELEE_DAMAGE: 2,
  editorMapPalette: [
    {
      color: "#508c5a",
      blockKey: "FLOOR_FLOOR_DIRT_1"
    },
    {
      color: "#759e66",
      blockKey: "FLOOR_FLOOR_DIRT_0"
    },
    {
      color: "#9ab172",
      blockKey: "FLOOR_FLOOR_DIRT_FULL"
    },
    {
      color: "#bfc37f",
      blockKey: "FLOOR_FLOOR_GRASS0_DIRT_MIX_1"
    },
    {
      color: "#e4d68b",
      blockKey: "DOOR_DOOR_VGATE_SEALED_DOWN"
    },
    {
      color: "#109e897",
      blockKey: "DOOR_DOOR_VGATE_SEALED_UP"
    },
    {
      color: "#12efba4",
      blockKey: "WALL_WALL_BRICK_GRAY_0"
    },
    {
      color: "#548e5b",
      blockKey: "WALL_WALL_STONE_BRICK_6"
    }
  ]
};
