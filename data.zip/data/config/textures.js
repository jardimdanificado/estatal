export default [
  {
    key: "stone",
    url: "data/images/dcss/dungeon/wall/stone_gray_0.png"
  },
  {
    key: "grass",
    url: "data/images/dcss/dungeon/floor/dirt_full_old.png"
  },
  {
    key: "wood",
    url: "data/images/dcss/dungeon/floor/snake_1.png"
  },
  {
    key: "dirt",
    url: "data/images/dcss/dungeon/floor/dirt_0_old.png"
  },
  {
    key: "npc",
    url: "data/images/dcss/monster/human.png"
  },
  {
    key: "gold",
    url: "data/images/dcss/dungeon/wall/crystal_wall_yellow.png"
  },
  {
    key: "door",
    url: "data/images/dcss/dungeon/doors/closed_door.png"
  },
  {
    key: "sand",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_0.png"
  },
  {
    key: "38-hand",
    url: "data/images/38-hand.png"
  },
  {
    key: "item-revolver",
    url: "data/images/item-revolver.png"
  },
  {
    key: "item-38-bullet",
    url: "data/images/item-38-bullet.png"
  },
  {
    key: "item-rock",
    url: "data/images/item-rock.png"
  },
  {
    key: "rock-hand",
    url: "data/images/rock-hand.png"
  },
  {
    key: "item-cuscuz",
    url: "data/images/item-cuscuz.png"
  },
  {
    key: "cuscuz-hand",
    url: "data/images/cuscuz-hand.png"
  },
  {
    key: "ui_player_face",
    url: "data/images/ui/ui_player_face.png"
  },
  {
    key: "sensed_friendly",
    url: "data/images/ui/sensed_friendly.png"
  },
  {
    key: "sensed_friendly_unseen",
    url: "data/images/ui/sensed_friendly_unseen.png"
  },
  {
    key: "sensed_hostile",
    url: "data/images/ui/sensed_hostile.png"
  },
  {
    key: "sensed_hostile_unseen",
    url: "data/images/ui/sensed_hostile_unseen.png"
  },
  {
    key: "travel_to_1",
    url: "data/images/dcss/misc/travel_path_to_1.png"
  },
  {
    key: "travel_to_2",
    url: "data/images/dcss/misc/travel_path_to_2.png"
  },
  {
    key: "travel_to_3",
    url: "data/images/dcss/misc/travel_path_to_3.png"
  },
  {
    key: "travel_to_4",
    url: "data/images/dcss/misc/travel_path_to_4.png"
  },
  {
    key: "travel_to_5",
    url: "data/images/dcss/misc/travel_path_to_5.png"
  },
  {
    key: "travel_to_6",
    url: "data/images/dcss/misc/travel_path_to_6.png"
  },
  {
    key: "travel_to_7",
    url: "data/images/dcss/misc/travel_path_to_7.png"
  },
  {
    key: "travel_to_8",
    url: "data/images/dcss/misc/travel_path_to_8.png"
  },
  {
    key: "mdam_almost_dead",
    url: "data/images/ui/mdam_almost_dead.png"
  },
  {
    key: "mdam_severely_damaged",
    url: "data/images/ui/mdam_severely_damaged.png"
  },
  {
    key: "mdam_heavily_damaged",
    url: "data/images/ui/mdam_heavily_damaged.png"
  },
  {
    key: "mdam_moderately_damaged",
    url: "data/images/ui/mdam_moderately_damaged.png"
  },
  {
    key: "mdam_lightly_damaged",
    url: "data/images/ui/mdam_lightly_damaged.png"
  },
  {
    key: "disabled_base",
    url: "data/images/dcss/gui/skills/disabled-base.png"
  },
  {
    key: "halo",
    url: "data/images/dcss/misc/halo.png"
  },
  {
    key: "arrow_0",
    url: "data/images/dcss/effect/arrow_0.png"
  },
  {
    key: "arrow_1",
    url: "data/images/dcss/effect/arrow_1.png"
  },
  {
    key: "arrow_2",
    url: "data/images/dcss/effect/arrow_2.png"
  },
  {
    key: "arrow_3",
    url: "data/images/dcss/effect/arrow_3.png"
  },
  {
    key: "arrow_4",
    url: "data/images/dcss/effect/arrow_4.png"
  },
  {
    key: "arrow_5",
    url: "data/images/dcss/effect/arrow_5.png"
  },
  {
    key: "arrow_6",
    url: "data/images/dcss/effect/arrow_6.png"
  },
  {
    key: "arrow_7",
    url: "data/images/dcss/effect/arrow_7.png"
  },
  {
    key: "blood_red",
    url: "data/images/dcss/misc/blood/blood_red.png"
  },
  {
    key: "blood_red_0",
    url: "data/images/dcss/misc/blood/blood_red_0.png"
  },
  {
    key: "blood_red_1_old",
    url: "data/images/dcss/misc/blood/blood_red_1_old.png"
  },
  {
    key: "blood_red_1_new",
    url: "data/images/dcss/misc/blood/blood_red_1_new.png"
  },
  {
    key: "blood_red_2_old",
    url: "data/images/dcss/misc/blood/blood_red_2_old.png"
  },
  {
    key: "blood_red_2_new",
    url: "data/images/dcss/misc/blood/blood_red_2_new.png"
  },
  {
    key: "blood_red_3_old",
    url: "data/images/dcss/misc/blood/blood_red_3_old.png"
  },
  {
    key: "blood_red_3_new",
    url: "data/images/dcss/misc/blood/blood_red_3_new.png"
  },
  {
    key: "blood_red_4_old",
    url: "data/images/dcss/misc/blood/blood_red_4_old.png"
  },
  {
    key: "blood_red_4_new",
    url: "data/images/dcss/misc/blood/blood_red_4_new.png"
  },
  {
    key: "blood_red_5",
    url: "data/images/dcss/misc/blood/blood_red_5.png"
  },
  {
    key: "blood_red_6",
    url: "data/images/dcss/misc/blood/blood_red_6.png"
  },
  {
    key: "blood_red_7",
    url: "data/images/dcss/misc/blood/blood_red_7.png"
  },
  {
    key: "blood_red_8",
    url: "data/images/dcss/misc/blood/blood_red_8.png"
  },
  {
    key: "blood_red_9",
    url: "data/images/dcss/misc/blood/blood_red_9.png"
  },
  {
    key: "blood_red_10",
    url: "data/images/dcss/misc/blood/blood_red_10.png"
  },
  {
    key: "blood_red_11",
    url: "data/images/dcss/misc/blood/blood_red_11.png"
  },
  {
    key: "blood_red_12",
    url: "data/images/dcss/misc/blood/blood_red_12.png"
  },
  {
    key: "blood_red_13",
    url: "data/images/dcss/misc/blood/blood_red_13.png"
  },
  {
    key: "blood_red_14",
    url: "data/images/dcss/misc/blood/blood_red_14.png"
  },
  {
    key: "blood_red_15",
    url: "data/images/dcss/misc/blood/blood_red_15.png"
  },
  {
    key: "blood_red_16",
    url: "data/images/dcss/misc/blood/blood_red_16.png"
  },
  {
    key: "blood_red_17",
    url: "data/images/dcss/misc/blood/blood_red_17.png"
  },
  {
    key: "blood_red_18",
    url: "data/images/dcss/misc/blood/blood_red_18.png"
  },
  {
    key: "blood_red_19",
    url: "data/images/dcss/misc/blood/blood_red_19.png"
  },
  {
    key: "blood_red_20",
    url: "data/images/dcss/misc/blood/blood_red_20.png"
  },
  {
    key: "blood_red_21",
    url: "data/images/dcss/misc/blood/blood_red_21.png"
  },
  {
    key: "blood_red_22",
    url: "data/images/dcss/misc/blood/blood_red_22.png"
  },
  {
    key: "blood_red_23",
    url: "data/images/dcss/misc/blood/blood_red_23.png"
  },
  {
    key: "blood_red_24",
    url: "data/images/dcss/misc/blood/blood_red_24.png"
  },
  {
    key: "blood_red_25",
    url: "data/images/dcss/misc/blood/blood_red_25.png"
  },
  {
    key: "blood_red_26",
    url: "data/images/dcss/misc/blood/blood_red_26.png"
  },
  {
    key: "blood_red_27",
    url: "data/images/dcss/misc/blood/blood_red_27.png"
  },
  {
    key: "blood_red_28",
    url: "data/images/dcss/misc/blood/blood_red_28.png"
  },
  {
    key: "blood_red_29",
    url: "data/images/dcss/misc/blood/blood_red_29.png"
  },
  {
    key: "blood_puddle_red",
    url: "data/images/dcss/misc/blood/blood_puddle_red.png"
  },
  {
    key: "blood_puddle_red_1",
    url: "data/images/dcss/misc/blood/blood_puddle_red_1.png"
  },
  {
    key: "blood_puddle_red_2",
    url: "data/images/dcss/misc/blood/blood_puddle_red_2.png"
  },
  {
    key: "blood_puddle_red_3",
    url: "data/images/dcss/misc/blood/blood_puddle_red_3.png"
  },
  {
    key: "blood_puddle_red_4",
    url: "data/images/dcss/misc/blood/blood_puddle_red_4.png"
  },
  {
    key: "wall_blood_0_north",
    url: "data/images/dcss/misc/blood/wall_blood_0_north.png"
  },
  {
    key: "wall_blood_1_north",
    url: "data/images/dcss/misc/blood/wall_blood_1_north.png"
  },
  {
    key: "wall_blood_3_north",
    url: "data/images/dcss/misc/blood/wall_blood_3_north.png"
  },
  {
    key: "wall_blood_4_north",
    url: "data/images/dcss/misc/blood/wall_blood_4_north.png"
  },
  {
    key: "wall_blood_5_north",
    url: "data/images/dcss/misc/blood/wall_blood_5_north.png"
  },
  {
    key: "wall_blood_6_north",
    url: "data/images/dcss/misc/blood/wall_blood_6_north.png"
  },
  {
    key: "wall_blood_7_north",
    url: "data/images/dcss/misc/blood/wall_blood_7_north.png"
  },
  {
    key: "wall_blood_8_north",
    url: "data/images/dcss/misc/blood/wall_blood_8_north.png"
  },
  {
    key: "wall_blood_9_north",
    url: "data/images/dcss/misc/blood/wall_blood_9_north.png"
  },
  {
    key: "wall_blood_10_north",
    url: "data/images/dcss/misc/blood/wall_blood_10_north.png"
  },
  {
    key: "wall_blood_11_north",
    url: "data/images/dcss/misc/blood/wall_blood_11_north.png"
  },
  {
    key: "wall_blood_12_north",
    url: "data/images/dcss/misc/blood/wall_blood_12_north.png"
  },
  {
    key: "wall_blood_13_north",
    url: "data/images/dcss/misc/blood/wall_blood_13_north.png"
  },
  {
    key: "wall_blood_14_north",
    url: "data/images/dcss/misc/blood/wall_blood_14_north.png"
  },
  {
    key: "wall_blood_15_north",
    url: "data/images/dcss/misc/blood/wall_blood_15_north.png"
  },
  {
    key: "wall_blood_16_north",
    url: "data/images/dcss/misc/blood/wall_blood_16_north.png"
  },
  {
    key: "wall_blood_17_north",
    url: "data/images/dcss/misc/blood/wall_blood_17_north.png"
  },
  {
    key: "wall_blood_18_north",
    url: "data/images/dcss/misc/blood/wall_blood_18_north.png"
  },
  {
    key: "wall_abyss_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_0.png"
  },
  {
    key: "wall_abyss_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_1.png"
  },
  {
    key: "wall_abyss_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_2.png"
  },
  {
    key: "wall_abyss_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_3.png"
  },
  {
    key: "wall_abyss_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_4.png"
  },
  {
    key: "wall_abyss_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_5.png"
  },
  {
    key: "wall_abyss_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_6.png"
  },
  {
    key: "wall_abyss_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_7.png"
  },
  {
    key: "wall_abyss_blue_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_blue_0.png"
  },
  {
    key: "wall_abyss_blue_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_blue_1.png"
  },
  {
    key: "wall_abyss_blue_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_blue_2.png"
  },
  {
    key: "wall_abyss_blue_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_blue_3.png"
  },
  {
    key: "wall_abyss_blue_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_blue_4.png"
  },
  {
    key: "wall_abyss_blue_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_blue_5.png"
  },
  {
    key: "wall_abyss_blue_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_blue_6.png"
  },
  {
    key: "wall_abyss_blue_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_blue_7.png"
  },
  {
    key: "wall_abyss_brown_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_brown_0.png"
  },
  {
    key: "wall_abyss_brown_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_brown_1.png"
  },
  {
    key: "wall_abyss_brown_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_brown_2.png"
  },
  {
    key: "wall_abyss_brown_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_brown_3.png"
  },
  {
    key: "wall_abyss_brown_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_brown_4.png"
  },
  {
    key: "wall_abyss_brown_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_brown_5.png"
  },
  {
    key: "wall_abyss_brown_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_brown_6.png"
  },
  {
    key: "wall_abyss_brown_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_brown_7.png"
  },
  {
    key: "wall_abyss_cyan_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_cyan_0.png"
  },
  {
    key: "wall_abyss_cyan_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_cyan_1.png"
  },
  {
    key: "wall_abyss_cyan_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_cyan_2.png"
  },
  {
    key: "wall_abyss_cyan_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_cyan_3.png"
  },
  {
    key: "wall_abyss_cyan_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_cyan_4.png"
  },
  {
    key: "wall_abyss_cyan_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_cyan_5.png"
  },
  {
    key: "wall_abyss_cyan_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_cyan_6.png"
  },
  {
    key: "wall_abyss_cyan_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_cyan_7.png"
  },
  {
    key: "wall_abyss_darkgray_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_darkgray_0.png"
  },
  {
    key: "wall_abyss_darkgray_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_darkgray_1.png"
  },
  {
    key: "wall_abyss_darkgray_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_darkgray_2.png"
  },
  {
    key: "wall_abyss_darkgray_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_darkgray_3.png"
  },
  {
    key: "wall_abyss_darkgray_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_darkgray_4.png"
  },
  {
    key: "wall_abyss_darkgray_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_darkgray_5.png"
  },
  {
    key: "wall_abyss_darkgray_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_darkgray_6.png"
  },
  {
    key: "wall_abyss_darkgray_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_darkgray_7.png"
  },
  {
    key: "wall_abyss_green_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_green_0.png"
  },
  {
    key: "wall_abyss_green_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_green_1.png"
  },
  {
    key: "wall_abyss_green_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_green_2.png"
  },
  {
    key: "wall_abyss_green_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_green_3.png"
  },
  {
    key: "wall_abyss_green_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_green_4.png"
  },
  {
    key: "wall_abyss_green_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_green_5.png"
  },
  {
    key: "wall_abyss_green_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_green_6.png"
  },
  {
    key: "wall_abyss_green_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_green_7.png"
  },
  {
    key: "wall_abyss_lightblue_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightblue_0.png"
  },
  {
    key: "wall_abyss_lightblue_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightblue_1.png"
  },
  {
    key: "wall_abyss_lightblue_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightblue_2.png"
  },
  {
    key: "wall_abyss_lightblue_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightblue_3.png"
  },
  {
    key: "wall_abyss_lightblue_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightblue_4.png"
  },
  {
    key: "wall_abyss_lightblue_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightblue_5.png"
  },
  {
    key: "wall_abyss_lightblue_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightblue_6.png"
  },
  {
    key: "wall_abyss_lightblue_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightblue_7.png"
  },
  {
    key: "wall_abyss_lightcyan_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightcyan_0.png"
  },
  {
    key: "wall_abyss_lightcyan_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightcyan_1.png"
  },
  {
    key: "wall_abyss_lightcyan_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightcyan_2.png"
  },
  {
    key: "wall_abyss_lightcyan_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightcyan_3.png"
  },
  {
    key: "wall_abyss_lightcyan_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightcyan_4.png"
  },
  {
    key: "wall_abyss_lightcyan_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightcyan_5.png"
  },
  {
    key: "wall_abyss_lightcyan_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightcyan_6.png"
  },
  {
    key: "wall_abyss_lightcyan_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightcyan_7.png"
  },
  {
    key: "wall_abyss_lightgray_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgray_0.png"
  },
  {
    key: "wall_abyss_lightgray_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgray_1.png"
  },
  {
    key: "wall_abyss_lightgray_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgray_2.png"
  },
  {
    key: "wall_abyss_lightgray_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgray_3.png"
  },
  {
    key: "wall_abyss_lightgray_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgray_4.png"
  },
  {
    key: "wall_abyss_lightgray_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgray_5.png"
  },
  {
    key: "wall_abyss_lightgray_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgray_6.png"
  },
  {
    key: "wall_abyss_lightgray_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgray_7.png"
  },
  {
    key: "wall_abyss_lightgreen_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgreen_0.png"
  },
  {
    key: "wall_abyss_lightgreen_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgreen_1.png"
  },
  {
    key: "wall_abyss_lightgreen_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgreen_2.png"
  },
  {
    key: "wall_abyss_lightgreen_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgreen_3.png"
  },
  {
    key: "wall_abyss_lightgreen_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgreen_4.png"
  },
  {
    key: "wall_abyss_lightgreen_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgreen_5.png"
  },
  {
    key: "wall_abyss_lightgreen_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgreen_6.png"
  },
  {
    key: "wall_abyss_lightgreen_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightgreen_7.png"
  },
  {
    key: "wall_abyss_lightmagenta_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightmagenta_0.png"
  },
  {
    key: "wall_abyss_lightmagenta_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightmagenta_1.png"
  },
  {
    key: "wall_abyss_lightmagenta_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightmagenta_2.png"
  },
  {
    key: "wall_abyss_lightmagenta_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightmagenta_3.png"
  },
  {
    key: "wall_abyss_lightmagenta_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightmagenta_4.png"
  },
  {
    key: "wall_abyss_lightmagenta_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightmagenta_5.png"
  },
  {
    key: "wall_abyss_lightmagenta_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightmagenta_6.png"
  },
  {
    key: "wall_abyss_lightmagenta_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightmagenta_7.png"
  },
  {
    key: "wall_abyss_lightred_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightred_0.png"
  },
  {
    key: "wall_abyss_lightred_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightred_1.png"
  },
  {
    key: "wall_abyss_lightred_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightred_2.png"
  },
  {
    key: "wall_abyss_lightred_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightred_3.png"
  },
  {
    key: "wall_abyss_lightred_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightred_4.png"
  },
  {
    key: "wall_abyss_lightred_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightred_5.png"
  },
  {
    key: "wall_abyss_lightred_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightred_6.png"
  },
  {
    key: "wall_abyss_lightred_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_lightred_7.png"
  },
  {
    key: "wall_abyss_magenta_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_magenta_0.png"
  },
  {
    key: "wall_abyss_magenta_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_magenta_1.png"
  },
  {
    key: "wall_abyss_magenta_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_magenta_2.png"
  },
  {
    key: "wall_abyss_magenta_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_magenta_3.png"
  },
  {
    key: "wall_abyss_magenta_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_magenta_4.png"
  },
  {
    key: "wall_abyss_magenta_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_magenta_5.png"
  },
  {
    key: "wall_abyss_magenta_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_magenta_6.png"
  },
  {
    key: "wall_abyss_magenta_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_magenta_7.png"
  },
  {
    key: "wall_abyss_white_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_white_0.png"
  },
  {
    key: "wall_abyss_white_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_white_1.png"
  },
  {
    key: "wall_abyss_white_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_white_2.png"
  },
  {
    key: "wall_abyss_white_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_white_3.png"
  },
  {
    key: "wall_abyss_white_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_white_4.png"
  },
  {
    key: "wall_abyss_white_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_white_5.png"
  },
  {
    key: "wall_abyss_white_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_white_6.png"
  },
  {
    key: "wall_abyss_white_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_white_7.png"
  },
  {
    key: "wall_abyss_yellow_0",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_yellow_0.png"
  },
  {
    key: "wall_abyss_yellow_1",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_yellow_1.png"
  },
  {
    key: "wall_abyss_yellow_2",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_yellow_2.png"
  },
  {
    key: "wall_abyss_yellow_3",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_yellow_3.png"
  },
  {
    key: "wall_abyss_yellow_4",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_yellow_4.png"
  },
  {
    key: "wall_abyss_yellow_5",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_yellow_5.png"
  },
  {
    key: "wall_abyss_yellow_6",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_yellow_6.png"
  },
  {
    key: "wall_abyss_yellow_7",
    url: "data/images/dcss/dungeon/wall/abyss/abyss_yellow_7.png"
  },
  {
    key: "wall_bars_red_1",
    url: "data/images/dcss/dungeon/wall/bars_red_1.png"
  },
  {
    key: "wall_bars_red_2",
    url: "data/images/dcss/dungeon/wall/bars_red_2.png"
  },
  {
    key: "wall_bars_red_3",
    url: "data/images/dcss/dungeon/wall/bars_red_3.png"
  },
  {
    key: "wall_bars_red_4",
    url: "data/images/dcss/dungeon/wall/bars_red_4.png"
  },
  {
    key: "wall_bars_red_5",
    url: "data/images/dcss/dungeon/wall/bars_red_5.png"
  },
  {
    key: "wall_bars_red_6",
    url: "data/images/dcss/dungeon/wall/bars_red_6.png"
  },
  {
    key: "wall_bars_red_7",
    url: "data/images/dcss/dungeon/wall/bars_red_7.png"
  },
  {
    key: "wall_bars_red_8",
    url: "data/images/dcss/dungeon/wall/bars_red_8.png"
  },
  {
    key: "wall_beehives_0",
    url: "data/images/dcss/dungeon/wall/beehives_0.png"
  },
  {
    key: "wall_beehives_1",
    url: "data/images/dcss/dungeon/wall/beehives_1.png"
  },
  {
    key: "wall_beehives_2",
    url: "data/images/dcss/dungeon/wall/beehives_2.png"
  },
  {
    key: "wall_beehives_3",
    url: "data/images/dcss/dungeon/wall/beehives_3.png"
  },
  {
    key: "wall_beehives_4",
    url: "data/images/dcss/dungeon/wall/beehives_4.png"
  },
  {
    key: "wall_beehives_5",
    url: "data/images/dcss/dungeon/wall/beehives_5.png"
  },
  {
    key: "wall_beehives_6",
    url: "data/images/dcss/dungeon/wall/beehives_6.png"
  },
  {
    key: "wall_beehives_7",
    url: "data/images/dcss/dungeon/wall/beehives_7.png"
  },
  {
    key: "wall_beehives_8",
    url: "data/images/dcss/dungeon/wall/beehives_8.png"
  },
  {
    key: "wall_beehives_9",
    url: "data/images/dcss/dungeon/wall/beehives_9.png"
  },
  {
    key: "wall_brick_brown-vines_1",
    url: "data/images/dcss/dungeon/wall/brick_brown-vines_1.png"
  },
  {
    key: "wall_brick_brown-vines_2",
    url: "data/images/dcss/dungeon/wall/brick_brown-vines_2.png"
  },
  {
    key: "wall_brick_brown-vines_3",
    url: "data/images/dcss/dungeon/wall/brick_brown-vines_3.png"
  },
  {
    key: "wall_brick_brown-vines_4",
    url: "data/images/dcss/dungeon/wall/brick_brown-vines_4.png"
  },
  {
    key: "wall_brick_brown_0",
    url: "data/images/dcss/dungeon/wall/brick_brown_0.png"
  },
  {
    key: "wall_brick_brown_1",
    url: "data/images/dcss/dungeon/wall/brick_brown_1.png"
  },
  {
    key: "wall_brick_brown_2",
    url: "data/images/dcss/dungeon/wall/brick_brown_2.png"
  },
  {
    key: "wall_brick_brown_3",
    url: "data/images/dcss/dungeon/wall/brick_brown_3.png"
  },
  {
    key: "wall_brick_brown_4",
    url: "data/images/dcss/dungeon/wall/brick_brown_4.png"
  },
  {
    key: "wall_brick_brown_5",
    url: "data/images/dcss/dungeon/wall/brick_brown_5.png"
  },
  {
    key: "wall_brick_brown_6",
    url: "data/images/dcss/dungeon/wall/brick_brown_6.png"
  },
  {
    key: "wall_brick_brown_7",
    url: "data/images/dcss/dungeon/wall/brick_brown_7.png"
  },
  {
    key: "wall_brick_dark_0",
    url: "data/images/dcss/dungeon/wall/brick_dark_0.png"
  },
  {
    key: "wall_brick_dark_1",
    url: "data/images/dcss/dungeon/wall/brick_dark_1.png"
  },
  {
    key: "wall_brick_dark_2",
    url: "data/images/dcss/dungeon/wall/brick_dark_2.png"
  },
  {
    key: "wall_brick_dark_3",
    url: "data/images/dcss/dungeon/wall/brick_dark_3.png"
  },
  {
    key: "wall_brick_dark_4",
    url: "data/images/dcss/dungeon/wall/brick_dark_4.png"
  },
  {
    key: "wall_brick_dark_5",
    url: "data/images/dcss/dungeon/wall/brick_dark_5.png"
  },
  {
    key: "wall_brick_dark_6",
    url: "data/images/dcss/dungeon/wall/brick_dark_6.png"
  },
  {
    key: "wall_brick_gray_0",
    url: "data/images/dcss/dungeon/wall/brick_gray_0.png"
  },
  {
    key: "wall_brick_gray_1",
    url: "data/images/dcss/dungeon/wall/brick_gray_1.png"
  },
  {
    key: "wall_brick_gray_2",
    url: "data/images/dcss/dungeon/wall/brick_gray_2.png"
  },
  {
    key: "wall_brick_gray_3",
    url: "data/images/dcss/dungeon/wall/brick_gray_3.png"
  },
  {
    key: "wall_catacombs_0",
    url: "data/images/dcss/dungeon/wall/catacombs_0.png"
  },
  {
    key: "wall_catacombs_1",
    url: "data/images/dcss/dungeon/wall/catacombs_1.png"
  },
  {
    key: "wall_catacombs_10",
    url: "data/images/dcss/dungeon/wall/catacombs_10.png"
  },
  {
    key: "wall_catacombs_11",
    url: "data/images/dcss/dungeon/wall/catacombs_11.png"
  },
  {
    key: "wall_catacombs_12",
    url: "data/images/dcss/dungeon/wall/catacombs_12.png"
  },
  {
    key: "wall_catacombs_13",
    url: "data/images/dcss/dungeon/wall/catacombs_13.png"
  },
  {
    key: "wall_catacombs_14",
    url: "data/images/dcss/dungeon/wall/catacombs_14.png"
  },
  {
    key: "wall_catacombs_15",
    url: "data/images/dcss/dungeon/wall/catacombs_15.png"
  },
  {
    key: "wall_catacombs_2",
    url: "data/images/dcss/dungeon/wall/catacombs_2.png"
  },
  {
    key: "wall_catacombs_3",
    url: "data/images/dcss/dungeon/wall/catacombs_3.png"
  },
  {
    key: "wall_catacombs_4",
    url: "data/images/dcss/dungeon/wall/catacombs_4.png"
  },
  {
    key: "wall_catacombs_5",
    url: "data/images/dcss/dungeon/wall/catacombs_5.png"
  },
  {
    key: "wall_catacombs_6",
    url: "data/images/dcss/dungeon/wall/catacombs_6.png"
  },
  {
    key: "wall_catacombs_7",
    url: "data/images/dcss/dungeon/wall/catacombs_7.png"
  },
  {
    key: "wall_catacombs_8",
    url: "data/images/dcss/dungeon/wall/catacombs_8.png"
  },
  {
    key: "wall_catacombs_9",
    url: "data/images/dcss/dungeon/wall/catacombs_9.png"
  },
  {
    key: "wall_church_0",
    url: "data/images/dcss/dungeon/wall/church_0.png"
  },
  {
    key: "wall_church_1",
    url: "data/images/dcss/dungeon/wall/church_1.png"
  },
  {
    key: "wall_church_2",
    url: "data/images/dcss/dungeon/wall/church_2.png"
  },
  {
    key: "wall_church_3",
    url: "data/images/dcss/dungeon/wall/church_3.png"
  },
  {
    key: "wall_church_4",
    url: "data/images/dcss/dungeon/wall/church_4.png"
  },
  {
    key: "wall_cobalt_rock_1",
    url: "data/images/dcss/dungeon/wall/cobalt_rock_1.png"
  },
  {
    key: "wall_cobalt_rock_2",
    url: "data/images/dcss/dungeon/wall/cobalt_rock_2.png"
  },
  {
    key: "wall_cobalt_rock_3",
    url: "data/images/dcss/dungeon/wall/cobalt_rock_3.png"
  },
  {
    key: "wall_cobalt_rock_4",
    url: "data/images/dcss/dungeon/wall/cobalt_rock_4.png"
  },
  {
    key: "wall_cobalt_stone_1",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_1.png"
  },
  {
    key: "wall_cobalt_stone_10",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_10.png"
  },
  {
    key: "wall_cobalt_stone_11",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_11.png"
  },
  {
    key: "wall_cobalt_stone_12",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_12.png"
  },
  {
    key: "wall_cobalt_stone_2",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_2.png"
  },
  {
    key: "wall_cobalt_stone_3",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_3.png"
  },
  {
    key: "wall_cobalt_stone_4",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_4.png"
  },
  {
    key: "wall_cobalt_stone_5",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_5.png"
  },
  {
    key: "wall_cobalt_stone_6",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_6.png"
  },
  {
    key: "wall_cobalt_stone_7",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_7.png"
  },
  {
    key: "wall_cobalt_stone_8",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_8.png"
  },
  {
    key: "wall_cobalt_stone_9",
    url: "data/images/dcss/dungeon/wall/cobalt_stone_9.png"
  },
  {
    key: "wall_crystal_wall_0",
    url: "data/images/dcss/dungeon/wall/crystal_wall_0.png"
  },
  {
    key: "wall_crystal_wall_1",
    url: "data/images/dcss/dungeon/wall/crystal_wall_1.png"
  },
  {
    key: "wall_crystal_wall_11",
    url: "data/images/dcss/dungeon/wall/crystal_wall_11.png"
  },
  {
    key: "wall_crystal_wall_12",
    url: "data/images/dcss/dungeon/wall/crystal_wall_12.png"
  },
  {
    key: "wall_crystal_wall_13",
    url: "data/images/dcss/dungeon/wall/crystal_wall_13.png"
  },
  {
    key: "wall_crystal_wall_1_0",
    url: "data/images/dcss/dungeon/wall/crystal_wall_1_0.png"
  },
  {
    key: "wall_crystal_wall_2",
    url: "data/images/dcss/dungeon/wall/crystal_wall_2.png"
  },
  {
    key: "wall_crystal_wall_3",
    url: "data/images/dcss/dungeon/wall/crystal_wall_3.png"
  },
  {
    key: "wall_crystal_wall_4",
    url: "data/images/dcss/dungeon/wall/crystal_wall_4.png"
  },
  {
    key: "wall_crystal_wall_5",
    url: "data/images/dcss/dungeon/wall/crystal_wall_5.png"
  },
  {
    key: "wall_crystal_wall_6",
    url: "data/images/dcss/dungeon/wall/crystal_wall_6.png"
  },
  {
    key: "wall_crystal_wall_7",
    url: "data/images/dcss/dungeon/wall/crystal_wall_7.png"
  },
  {
    key: "wall_crystal_wall_8",
    url: "data/images/dcss/dungeon/wall/crystal_wall_8.png"
  },
  {
    key: "wall_crystal_wall_9",
    url: "data/images/dcss/dungeon/wall/crystal_wall_9.png"
  },
  {
    key: "wall_crystal_wall_blue",
    url: "data/images/dcss/dungeon/wall/crystal_wall_blue.png"
  },
  {
    key: "wall_crystal_wall_brown",
    url: "data/images/dcss/dungeon/wall/crystal_wall_brown.png"
  },
  {
    key: "wall_crystal_wall_cyan",
    url: "data/images/dcss/dungeon/wall/crystal_wall_cyan.png"
  },
  {
    key: "wall_crystal_wall_darkgray",
    url: "data/images/dcss/dungeon/wall/crystal_wall_darkgray.png"
  },
  {
    key: "wall_crystal_wall_green",
    url: "data/images/dcss/dungeon/wall/crystal_wall_green.png"
  },
  {
    key: "wall_crystal_wall_lightblue",
    url: "data/images/dcss/dungeon/wall/crystal_wall_lightblue.png"
  },
  {
    key: "wall_crystal_wall_lightcyan",
    url: "data/images/dcss/dungeon/wall/crystal_wall_lightcyan.png"
  },
  {
    key: "wall_crystal_wall_lightgray",
    url: "data/images/dcss/dungeon/wall/crystal_wall_lightgray.png"
  },
  {
    key: "wall_crystal_wall_lightgreen",
    url: "data/images/dcss/dungeon/wall/crystal_wall_lightgreen.png"
  },
  {
    key: "wall_crystal_wall_lightmagenta",
    url: "data/images/dcss/dungeon/wall/crystal_wall_lightmagenta.png"
  },
  {
    key: "wall_crystal_wall_lightred",
    url: "data/images/dcss/dungeon/wall/crystal_wall_lightred.png"
  },
  {
    key: "wall_crystal_wall_magenta",
    url: "data/images/dcss/dungeon/wall/crystal_wall_magenta.png"
  },
  {
    key: "wall_crystal_wall_red",
    url: "data/images/dcss/dungeon/wall/crystal_wall_red.png"
  },
  {
    key: "wall_crystal_wall_white",
    url: "data/images/dcss/dungeon/wall/crystal_wall_white.png"
  },
  {
    key: "wall_crystal_wall_yellow",
    url: "data/images/dcss/dungeon/wall/crystal_wall_yellow.png"
  },
  {
    key: "wall_emerald_1",
    url: "data/images/dcss/dungeon/wall/emerald_1.png"
  },
  {
    key: "wall_emerald_2",
    url: "data/images/dcss/dungeon/wall/emerald_2.png"
  },
  {
    key: "wall_emerald_3",
    url: "data/images/dcss/dungeon/wall/emerald_3.png"
  },
  {
    key: "wall_emerald_4",
    url: "data/images/dcss/dungeon/wall/emerald_4.png"
  },
  {
    key: "wall_emerald_5",
    url: "data/images/dcss/dungeon/wall/emerald_5.png"
  },
  {
    key: "wall_emerald_6",
    url: "data/images/dcss/dungeon/wall/emerald_6.png"
  },
  {
    key: "wall_emerald_7",
    url: "data/images/dcss/dungeon/wall/emerald_7.png"
  },
  {
    key: "wall_emerald_8",
    url: "data/images/dcss/dungeon/wall/emerald_8.png"
  },
  {
    key: "wall_green_crystal_wall",
    url: "data/images/dcss/dungeon/wall/green_crystal_wall.png"
  },
  {
    key: "wall_hell_1",
    url: "data/images/dcss/dungeon/wall/hell_1.png"
  },
  {
    key: "wall_hell_10",
    url: "data/images/dcss/dungeon/wall/hell_10.png"
  },
  {
    key: "wall_hell_11",
    url: "data/images/dcss/dungeon/wall/hell_11.png"
  },
  {
    key: "wall_hell_2",
    url: "data/images/dcss/dungeon/wall/hell_2.png"
  },
  {
    key: "wall_hell_3",
    url: "data/images/dcss/dungeon/wall/hell_3.png"
  },
  {
    key: "wall_hell_4",
    url: "data/images/dcss/dungeon/wall/hell_4.png"
  },
  {
    key: "wall_hell_5",
    url: "data/images/dcss/dungeon/wall/hell_5.png"
  },
  {
    key: "wall_hell_6",
    url: "data/images/dcss/dungeon/wall/hell_6.png"
  },
  {
    key: "wall_hell_7",
    url: "data/images/dcss/dungeon/wall/hell_7.png"
  },
  {
    key: "wall_hell_8",
    url: "data/images/dcss/dungeon/wall/hell_8.png"
  },
  {
    key: "wall_hell_9",
    url: "data/images/dcss/dungeon/wall/hell_9.png"
  },
  {
    key: "wall_hive_0",
    url: "data/images/dcss/dungeon/wall/hive_0.png"
  },
  {
    key: "wall_hive_1",
    url: "data/images/dcss/dungeon/wall/hive_1.png"
  },
  {
    key: "wall_hive_2",
    url: "data/images/dcss/dungeon/wall/hive_2.png"
  },
  {
    key: "wall_hive_3",
    url: "data/images/dcss/dungeon/wall/hive_3.png"
  },
  {
    key: "wall_lab-metal_0",
    url: "data/images/dcss/dungeon/wall/lab-metal_0.png"
  },
  {
    key: "wall_lab-metal_1",
    url: "data/images/dcss/dungeon/wall/lab-metal_1.png"
  },
  {
    key: "wall_lab-metal_2",
    url: "data/images/dcss/dungeon/wall/lab-metal_2.png"
  },
  {
    key: "wall_lab-metal_3",
    url: "data/images/dcss/dungeon/wall/lab-metal_3.png"
  },
  {
    key: "wall_lab-metal_4",
    url: "data/images/dcss/dungeon/wall/lab-metal_4.png"
  },
  {
    key: "wall_lab-metal_5",
    url: "data/images/dcss/dungeon/wall/lab-metal_5.png"
  },
  {
    key: "wall_lab-metal_6",
    url: "data/images/dcss/dungeon/wall/lab-metal_6.png"
  },
  {
    key: "wall_lab-rock_0",
    url: "data/images/dcss/dungeon/wall/lab-rock_0.png"
  },
  {
    key: "wall_lab-rock_1",
    url: "data/images/dcss/dungeon/wall/lab-rock_1.png"
  },
  {
    key: "wall_lab-rock_2",
    url: "data/images/dcss/dungeon/wall/lab-rock_2.png"
  },
  {
    key: "wall_lab-rock_3",
    url: "data/images/dcss/dungeon/wall/lab-rock_3.png"
  },
  {
    key: "wall_lab-stone_0",
    url: "data/images/dcss/dungeon/wall/lab-stone_0.png"
  },
  {
    key: "wall_lab-stone_1",
    url: "data/images/dcss/dungeon/wall/lab-stone_1.png"
  },
  {
    key: "wall_lab-stone_2",
    url: "data/images/dcss/dungeon/wall/lab-stone_2.png"
  },
  {
    key: "wall_lab-stone_3",
    url: "data/images/dcss/dungeon/wall/lab-stone_3.png"
  },
  {
    key: "wall_lab-stone_4",
    url: "data/images/dcss/dungeon/wall/lab-stone_4.png"
  },
  {
    key: "wall_lab-stone_5",
    url: "data/images/dcss/dungeon/wall/lab-stone_5.png"
  },
  {
    key: "wall_lair_0",
    url: "data/images/dcss/dungeon/wall/lair_0_old.png"
  },
  {
    key: "wall_lair_1",
    url: "data/images/dcss/dungeon/wall/lair_1_old.png"
  },
  {
    key: "wall_lair_2",
    url: "data/images/dcss/dungeon/wall/lair_2_old.png"
  },
  {
    key: "wall_lair_3",
    url: "data/images/dcss/dungeon/wall/lair_3_old.png"
  },
  {
    key: "wall_marble_wall_1",
    url: "data/images/dcss/dungeon/wall/marble_wall_1.png"
  },
  {
    key: "wall_marble_wall_10",
    url: "data/images/dcss/dungeon/wall/marble_wall_10.png"
  },
  {
    key: "wall_marble_wall_11",
    url: "data/images/dcss/dungeon/wall/marble_wall_11.png"
  },
  {
    key: "wall_marble_wall_12",
    url: "data/images/dcss/dungeon/wall/marble_wall_12.png"
  },
  {
    key: "wall_marble_wall_2",
    url: "data/images/dcss/dungeon/wall/marble_wall_2.png"
  },
  {
    key: "wall_marble_wall_3",
    url: "data/images/dcss/dungeon/wall/marble_wall_3.png"
  },
  {
    key: "wall_marble_wall_4",
    url: "data/images/dcss/dungeon/wall/marble_wall_4.png"
  },
  {
    key: "wall_marble_wall_5",
    url: "data/images/dcss/dungeon/wall/marble_wall_5.png"
  },
  {
    key: "wall_marble_wall_6",
    url: "data/images/dcss/dungeon/wall/marble_wall_6.png"
  },
  {
    key: "wall_marble_wall_7",
    url: "data/images/dcss/dungeon/wall/marble_wall_7.png"
  },
  {
    key: "wall_marble_wall_8",
    url: "data/images/dcss/dungeon/wall/marble_wall_8.png"
  },
  {
    key: "wall_marble_wall_9",
    url: "data/images/dcss/dungeon/wall/marble_wall_9.png"
  },
  {
    key: "wall_metal_wall",
    url: "data/images/dcss/dungeon/wall/metal_wall.png"
  },
  {
    key: "wall_metal_wall_brown",
    url: "data/images/dcss/dungeon/wall/metal_wall_brown.png"
  },
  {
    key: "wall_metal_wall_cracked",
    url: "data/images/dcss/dungeon/wall/metal_wall_cracked.png"
  },
  {
    key: "wall_metal_wall_white_0",
    url: "data/images/dcss/dungeon/wall/metal_wall_white_0.png"
  },
  {
    key: "wall_metal_wall_white_1",
    url: "data/images/dcss/dungeon/wall/metal_wall_white_1.png"
  },
  {
    key: "wall_metal_wall_white_2",
    url: "data/images/dcss/dungeon/wall/metal_wall_white_2.png"
  },
  {
    key: "wall_mirrored_wall",
    url: "data/images/dcss/dungeon/wall/mirrored_wall_old.png"
  },
  {
    key: "wall_orc_0",
    url: "data/images/dcss/dungeon/wall/orc_0.png"
  },
  {
    key: "wall_orc_1",
    url: "data/images/dcss/dungeon/wall/orc_1.png"
  },
  {
    key: "wall_orc_10",
    url: "data/images/dcss/dungeon/wall/orc_10.png"
  },
  {
    key: "wall_orc_11",
    url: "data/images/dcss/dungeon/wall/orc_11.png"
  },
  {
    key: "wall_orc_2",
    url: "data/images/dcss/dungeon/wall/orc_2.png"
  },
  {
    key: "wall_orc_3",
    url: "data/images/dcss/dungeon/wall/orc_3.png"
  },
  {
    key: "wall_orc_4",
    url: "data/images/dcss/dungeon/wall/orc_4.png"
  },
  {
    key: "wall_orc_5",
    url: "data/images/dcss/dungeon/wall/orc_5.png"
  },
  {
    key: "wall_orc_6",
    url: "data/images/dcss/dungeon/wall/orc_6.png"
  },
  {
    key: "wall_orc_7",
    url: "data/images/dcss/dungeon/wall/orc_7.png"
  },
  {
    key: "wall_orc_8",
    url: "data/images/dcss/dungeon/wall/orc_8.png"
  },
  {
    key: "wall_orc_9",
    url: "data/images/dcss/dungeon/wall/orc_9.png"
  },
  {
    key: "wall_pebble_red_0",
    url: "data/images/dcss/dungeon/wall/pebble_red_0_old.png"
  },
  {
    key: "wall_pebble_red_1",
    url: "data/images/dcss/dungeon/wall/pebble_red_1_old.png"
  },
  {
    key: "wall_pebble_red_2",
    url: "data/images/dcss/dungeon/wall/pebble_red_2_old.png"
  },
  {
    key: "wall_pebble_red_3",
    url: "data/images/dcss/dungeon/wall/pebble_red_3_old.png"
  },
  {
    key: "wall_permarock_clear_red_0",
    url: "data/images/dcss/dungeon/wall/permarock_clear_red_0.png"
  },
  {
    key: "wall_permarock_red_0",
    url: "data/images/dcss/dungeon/wall/permarock_red_0.png"
  },
  {
    key: "wall_relief_0",
    url: "data/images/dcss/dungeon/wall/relief_0.png"
  },
  {
    key: "wall_relief_1",
    url: "data/images/dcss/dungeon/wall/relief_1.png"
  },
  {
    key: "wall_relief_2",
    url: "data/images/dcss/dungeon/wall/relief_2.png"
  },
  {
    key: "wall_relief_3",
    url: "data/images/dcss/dungeon/wall/relief_3.png"
  },
  {
    key: "wall_relief_brown_0",
    url: "data/images/dcss/dungeon/wall/relief_brown_0.png"
  },
  {
    key: "wall_relief_brown_1",
    url: "data/images/dcss/dungeon/wall/relief_brown_1.png"
  },
  {
    key: "wall_relief_brown_2",
    url: "data/images/dcss/dungeon/wall/relief_brown_2.png"
  },
  {
    key: "wall_relief_brown_3",
    url: "data/images/dcss/dungeon/wall/relief_brown_3.png"
  },
  {
    key: "wall_sandstone_wall_0",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_0.png"
  },
  {
    key: "wall_sandstone_wall_1",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_1.png"
  },
  {
    key: "wall_sandstone_wall_2",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_2.png"
  },
  {
    key: "wall_sandstone_wall_3",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_3.png"
  },
  {
    key: "wall_sandstone_wall_4",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_4.png"
  },
  {
    key: "wall_sandstone_wall_5",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_5.png"
  },
  {
    key: "wall_sandstone_wall_6",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_6.png"
  },
  {
    key: "wall_sandstone_wall_7",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_7.png"
  },
  {
    key: "wall_sandstone_wall_8",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_8.png"
  },
  {
    key: "wall_sandstone_wall_9",
    url: "data/images/dcss/dungeon/wall/sandstone_wall_9.png"
  },
  {
    key: "wall_shadow_east",
    url: "data/images/dcss/dungeon/wall/shadow_east.png"
  },
  {
    key: "wall_shadow_east_darker",
    url: "data/images/dcss/dungeon/wall/shadow_east_darker.png"
  },
  {
    key: "wall_shadow_east_top",
    url: "data/images/dcss/dungeon/wall/shadow_east_top.png"
  },
  {
    key: "wall_shadow_east_top_darker",
    url: "data/images/dcss/dungeon/wall/shadow_east_top_darker.png"
  },
  {
    key: "wall_shadow_north",
    url: "data/images/dcss/dungeon/wall/shadow_north.png"
  },
  {
    key: "wall_shadow_north_darker",
    url: "data/images/dcss/dungeon/wall/shadow_north_darker.png"
  },
  {
    key: "wall_shadow_northeast",
    url: "data/images/dcss/dungeon/wall/shadow_northeast.png"
  },
  {
    key: "wall_shadow_northeast_darker",
    url: "data/images/dcss/dungeon/wall/shadow_northeast_darker.png"
  },
  {
    key: "wall_shadow_northwest",
    url: "data/images/dcss/dungeon/wall/shadow_northwest.png"
  },
  {
    key: "wall_shadow_northwest_darker",
    url: "data/images/dcss/dungeon/wall/shadow_northwest_darker.png"
  },
  {
    key: "wall_shadow_west",
    url: "data/images/dcss/dungeon/wall/shadow_west.png"
  },
  {
    key: "wall_shadow_west_darker",
    url: "data/images/dcss/dungeon/wall/shadow_west_darker.png"
  },
  {
    key: "wall_shadow_west_top",
    url: "data/images/dcss/dungeon/wall/shadow_west_top.png"
  },
  {
    key: "wall_shadow_west_top_darker",
    url: "data/images/dcss/dungeon/wall/shadow_west_top_darker.png"
  },
  {
    key: "wall_shoals_wall_1",
    url: "data/images/dcss/dungeon/wall/shoals_wall_1.png"
  },
  {
    key: "wall_shoals_wall_2",
    url: "data/images/dcss/dungeon/wall/shoals_wall_2.png"
  },
  {
    key: "wall_shoals_wall_3",
    url: "data/images/dcss/dungeon/wall/shoals_wall_3.png"
  },
  {
    key: "wall_shoals_wall_4",
    url: "data/images/dcss/dungeon/wall/shoals_wall_4.png"
  },
  {
    key: "wall_silver_wall",
    url: "data/images/dcss/dungeon/wall/silver_wall.png"
  },
  {
    key: "wall_slime_0",
    url: "data/images/dcss/dungeon/wall/slime_0_old.png"
  },
  {
    key: "wall_slime_1",
    url: "data/images/dcss/dungeon/wall/slime_1_old.png"
  },
  {
    key: "wall_slime_2",
    url: "data/images/dcss/dungeon/wall/slime_2_old.png"
  },
  {
    key: "wall_slime_3",
    url: "data/images/dcss/dungeon/wall/slime_3_old.png"
  },
  {
    key: "wall_slime_4",
    url: "data/images/dcss/dungeon/wall/slime_4.png"
  },
  {
    key: "wall_slime_5",
    url: "data/images/dcss/dungeon/wall/slime_5.png"
  },
  {
    key: "wall_slime_6",
    url: "data/images/dcss/dungeon/wall/slime_6.png"
  },
  {
    key: "wall_slime_7",
    url: "data/images/dcss/dungeon/wall/slime_7.png"
  },
  {
    key: "wall_slime_stone_0",
    url: "data/images/dcss/dungeon/wall/slime_stone_0.png"
  },
  {
    key: "wall_slime_stone_1",
    url: "data/images/dcss/dungeon/wall/slime_stone_1.png"
  },
  {
    key: "wall_slime_stone_2",
    url: "data/images/dcss/dungeon/wall/slime_stone_2.png"
  },
  {
    key: "wall_snake_0",
    url: "data/images/dcss/dungeon/wall/snake_0.png"
  },
  {
    key: "wall_snake_1",
    url: "data/images/dcss/dungeon/wall/snake_1.png"
  },
  {
    key: "wall_snake_2",
    url: "data/images/dcss/dungeon/wall/snake_2.png"
  },
  {
    key: "wall_snake_3",
    url: "data/images/dcss/dungeon/wall/snake_3.png"
  },
  {
    key: "wall_snake_4",
    url: "data/images/dcss/dungeon/wall/snake_4.png"
  },
  {
    key: "wall_snake_5",
    url: "data/images/dcss/dungeon/wall/snake_5.png"
  },
  {
    key: "wall_snake_6",
    url: "data/images/dcss/dungeon/wall/snake_6.png"
  },
  {
    key: "wall_snake_7",
    url: "data/images/dcss/dungeon/wall/snake_7.png"
  },
  {
    key: "wall_snake_8",
    url: "data/images/dcss/dungeon/wall/snake_8.png"
  },
  {
    key: "wall_snake_9",
    url: "data/images/dcss/dungeon/wall/snake_9.png"
  },
  {
    key: "wall_stone2_brown_2",
    url: "data/images/dcss/dungeon/wall/stone2_brown_2_old.png"
  },
  {
    key: "wall_stone2_brown_3",
    url: "data/images/dcss/dungeon/wall/stone2_brown_3_old.png"
  },
  {
    key: "wall_stone2_dark_2",
    url: "data/images/dcss/dungeon/wall/stone2_dark_2_old.png"
  },
  {
    key: "wall_stone2_dark_3",
    url: "data/images/dcss/dungeon/wall/stone2_dark_3_old.png"
  },
  {
    key: "wall_stone2_gray_2",
    url: "data/images/dcss/dungeon/wall/stone2_gray_2_old.png"
  },
  {
    key: "wall_stone2_gray_3",
    url: "data/images/dcss/dungeon/wall/stone2_gray_3_old.png"
  },
  {
    key: "wall_stone_2_brown0",
    url: "data/images/dcss/dungeon/wall/stone_2_brown0.png"
  },
  {
    key: "wall_stone_2_brown1",
    url: "data/images/dcss/dungeon/wall/stone_2_brown1.png"
  },
  {
    key: "wall_stone_2_brown_0",
    url: "data/images/dcss/dungeon/wall/stone_2_brown_0.png"
  },
  {
    key: "wall_stone_2_brown_1",
    url: "data/images/dcss/dungeon/wall/stone_2_brown_1.png"
  },
  {
    key: "wall_stone_2_dark0",
    url: "data/images/dcss/dungeon/wall/stone_2_dark0.png"
  },
  {
    key: "wall_stone_2_dark1",
    url: "data/images/dcss/dungeon/wall/stone_2_dark1.png"
  },
  {
    key: "wall_stone_2_dark_0",
    url: "data/images/dcss/dungeon/wall/stone_2_dark_0.png"
  },
  {
    key: "wall_stone_2_dark_1",
    url: "data/images/dcss/dungeon/wall/stone_2_dark_1.png"
  },
  {
    key: "wall_stone_2_gray0",
    url: "data/images/dcss/dungeon/wall/stone_2_gray0.png"
  },
  {
    key: "wall_stone_2_gray1",
    url: "data/images/dcss/dungeon/wall/stone_2_gray1.png"
  },
  {
    key: "wall_stone_2_gray_0",
    url: "data/images/dcss/dungeon/wall/stone_2_gray_0.png"
  },
  {
    key: "wall_stone_2_gray_1",
    url: "data/images/dcss/dungeon/wall/stone_2_gray_1.png"
  },
  {
    key: "wall_stone_black_marked_0",
    url: "data/images/dcss/dungeon/wall/stone_black_marked_0.png"
  },
  {
    key: "wall_stone_black_marked_1",
    url: "data/images/dcss/dungeon/wall/stone_black_marked_1.png"
  },
  {
    key: "wall_stone_black_marked_2",
    url: "data/images/dcss/dungeon/wall/stone_black_marked_2.png"
  },
  {
    key: "wall_stone_black_marked_3",
    url: "data/images/dcss/dungeon/wall/stone_black_marked_3.png"
  },
  {
    key: "wall_stone_black_marked_4",
    url: "data/images/dcss/dungeon/wall/stone_black_marked_4.png"
  },
  {
    key: "wall_stone_black_marked_5",
    url: "data/images/dcss/dungeon/wall/stone_black_marked_5.png"
  },
  {
    key: "wall_stone_black_marked_6",
    url: "data/images/dcss/dungeon/wall/stone_black_marked_6.png"
  },
  {
    key: "wall_stone_black_marked_7",
    url: "data/images/dcss/dungeon/wall/stone_black_marked_7.png"
  },
  {
    key: "wall_stone_black_marked_8",
    url: "data/images/dcss/dungeon/wall/stone_black_marked_8.png"
  },
  {
    key: "wall_stone_brick_1",
    url: "data/images/dcss/dungeon/wall/stone_brick_1.png"
  },
  {
    key: "wall_stone_brick_10",
    url: "data/images/dcss/dungeon/wall/stone_brick_10.png"
  },
  {
    key: "wall_stone_brick_11",
    url: "data/images/dcss/dungeon/wall/stone_brick_11.png"
  },
  {
    key: "wall_stone_brick_12",
    url: "data/images/dcss/dungeon/wall/stone_brick_12.png"
  },
  {
    key: "wall_stone_brick_2",
    url: "data/images/dcss/dungeon/wall/stone_brick_2.png"
  },
  {
    key: "wall_stone_brick_3",
    url: "data/images/dcss/dungeon/wall/stone_brick_3.png"
  },
  {
    key: "wall_stone_brick_4",
    url: "data/images/dcss/dungeon/wall/stone_brick_4.png"
  },
  {
    key: "wall_stone_brick_5",
    url: "data/images/dcss/dungeon/wall/stone_brick_5.png"
  },
  {
    key: "wall_stone_brick_6",
    url: "data/images/dcss/dungeon/wall/stone_brick_6.png"
  },
  {
    key: "wall_stone_brick_7",
    url: "data/images/dcss/dungeon/wall/stone_brick_7.png"
  },
  {
    key: "wall_stone_brick_8",
    url: "data/images/dcss/dungeon/wall/stone_brick_8.png"
  },
  {
    key: "wall_stone_brick_9",
    url: "data/images/dcss/dungeon/wall/stone_brick_9.png"
  },
  {
    key: "wall_stone_dark_0",
    url: "data/images/dcss/dungeon/wall/stone_dark_0.png"
  },
  {
    key: "wall_stone_dark_1",
    url: "data/images/dcss/dungeon/wall/stone_dark_1.png"
  },
  {
    key: "wall_stone_dark_2",
    url: "data/images/dcss/dungeon/wall/stone_dark_2.png"
  },
  {
    key: "wall_stone_dark_3",
    url: "data/images/dcss/dungeon/wall/stone_dark_3.png"
  },
  {
    key: "wall_stone_gray_0",
    url: "data/images/dcss/dungeon/wall/stone_gray_0.png"
  },
  {
    key: "wall_stone_gray_1",
    url: "data/images/dcss/dungeon/wall/stone_gray_1.png"
  },
  {
    key: "wall_stone_gray_2",
    url: "data/images/dcss/dungeon/wall/stone_gray_2.png"
  },
  {
    key: "wall_stone_gray_3",
    url: "data/images/dcss/dungeon/wall/stone_gray_3.png"
  },
  {
    key: "wall_tomb_0",
    url: "data/images/dcss/dungeon/wall/tomb_0.png"
  },
  {
    key: "wall_tomb_1",
    url: "data/images/dcss/dungeon/wall/tomb_1.png"
  },
  {
    key: "wall_tomb_2",
    url: "data/images/dcss/dungeon/wall/tomb_2.png"
  },
  {
    key: "wall_tomb_3",
    url: "data/images/dcss/dungeon/wall/tomb_3.png"
  },
  {
    key: "wall_transparent_flesh",
    url: "data/images/dcss/dungeon/wall/transparent_flesh.png"
  },
  {
    key: "wall_transparent_stone",
    url: "data/images/dcss/dungeon/wall/transparent_stone.png"
  },
  {
    key: "wall_transparent_wall",
    url: "data/images/dcss/dungeon/wall/transparent_wall_old.png"
  },
  {
    key: "wall_undead_0",
    url: "data/images/dcss/dungeon/wall/undead_0.png"
  },
  {
    key: "wall_undead_1",
    url: "data/images/dcss/dungeon/wall/undead_1.png"
  },
  {
    key: "wall_undead_2",
    url: "data/images/dcss/dungeon/wall/undead_2.png"
  },
  {
    key: "wall_undead_3",
    url: "data/images/dcss/dungeon/wall/undead_3.png"
  },
  {
    key: "wall_undead_brown_0",
    url: "data/images/dcss/dungeon/wall/undead_brown_0.png"
  },
  {
    key: "wall_undead_brown_1",
    url: "data/images/dcss/dungeon/wall/undead_brown_1.png"
  },
  {
    key: "wall_undead_brown_2",
    url: "data/images/dcss/dungeon/wall/undead_brown_2.png"
  },
  {
    key: "wall_undead_brown_3",
    url: "data/images/dcss/dungeon/wall/undead_brown_3.png"
  },
  {
    key: "wall_vault_0",
    url: "data/images/dcss/dungeon/wall/vault_0.png"
  },
  {
    key: "wall_vault_1",
    url: "data/images/dcss/dungeon/wall/vault_1.png"
  },
  {
    key: "wall_vault_2",
    url: "data/images/dcss/dungeon/wall/vault_2.png"
  },
  {
    key: "wall_vault_3",
    url: "data/images/dcss/dungeon/wall/vault_3.png"
  },
  {
    key: "wall_volcanic_wall_0",
    url: "data/images/dcss/dungeon/wall/volcanic_wall_0.png"
  },
  {
    key: "wall_volcanic_wall_1",
    url: "data/images/dcss/dungeon/wall/volcanic_wall_1.png"
  },
  {
    key: "wall_volcanic_wall_2",
    url: "data/images/dcss/dungeon/wall/volcanic_wall_2.png"
  },
  {
    key: "wall_volcanic_wall_3",
    url: "data/images/dcss/dungeon/wall/volcanic_wall_3.png"
  },
  {
    key: "wall_volcanic_wall_4",
    url: "data/images/dcss/dungeon/wall/volcanic_wall_4.png"
  },
  {
    key: "wall_volcanic_wall_5",
    url: "data/images/dcss/dungeon/wall/volcanic_wall_5.png"
  },
  {
    key: "wall_volcanic_wall_6",
    url: "data/images/dcss/dungeon/wall/volcanic_wall_6.png"
  },
  {
    key: "wall_wall_flesh_0",
    url: "data/images/dcss/dungeon/wall/wall_flesh_0.png"
  },
  {
    key: "wall_wall_flesh_1",
    url: "data/images/dcss/dungeon/wall/wall_flesh_1.png"
  },
  {
    key: "wall_wall_flesh_2",
    url: "data/images/dcss/dungeon/wall/wall_flesh_2.png"
  },
  {
    key: "wall_wall_flesh_3",
    url: "data/images/dcss/dungeon/wall/wall_flesh_3.png"
  },
  {
    key: "wall_wall_flesh_4",
    url: "data/images/dcss/dungeon/wall/wall_flesh_4.png"
  },
  {
    key: "wall_wall_flesh_5",
    url: "data/images/dcss/dungeon/wall/wall_flesh_5.png"
  },
  {
    key: "wall_wall_flesh_6",
    url: "data/images/dcss/dungeon/wall/wall_flesh_6.png"
  },
  {
    key: "wall_wall_vines_0",
    url: "data/images/dcss/dungeon/wall/wall_vines_0.png"
  },
  {
    key: "wall_wall_vines_1",
    url: "data/images/dcss/dungeon/wall/wall_vines_1.png"
  },
  {
    key: "wall_wall_vines_2",
    url: "data/images/dcss/dungeon/wall/wall_vines_2.png"
  },
  {
    key: "wall_wall_vines_3",
    url: "data/images/dcss/dungeon/wall/wall_vines_3.png"
  },
  {
    key: "wall_wall_vines_4",
    url: "data/images/dcss/dungeon/wall/wall_vines_4.png"
  },
  {
    key: "wall_wall_vines_5",
    url: "data/images/dcss/dungeon/wall/wall_vines_5.png"
  },
  {
    key: "wall_wall_vines_6",
    url: "data/images/dcss/dungeon/wall/wall_vines_6.png"
  },
  {
    key: "wall_wall_yellow_rock_0",
    url: "data/images/dcss/dungeon/wall/wall_yellow_rock_0.png"
  },
  {
    key: "wall_wall_yellow_rock_1",
    url: "data/images/dcss/dungeon/wall/wall_yellow_rock_1.png"
  },
  {
    key: "wall_wall_yellow_rock_2",
    url: "data/images/dcss/dungeon/wall/wall_yellow_rock_2.png"
  },
  {
    key: "wall_wall_yellow_rock_3",
    url: "data/images/dcss/dungeon/wall/wall_yellow_rock_3.png"
  },
  {
    key: "wall_wax_wall",
    url: "data/images/dcss/dungeon/wall/wax_wall_old.png"
  },
  {
    key: "wall_zot_blue_0",
    url: "data/images/dcss/dungeon/wall/zot_blue_0_old.png"
  },
  {
    key: "wall_zot_blue_1",
    url: "data/images/dcss/dungeon/wall/zot_blue_1_old.png"
  },
  {
    key: "wall_zot_blue_2",
    url: "data/images/dcss/dungeon/wall/zot_blue_2_old.png"
  },
  {
    key: "wall_zot_blue_3",
    url: "data/images/dcss/dungeon/wall/zot_blue_3_old.png"
  },
  {
    key: "floor_acidic_floor_0",
    url: "data/images/dcss/dungeon/floor/acidic_floor_0.png"
  },
  {
    key: "floor_acidic_floor_1",
    url: "data/images/dcss/dungeon/floor/acidic_floor_1.png"
  },
  {
    key: "floor_acidic_floor_2",
    url: "data/images/dcss/dungeon/floor/acidic_floor_2.png"
  },
  {
    key: "floor_acidic_floor_3",
    url: "data/images/dcss/dungeon/floor/acidic_floor_3.png"
  },
  {
    key: "floor_black_cobalt_1",
    url: "data/images/dcss/dungeon/floor/black_cobalt_1.png"
  },
  {
    key: "floor_black_cobalt_10",
    url: "data/images/dcss/dungeon/floor/black_cobalt_10.png"
  },
  {
    key: "floor_black_cobalt_11",
    url: "data/images/dcss/dungeon/floor/black_cobalt_11.png"
  },
  {
    key: "floor_black_cobalt_12",
    url: "data/images/dcss/dungeon/floor/black_cobalt_12.png"
  },
  {
    key: "floor_black_cobalt_2",
    url: "data/images/dcss/dungeon/floor/black_cobalt_2.png"
  },
  {
    key: "floor_black_cobalt_3",
    url: "data/images/dcss/dungeon/floor/black_cobalt_3.png"
  },
  {
    key: "floor_black_cobalt_4",
    url: "data/images/dcss/dungeon/floor/black_cobalt_4.png"
  },
  {
    key: "floor_black_cobalt_5",
    url: "data/images/dcss/dungeon/floor/black_cobalt_5.png"
  },
  {
    key: "floor_black_cobalt_6",
    url: "data/images/dcss/dungeon/floor/black_cobalt_6.png"
  },
  {
    key: "floor_black_cobalt_7",
    url: "data/images/dcss/dungeon/floor/black_cobalt_7.png"
  },
  {
    key: "floor_black_cobalt_8",
    url: "data/images/dcss/dungeon/floor/black_cobalt_8.png"
  },
  {
    key: "floor_black_cobalt_9",
    url: "data/images/dcss/dungeon/floor/black_cobalt_9.png"
  },
  {
    key: "floor_bog_green_0",
    url: "data/images/dcss/dungeon/floor/bog_green_0_old.png"
  },
  {
    key: "floor_bog_green_1",
    url: "data/images/dcss/dungeon/floor/bog_green_1_old.png"
  },
  {
    key: "floor_bog_green_2",
    url: "data/images/dcss/dungeon/floor/bog_green_2_old.png"
  },
  {
    key: "floor_bog_green_3",
    url: "data/images/dcss/dungeon/floor/bog_green_3_old.png"
  },
  {
    key: "floor_cage_0",
    url: "data/images/dcss/dungeon/floor/cage_0.png"
  },
  {
    key: "floor_cage_1",
    url: "data/images/dcss/dungeon/floor/cage_1.png"
  },
  {
    key: "floor_cage_2",
    url: "data/images/dcss/dungeon/floor/cage_2.png"
  },
  {
    key: "floor_cage_3",
    url: "data/images/dcss/dungeon/floor/cage_3.png"
  },
  {
    key: "floor_cage_4",
    url: "data/images/dcss/dungeon/floor/cage_4.png"
  },
  {
    key: "floor_cage_5",
    url: "data/images/dcss/dungeon/floor/cage_5.png"
  },
  {
    key: "floor_cobble_blood_10",
    url: "data/images/dcss/dungeon/floor/cobble_blood_10_old.png"
  },
  {
    key: "floor_cobble_blood_11",
    url: "data/images/dcss/dungeon/floor/cobble_blood_11_old.png"
  },
  {
    key: "floor_cobble_blood_12",
    url: "data/images/dcss/dungeon/floor/cobble_blood_12_old.png"
  },
  {
    key: "floor_cobble_blood_1",
    url: "data/images/dcss/dungeon/floor/cobble_blood_1_old.png"
  },
  {
    key: "floor_cobble_blood_2",
    url: "data/images/dcss/dungeon/floor/cobble_blood_2_old.png"
  },
  {
    key: "floor_cobble_blood_3",
    url: "data/images/dcss/dungeon/floor/cobble_blood_3_old.png"
  },
  {
    key: "floor_cobble_blood_4",
    url: "data/images/dcss/dungeon/floor/cobble_blood_4_old.png"
  },
  {
    key: "floor_cobble_blood_5",
    url: "data/images/dcss/dungeon/floor/cobble_blood_5_old.png"
  },
  {
    key: "floor_cobble_blood_6",
    url: "data/images/dcss/dungeon/floor/cobble_blood_6_old.png"
  },
  {
    key: "floor_cobble_blood_7",
    url: "data/images/dcss/dungeon/floor/cobble_blood_7_old.png"
  },
  {
    key: "floor_cobble_blood_8",
    url: "data/images/dcss/dungeon/floor/cobble_blood_8_old.png"
  },
  {
    key: "floor_cobble_blood_9",
    url: "data/images/dcss/dungeon/floor/cobble_blood_9_old.png"
  },
  {
    key: "floor_crypt_10",
    url: "data/images/dcss/dungeon/floor/crypt_10.png"
  },
  {
    key: "floor_crypt_11",
    url: "data/images/dcss/dungeon/floor/crypt_11.png"
  },
  {
    key: "floor_crypt_domino_1a",
    url: "data/images/dcss/dungeon/floor/crypt_domino_1a.png"
  },
  {
    key: "floor_crypt_domino_1b",
    url: "data/images/dcss/dungeon/floor/crypt_domino_1b.png"
  },
  {
    key: "floor_crypt_domino_2a",
    url: "data/images/dcss/dungeon/floor/crypt_domino_2a.png"
  },
  {
    key: "floor_crypt_domino_3a",
    url: "data/images/dcss/dungeon/floor/crypt_domino_3a.png"
  },
  {
    key: "floor_crypt_domino_4a",
    url: "data/images/dcss/dungeon/floor/crypt_domino_4a.png"
  },
  {
    key: "floor_crypt_domino_4b",
    url: "data/images/dcss/dungeon/floor/crypt_domino_4b.png"
  },
  {
    key: "floor_crypt_domino_5a",
    url: "data/images/dcss/dungeon/floor/crypt_domino_5a.png"
  },
  {
    key: "floor_crypt_domino_6a",
    url: "data/images/dcss/dungeon/floor/crypt_domino_6a.png"
  },
  {
    key: "floor_crypt_domino_7a",
    url: "data/images/dcss/dungeon/floor/crypt_domino_7a.png"
  },
  {
    key: "floor_crypt_domino_8a",
    url: "data/images/dcss/dungeon/floor/crypt_domino_8a.png"
  },
  {
    key: "floor_crystal_floor_0",
    url: "data/images/dcss/dungeon/floor/crystal_floor_0.png"
  },
  {
    key: "floor_crystal_floor_1",
    url: "data/images/dcss/dungeon/floor/crystal_floor_1.png"
  },
  {
    key: "floor_crystal_floor_2",
    url: "data/images/dcss/dungeon/floor/crystal_floor_2.png"
  },
  {
    key: "floor_crystal_floor_3",
    url: "data/images/dcss/dungeon/floor/crystal_floor_3.png"
  },
  {
    key: "floor_crystal_floor_4",
    url: "data/images/dcss/dungeon/floor/crystal_floor_4.png"
  },
  {
    key: "floor_crystal_floor_5",
    url: "data/images/dcss/dungeon/floor/crystal_floor_5.png"
  },
  {
    key: "floor_demonic_red_1",
    url: "data/images/dcss/dungeon/floor/demonic_red_1.png"
  },
  {
    key: "floor_demonic_red_2",
    url: "data/images/dcss/dungeon/floor/demonic_red_2.png"
  },
  {
    key: "floor_demonic_red_3",
    url: "data/images/dcss/dungeon/floor/demonic_red_3.png"
  },
  {
    key: "floor_demonic_red_4",
    url: "data/images/dcss/dungeon/floor/demonic_red_4.png"
  },
  {
    key: "floor_demonic_red_5",
    url: "data/images/dcss/dungeon/floor/demonic_red_5.png"
  },
  {
    key: "floor_demonic_red_6",
    url: "data/images/dcss/dungeon/floor/demonic_red_6.png"
  },
  {
    key: "floor_demonic_red_7",
    url: "data/images/dcss/dungeon/floor/demonic_red_7.png"
  },
  {
    key: "floor_demonic_red_8",
    url: "data/images/dcss/dungeon/floor/demonic_red_8.png"
  },
  {
    key: "floor_demonic_red_9",
    url: "data/images/dcss/dungeon/floor/demonic_red_9.png"
  },
  {
    key: "floor_dirt_0",
    url: "data/images/dcss/dungeon/floor/dirt_0_old.png"
  },
  {
    key: "floor_dirt_1",
    url: "data/images/dcss/dungeon/floor/dirt_1_old.png"
  },
  {
    key: "floor_dirt_2",
    url: "data/images/dcss/dungeon/floor/dirt_2_old.png"
  },
  {
    key: "floor_dirt_east",
    url: "data/images/dcss/dungeon/floor/dirt_east_old.png"
  },
  {
    key: "floor_dirt_full",
    url: "data/images/dcss/dungeon/floor/dirt_full_old.png"
  },
  {
    key: "floor_dirt_north",
    url: "data/images/dcss/dungeon/floor/dirt_north_old.png"
  },
  {
    key: "floor_dirt_northeast",
    url: "data/images/dcss/dungeon/floor/dirt_northeast_old.png"
  },
  {
    key: "floor_dirt_northwest",
    url: "data/images/dcss/dungeon/floor/dirt_northwest_old.png"
  },
  {
    key: "floor_dirt_south",
    url: "data/images/dcss/dungeon/floor/dirt_south_old.png"
  },
  {
    key: "floor_dirt_southeast",
    url: "data/images/dcss/dungeon/floor/dirt_southeast_old.png"
  },
  {
    key: "floor_dirt_southwest",
    url: "data/images/dcss/dungeon/floor/dirt_southwest_old.png"
  },
  {
    key: "floor_dirt_west",
    url: "data/images/dcss/dungeon/floor/dirt_west_old.png"
  },
  {
    key: "floor_etched_0",
    url: "data/images/dcss/dungeon/floor/etched_0.png"
  },
  {
    key: "floor_etched_1",
    url: "data/images/dcss/dungeon/floor/etched_1.png"
  },
  {
    key: "floor_etched_2",
    url: "data/images/dcss/dungeon/floor/etched_2.png"
  },
  {
    key: "floor_etched_3",
    url: "data/images/dcss/dungeon/floor/etched_3.png"
  },
  {
    key: "floor_etched_4",
    url: "data/images/dcss/dungeon/floor/etched_4.png"
  },
  {
    key: "floor_etched_5",
    url: "data/images/dcss/dungeon/floor/etched_5.png"
  },
  {
    key: "floor_floor_nerves_0",
    url: "data/images/dcss/dungeon/floor/floor_nerves_0.png"
  },
  {
    key: "floor_floor_nerves_1",
    url: "data/images/dcss/dungeon/floor/floor_nerves_1_old.png"
  },
  {
    key: "floor_floor_nerves_2",
    url: "data/images/dcss/dungeon/floor/floor_nerves_2_old.png"
  },
  {
    key: "floor_floor_nerves_3",
    url: "data/images/dcss/dungeon/floor/floor_nerves_3_old.png"
  },
  {
    key: "floor_floor_nerves_4",
    url: "data/images/dcss/dungeon/floor/floor_nerves_4_old.png"
  },
  {
    key: "floor_floor_nerves_5",
    url: "data/images/dcss/dungeon/floor/floor_nerves_5_old.png"
  },
  {
    key: "floor_floor_nerves_6",
    url: "data/images/dcss/dungeon/floor/floor_nerves_6.png"
  },
  {
    key: "floor_floor_sand_rock_0",
    url: "data/images/dcss/dungeon/floor/floor_sand_rock_0.png"
  },
  {
    key: "floor_floor_sand_rock_1",
    url: "data/images/dcss/dungeon/floor/floor_sand_rock_1.png"
  },
  {
    key: "floor_floor_sand_rock_2",
    url: "data/images/dcss/dungeon/floor/floor_sand_rock_2.png"
  },
  {
    key: "floor_floor_sand_rock_3",
    url: "data/images/dcss/dungeon/floor/floor_sand_rock_3.png"
  },
  {
    key: "floor_floor_sand_stone_0",
    url: "data/images/dcss/dungeon/floor/floor_sand_stone_0.png"
  },
  {
    key: "floor_floor_sand_stone_1",
    url: "data/images/dcss/dungeon/floor/floor_sand_stone_1.png"
  },
  {
    key: "floor_floor_sand_stone_2",
    url: "data/images/dcss/dungeon/floor/floor_sand_stone_2.png"
  },
  {
    key: "floor_floor_sand_stone_3",
    url: "data/images/dcss/dungeon/floor/floor_sand_stone_3.png"
  },
  {
    key: "floor_floor_sand_stone_4",
    url: "data/images/dcss/dungeon/floor/floor_sand_stone_4.png"
  },
  {
    key: "floor_floor_sand_stone_5",
    url: "data/images/dcss/dungeon/floor/floor_sand_stone_5.png"
  },
  {
    key: "floor_floor_sand_stone_6",
    url: "data/images/dcss/dungeon/floor/floor_sand_stone_6.png"
  },
  {
    key: "floor_floor_sand_stone_7",
    url: "data/images/dcss/dungeon/floor/floor_sand_stone_7.png"
  },
  {
    key: "floor_floor_vines_0",
    url: "data/images/dcss/dungeon/floor/floor_vines_0_old.png"
  },
  {
    key: "floor_floor_vines_1",
    url: "data/images/dcss/dungeon/floor/floor_vines_1_old.png"
  },
  {
    key: "floor_floor_vines_2",
    url: "data/images/dcss/dungeon/floor/floor_vines_2_old.png"
  },
  {
    key: "floor_floor_vines_3",
    url: "data/images/dcss/dungeon/floor/floor_vines_3_old.png"
  },
  {
    key: "floor_floor_vines_4",
    url: "data/images/dcss/dungeon/floor/floor_vines_4_old.png"
  },
  {
    key: "floor_floor_vines_5",
    url: "data/images/dcss/dungeon/floor/floor_vines_5_old.png"
  },
  {
    key: "floor_floor_vines_6",
    url: "data/images/dcss/dungeon/floor/floor_vines_6_old.png"
  },
  {
    key: "floor_frozen_0",
    url: "data/images/dcss/dungeon/floor/frozen_0.png"
  },
  {
    key: "floor_frozen_1",
    url: "data/images/dcss/dungeon/floor/frozen_1.png"
  },
  {
    key: "floor_frozen_10",
    url: "data/images/dcss/dungeon/floor/frozen_10.png"
  },
  {
    key: "floor_frozen_11",
    url: "data/images/dcss/dungeon/floor/frozen_11.png"
  },
  {
    key: "floor_frozen_12",
    url: "data/images/dcss/dungeon/floor/frozen_12.png"
  },
  {
    key: "floor_frozen_2",
    url: "data/images/dcss/dungeon/floor/frozen_2.png"
  },
  {
    key: "floor_frozen_3",
    url: "data/images/dcss/dungeon/floor/frozen_3.png"
  },
  {
    key: "floor_frozen_4",
    url: "data/images/dcss/dungeon/floor/frozen_4.png"
  },
  {
    key: "floor_frozen_5",
    url: "data/images/dcss/dungeon/floor/frozen_5.png"
  },
  {
    key: "floor_frozen_6",
    url: "data/images/dcss/dungeon/floor/frozen_6.png"
  },
  {
    key: "floor_frozen_7",
    url: "data/images/dcss/dungeon/floor/frozen_7.png"
  },
  {
    key: "floor_frozen_8",
    url: "data/images/dcss/dungeon/floor/frozen_8.png"
  },
  {
    key: "floor_frozen_9",
    url: "data/images/dcss/dungeon/floor/frozen_9.png"
  },
  {
    key: "floor_grass0-dirt-mix_1",
    url: "data/images/dcss/dungeon/floor/grass/grass0-dirt-mix_1.png"
  },
  {
    key: "floor_grass0-dirt-mix_2",
    url: "data/images/dcss/dungeon/floor/grass/grass0-dirt-mix_2.png"
  },
  {
    key: "floor_grass0-dirt-mix_3",
    url: "data/images/dcss/dungeon/floor/grass/grass0-dirt-mix_3.png"
  },
  {
    key: "floor_grass_0",
    url: "data/images/dcss/dungeon/floor/grass/grass_0_old.png"
  },
  {
    key: "floor_grass_1",
    url: "data/images/dcss/dungeon/floor/grass/grass_1_old.png"
  },
  {
    key: "floor_grass_2",
    url: "data/images/dcss/dungeon/floor/grass/grass_2_old.png"
  },
  {
    key: "floor_grass_east",
    url: "data/images/dcss/dungeon/floor/grass/grass_east_old.png"
  },
  {
    key: "floor_grass_flowers_blue_1",
    url: "data/images/dcss/dungeon/floor/grass/grass_flowers_blue_1_old.png"
  },
  {
    key: "floor_grass_flowers_blue_2",
    url: "data/images/dcss/dungeon/floor/grass/grass_flowers_blue_2_old.png"
  },
  {
    key: "floor_grass_flowers_blue_3",
    url: "data/images/dcss/dungeon/floor/grass/grass_flowers_blue_3_old.png"
  },
  {
    key: "floor_grass_flowers_red_1",
    url: "data/images/dcss/dungeon/floor/grass/grass_flowers_red_1_old.png"
  },
  {
    key: "floor_grass_flowers_red_2",
    url: "data/images/dcss/dungeon/floor/grass/grass_flowers_red_2_old.png"
  },
  {
    key: "floor_grass_flowers_red_3",
    url: "data/images/dcss/dungeon/floor/grass/grass_flowers_red_3_old.png"
  },
  {
    key: "floor_grass_flowers_yellow_1",
    url: "data/images/dcss/dungeon/floor/grass/grass_flowers_yellow_1_old.png"
  },
  {
    key: "floor_grass_flowers_yellow_2",
    url: "data/images/dcss/dungeon/floor/grass/grass_flowers_yellow_2_old.png"
  },
  {
    key: "floor_grass_flowers_yellow_3",
    url: "data/images/dcss/dungeon/floor/grass/grass_flowers_yellow_3_old.png"
  },
  {
    key: "floor_grass_full",
    url: "data/images/dcss/dungeon/floor/grass/grass_full_old.png"
  },
  {
    key: "floor_grass_north",
    url: "data/images/dcss/dungeon/floor/grass/grass_north_old.png"
  },
  {
    key: "floor_grass_northeast",
    url: "data/images/dcss/dungeon/floor/grass/grass_northeast_old.png"
  },
  {
    key: "floor_grass_northwest",
    url: "data/images/dcss/dungeon/floor/grass/grass_northwest_old.png"
  },
  {
    key: "floor_grass_south",
    url: "data/images/dcss/dungeon/floor/grass/grass_south_old.png"
  },
  {
    key: "floor_grass_southeast",
    url: "data/images/dcss/dungeon/floor/grass/grass_southeast_old.png"
  },
  {
    key: "floor_grass_southwest",
    url: "data/images/dcss/dungeon/floor/grass/grass_southwest_old.png"
  },
  {
    key: "floor_grass_west",
    url: "data/images/dcss/dungeon/floor/grass/grass_west_old.png"
  },
  {
    key: "floor_green_bones_1",
    url: "data/images/dcss/dungeon/floor/green_bones_1.png"
  },
  {
    key: "floor_green_bones_10",
    url: "data/images/dcss/dungeon/floor/green_bones_10.png"
  },
  {
    key: "floor_green_bones_11",
    url: "data/images/dcss/dungeon/floor/green_bones_11.png"
  },
  {
    key: "floor_green_bones_12",
    url: "data/images/dcss/dungeon/floor/green_bones_12.png"
  },
  {
    key: "floor_green_bones_2",
    url: "data/images/dcss/dungeon/floor/green_bones_2.png"
  },
  {
    key: "floor_green_bones_3",
    url: "data/images/dcss/dungeon/floor/green_bones_3.png"
  },
  {
    key: "floor_green_bones_4",
    url: "data/images/dcss/dungeon/floor/green_bones_4.png"
  },
  {
    key: "floor_green_bones_5",
    url: "data/images/dcss/dungeon/floor/green_bones_5.png"
  },
  {
    key: "floor_green_bones_6",
    url: "data/images/dcss/dungeon/floor/green_bones_6.png"
  },
  {
    key: "floor_green_bones_7",
    url: "data/images/dcss/dungeon/floor/green_bones_7.png"
  },
  {
    key: "floor_green_bones_8",
    url: "data/images/dcss/dungeon/floor/green_bones_8.png"
  },
  {
    key: "floor_green_bones_9",
    url: "data/images/dcss/dungeon/floor/green_bones_9.png"
  },
  {
    key: "floor_grey_dirt_0",
    url: "data/images/dcss/dungeon/floor/grey_dirt_0_old.png"
  },
  {
    key: "floor_grey_dirt_1",
    url: "data/images/dcss/dungeon/floor/grey_dirt_1_old.png"
  },
  {
    key: "floor_grey_dirt_2",
    url: "data/images/dcss/dungeon/floor/grey_dirt_2_old.png"
  },
  {
    key: "floor_grey_dirt_3",
    url: "data/images/dcss/dungeon/floor/grey_dirt_3_old.png"
  },
  {
    key: "floor_grey_dirt_4",
    url: "data/images/dcss/dungeon/floor/grey_dirt_4_old.png"
  },
  {
    key: "floor_grey_dirt_5",
    url: "data/images/dcss/dungeon/floor/grey_dirt_5_old.png"
  },
  {
    key: "floor_grey_dirt_6",
    url: "data/images/dcss/dungeon/floor/grey_dirt_6_old.png"
  },
  {
    key: "floor_grey_dirt_7",
    url: "data/images/dcss/dungeon/floor/grey_dirt_7_old.png"
  },
  {
    key: "floor_grey_dirt_b_0",
    url: "data/images/dcss/dungeon/floor/grey_dirt_b_0.png"
  },
  {
    key: "floor_grey_dirt_b_1",
    url: "data/images/dcss/dungeon/floor/grey_dirt_b_1.png"
  },
  {
    key: "floor_grey_dirt_b_2",
    url: "data/images/dcss/dungeon/floor/grey_dirt_b_2.png"
  },
  {
    key: "floor_grey_dirt_b_3",
    url: "data/images/dcss/dungeon/floor/grey_dirt_b_3.png"
  },
  {
    key: "floor_grey_dirt_b_4",
    url: "data/images/dcss/dungeon/floor/grey_dirt_b_4.png"
  },
  {
    key: "floor_grey_dirt_b_5",
    url: "data/images/dcss/dungeon/floor/grey_dirt_b_5.png"
  },
  {
    key: "floor_grey_dirt_b_6",
    url: "data/images/dcss/dungeon/floor/grey_dirt_b_6.png"
  },
  {
    key: "floor_grey_dirt_b_7",
    url: "data/images/dcss/dungeon/floor/grey_dirt_b_7.png"
  },
  {
    key: "floor_hive_0",
    url: "data/images/dcss/dungeon/floor/hive_0.png"
  },
  {
    key: "floor_hive_1",
    url: "data/images/dcss/dungeon/floor/hive_1.png"
  },
  {
    key: "floor_hive_2",
    url: "data/images/dcss/dungeon/floor/hive_2.png"
  },
  {
    key: "floor_hive_3",
    url: "data/images/dcss/dungeon/floor/hive_3.png"
  },
  {
    key: "floor_ice_0",
    url: "data/images/dcss/dungeon/floor/ice_0_old.png"
  },
  {
    key: "floor_ice_1",
    url: "data/images/dcss/dungeon/floor/ice_1_old.png"
  },
  {
    key: "floor_ice_2",
    url: "data/images/dcss/dungeon/floor/ice_2_old.png"
  },
  {
    key: "floor_ice_3",
    url: "data/images/dcss/dungeon/floor/ice_3_old.png"
  },
  {
    key: "floor_infernal_1",
    url: "data/images/dcss/dungeon/floor/infernal_1.png"
  },
  {
    key: "floor_infernal_10",
    url: "data/images/dcss/dungeon/floor/infernal_10.png"
  },
  {
    key: "floor_infernal_11",
    url: "data/images/dcss/dungeon/floor/infernal_11.png"
  },
  {
    key: "floor_infernal_12",
    url: "data/images/dcss/dungeon/floor/infernal_12.png"
  },
  {
    key: "floor_infernal_13",
    url: "data/images/dcss/dungeon/floor/infernal_13.png"
  },
  {
    key: "floor_infernal_14",
    url: "data/images/dcss/dungeon/floor/infernal_14.png"
  },
  {
    key: "floor_infernal_15",
    url: "data/images/dcss/dungeon/floor/infernal_15.png"
  },
  {
    key: "floor_infernal_2",
    url: "data/images/dcss/dungeon/floor/infernal_2.png"
  },
  {
    key: "floor_infernal_3",
    url: "data/images/dcss/dungeon/floor/infernal_3.png"
  },
  {
    key: "floor_infernal_4",
    url: "data/images/dcss/dungeon/floor/infernal_4.png"
  },
  {
    key: "floor_infernal_5",
    url: "data/images/dcss/dungeon/floor/infernal_5.png"
  },
  {
    key: "floor_infernal_6",
    url: "data/images/dcss/dungeon/floor/infernal_6.png"
  },
  {
    key: "floor_infernal_7",
    url: "data/images/dcss/dungeon/floor/infernal_7.png"
  },
  {
    key: "floor_infernal_8",
    url: "data/images/dcss/dungeon/floor/infernal_8.png"
  },
  {
    key: "floor_infernal_9",
    url: "data/images/dcss/dungeon/floor/infernal_9.png"
  },
  {
    key: "floor_infernal_blank",
    url: "data/images/dcss/dungeon/floor/infernal_blank.png"
  },
  {
    key: "floor_labyrinth_0",
    url: "data/images/dcss/dungeon/floor/labyrinth_0.png"
  },
  {
    key: "floor_labyrinth_1",
    url: "data/images/dcss/dungeon/floor/labyrinth_1.png"
  },
  {
    key: "floor_labyrinth_2",
    url: "data/images/dcss/dungeon/floor/labyrinth_2.png"
  },
  {
    key: "floor_labyrinth_3",
    url: "data/images/dcss/dungeon/floor/labyrinth_3.png"
  },
  {
    key: "floor_lair0b",
    url: "data/images/dcss/dungeon/floor/lair0b.png"
  },
  {
    key: "floor_lair1b",
    url: "data/images/dcss/dungeon/floor/lair1b.png"
  },
  {
    key: "floor_lair2b",
    url: "data/images/dcss/dungeon/floor/lair2b.png"
  },
  {
    key: "floor_lair3b",
    url: "data/images/dcss/dungeon/floor/lair3b.png"
  },
  {
    key: "floor_lair4b",
    url: "data/images/dcss/dungeon/floor/lair4b.png"
  },
  {
    key: "floor_lair5b",
    url: "data/images/dcss/dungeon/floor/lair5b.png"
  },
  {
    key: "floor_lair6b",
    url: "data/images/dcss/dungeon/floor/lair6b.png"
  },
  {
    key: "floor_lair7b",
    url: "data/images/dcss/dungeon/floor/lair7b.png"
  },
  {
    key: "floor_lair_0",
    url: "data/images/dcss/dungeon/floor/lair_0_old.png"
  },
  {
    key: "floor_lair_1",
    url: "data/images/dcss/dungeon/floor/lair_1_old.png"
  },
  {
    key: "floor_lair_2",
    url: "data/images/dcss/dungeon/floor/lair_2_old.png"
  },
  {
    key: "floor_lair_3",
    url: "data/images/dcss/dungeon/floor/lair_3_old.png"
  },
  {
    key: "floor_lair_4",
    url: "data/images/dcss/dungeon/floor/lair_4.png"
  },
  {
    key: "floor_lair_5",
    url: "data/images/dcss/dungeon/floor/lair_5.png"
  },
  {
    key: "floor_lair_6",
    url: "data/images/dcss/dungeon/floor/lair_6.png"
  },
  {
    key: "floor_lair_7",
    url: "data/images/dcss/dungeon/floor/lair_7.png"
  },
  {
    key: "floor_lava_0",
    url: "data/images/dcss/dungeon/floor/lava_0.png"
  },
  {
    key: "floor_lava_1",
    url: "data/images/dcss/dungeon/floor/lava_1.png"
  },
  {
    key: "floor_lava_2",
    url: "data/images/dcss/dungeon/floor/lava_2.png"
  },
  {
    key: "floor_lava_3",
    url: "data/images/dcss/dungeon/floor/lava_3.png"
  },
  {
    key: "floor_lava",
    url: "data/images/dcss/dungeon/floor/lava_old.png"
  },
  {
    key: "floor_limestone_0",
    url: "data/images/dcss/dungeon/floor/limestone_0.png"
  },
  {
    key: "floor_limestone_1",
    url: "data/images/dcss/dungeon/floor/limestone_1.png"
  },
  {
    key: "floor_limestone_2",
    url: "data/images/dcss/dungeon/floor/limestone_2.png"
  },
  {
    key: "floor_limestone_3",
    url: "data/images/dcss/dungeon/floor/limestone_3.png"
  },
  {
    key: "floor_limestone_4",
    url: "data/images/dcss/dungeon/floor/limestone_4.png"
  },
  {
    key: "floor_limestone_5",
    url: "data/images/dcss/dungeon/floor/limestone_5.png"
  },
  {
    key: "floor_limestone_6",
    url: "data/images/dcss/dungeon/floor/limestone_6.png"
  },
  {
    key: "floor_limestone_7",
    url: "data/images/dcss/dungeon/floor/limestone_7.png"
  },
  {
    key: "floor_limestone_8",
    url: "data/images/dcss/dungeon/floor/limestone_8.png"
  },
  {
    key: "floor_limestone_9",
    url: "data/images/dcss/dungeon/floor/limestone_9.png"
  },
  {
    key: "floor_marble_floor_1",
    url: "data/images/dcss/dungeon/floor/marble_floor_1.png"
  },
  {
    key: "floor_marble_floor_2",
    url: "data/images/dcss/dungeon/floor/marble_floor_2.png"
  },
  {
    key: "floor_marble_floor_3",
    url: "data/images/dcss/dungeon/floor/marble_floor_3.png"
  },
  {
    key: "floor_marble_floor_4",
    url: "data/images/dcss/dungeon/floor/marble_floor_4.png"
  },
  {
    key: "floor_marble_floor_5",
    url: "data/images/dcss/dungeon/floor/marble_floor_5.png"
  },
  {
    key: "floor_marble_floor_6",
    url: "data/images/dcss/dungeon/floor/marble_floor_6.png"
  },
  {
    key: "floor_mesh_0",
    url: "data/images/dcss/dungeon/floor/mesh_0_old.png"
  },
  {
    key: "floor_mesh_1",
    url: "data/images/dcss/dungeon/floor/mesh_1_old.png"
  },
  {
    key: "floor_mesh_2",
    url: "data/images/dcss/dungeon/floor/mesh_2_old.png"
  },
  {
    key: "floor_mesh_3",
    url: "data/images/dcss/dungeon/floor/mesh_3_old.png"
  },
  {
    key: "floor_mosaic_0",
    url: "data/images/dcss/dungeon/floor/mosaic_0.png"
  },
  {
    key: "floor_mosaic_1",
    url: "data/images/dcss/dungeon/floor/mosaic_1.png"
  },
  {
    key: "floor_mosaic_10",
    url: "data/images/dcss/dungeon/floor/mosaic_10.png"
  },
  {
    key: "floor_mosaic_11",
    url: "data/images/dcss/dungeon/floor/mosaic_11.png"
  },
  {
    key: "floor_mosaic_12",
    url: "data/images/dcss/dungeon/floor/mosaic_12.png"
  },
  {
    key: "floor_mosaic_13",
    url: "data/images/dcss/dungeon/floor/mosaic_13.png"
  },
  {
    key: "floor_mosaic_14",
    url: "data/images/dcss/dungeon/floor/mosaic_14.png"
  },
  {
    key: "floor_mosaic_15",
    url: "data/images/dcss/dungeon/floor/mosaic_15.png"
  },
  {
    key: "floor_mosaic_2",
    url: "data/images/dcss/dungeon/floor/mosaic_2.png"
  },
  {
    key: "floor_mosaic_3",
    url: "data/images/dcss/dungeon/floor/mosaic_3.png"
  },
  {
    key: "floor_mosaic_4",
    url: "data/images/dcss/dungeon/floor/mosaic_4.png"
  },
  {
    key: "floor_mosaic_5",
    url: "data/images/dcss/dungeon/floor/mosaic_5.png"
  },
  {
    key: "floor_mosaic_6",
    url: "data/images/dcss/dungeon/floor/mosaic_6.png"
  },
  {
    key: "floor_mosaic_7",
    url: "data/images/dcss/dungeon/floor/mosaic_7.png"
  },
  {
    key: "floor_mosaic_8",
    url: "data/images/dcss/dungeon/floor/mosaic_8.png"
  },
  {
    key: "floor_mosaic_9",
    url: "data/images/dcss/dungeon/floor/mosaic_9.png"
  },
  {
    key: "floor_moss_0",
    url: "data/images/dcss/dungeon/floor/moss_0.png"
  },
  {
    key: "floor_moss_1",
    url: "data/images/dcss/dungeon/floor/moss_1.png"
  },
  {
    key: "floor_moss_2",
    url: "data/images/dcss/dungeon/floor/moss_2.png"
  },
  {
    key: "floor_moss_3",
    url: "data/images/dcss/dungeon/floor/moss_3.png"
  },
  {
    key: "floor_mud_0",
    url: "data/images/dcss/dungeon/floor/mud_0.png"
  },
  {
    key: "floor_mud_1",
    url: "data/images/dcss/dungeon/floor/mud_1.png"
  },
  {
    key: "floor_mud_2",
    url: "data/images/dcss/dungeon/floor/mud_2.png"
  },
  {
    key: "floor_mud_3",
    url: "data/images/dcss/dungeon/floor/mud_3.png"
  },
  {
    key: "floor_orc_0",
    url: "data/images/dcss/dungeon/floor/orc_0.png"
  },
  {
    key: "floor_orc_1",
    url: "data/images/dcss/dungeon/floor/orc_1.png"
  },
  {
    key: "floor_orc_2",
    url: "data/images/dcss/dungeon/floor/orc_2.png"
  },
  {
    key: "floor_orc_3",
    url: "data/images/dcss/dungeon/floor/orc_3.png"
  },
  {
    key: "floor_orc_4",
    url: "data/images/dcss/dungeon/floor/orc_4.png"
  },
  {
    key: "floor_orc_5",
    url: "data/images/dcss/dungeon/floor/orc_5.png"
  },
  {
    key: "floor_orc_6",
    url: "data/images/dcss/dungeon/floor/orc_6.png"
  },
  {
    key: "floor_orc_7",
    url: "data/images/dcss/dungeon/floor/orc_7.png"
  },
  {
    key: "floor_pebble_brown_0",
    url: "data/images/dcss/dungeon/floor/pebble_brown_0_old.png"
  },
  {
    key: "floor_pebble_brown_1",
    url: "data/images/dcss/dungeon/floor/pebble_brown_1_old.png"
  },
  {
    key: "floor_pebble_brown_2",
    url: "data/images/dcss/dungeon/floor/pebble_brown_2_old.png"
  },
  {
    key: "floor_pebble_brown_3",
    url: "data/images/dcss/dungeon/floor/pebble_brown_3_old.png"
  },
  {
    key: "floor_pebble_brown_4",
    url: "data/images/dcss/dungeon/floor/pebble_brown_4_old.png"
  },
  {
    key: "floor_pebble_brown_5",
    url: "data/images/dcss/dungeon/floor/pebble_brown_5_old.png"
  },
  {
    key: "floor_pebble_brown_6",
    url: "data/images/dcss/dungeon/floor/pebble_brown_6_old.png"
  },
  {
    key: "floor_pebble_brown_7",
    url: "data/images/dcss/dungeon/floor/pebble_brown_7_old.png"
  },
  {
    key: "floor_pebble_brown_8",
    url: "data/images/dcss/dungeon/floor/pebble_brown_8_old.png"
  },
  {
    key: "floor_pedestal_east",
    url: "data/images/dcss/dungeon/floor/pedestal_east.png"
  },
  {
    key: "floor_pedestal_full",
    url: "data/images/dcss/dungeon/floor/pedestal_full.png"
  },
  {
    key: "floor_pedestal_north",
    url: "data/images/dcss/dungeon/floor/pedestal_north.png"
  },
  {
    key: "floor_pedestal_northeast",
    url: "data/images/dcss/dungeon/floor/pedestal_northeast.png"
  },
  {
    key: "floor_pedestal_northwest",
    url: "data/images/dcss/dungeon/floor/pedestal_northwest.png"
  },
  {
    key: "floor_pedestal_south",
    url: "data/images/dcss/dungeon/floor/pedestal_south.png"
  },
  {
    key: "floor_pedestal_southeast",
    url: "data/images/dcss/dungeon/floor/pedestal_southeast.png"
  },
  {
    key: "floor_pedestal_southwest",
    url: "data/images/dcss/dungeon/floor/pedestal_southwest.png"
  },
  {
    key: "floor_pedestal_west",
    url: "data/images/dcss/dungeon/floor/pedestal_west.png"
  },
  {
    key: "floor_rect_gray_0",
    url: "data/images/dcss/dungeon/floor/rect_gray_0_old.png"
  },
  {
    key: "floor_rect_gray_1",
    url: "data/images/dcss/dungeon/floor/rect_gray_1_old.png"
  },
  {
    key: "floor_rect_gray_2",
    url: "data/images/dcss/dungeon/floor/rect_gray_2_old.png"
  },
  {
    key: "floor_rect_gray_3",
    url: "data/images/dcss/dungeon/floor/rect_gray_3_old.png"
  },
  {
    key: "floor_rough_red_0",
    url: "data/images/dcss/dungeon/floor/rough_red_0.png"
  },
  {
    key: "floor_rough_red_1",
    url: "data/images/dcss/dungeon/floor/rough_red_1.png"
  },
  {
    key: "floor_rough_red_2",
    url: "data/images/dcss/dungeon/floor/rough_red_2.png"
  },
  {
    key: "floor_rough_red_3",
    url: "data/images/dcss/dungeon/floor/rough_red_3.png"
  },
  {
    key: "floor_sand_1",
    url: "data/images/dcss/dungeon/floor/sand_1.png"
  },
  {
    key: "floor_sand_2",
    url: "data/images/dcss/dungeon/floor/sand_2.png"
  },
  {
    key: "floor_sand_3",
    url: "data/images/dcss/dungeon/floor/sand_3.png"
  },
  {
    key: "floor_sand_4",
    url: "data/images/dcss/dungeon/floor/sand_4.png"
  },
  {
    key: "floor_sand_5",
    url: "data/images/dcss/dungeon/floor/sand_5.png"
  },
  {
    key: "floor_sand_6",
    url: "data/images/dcss/dungeon/floor/sand_6.png"
  },
  {
    key: "floor_sand_7",
    url: "data/images/dcss/dungeon/floor/sand_7.png"
  },
  {
    key: "floor_sand_8",
    url: "data/images/dcss/dungeon/floor/sand_8.png"
  },
  {
    key: "floor_sandstone_floor_0",
    url: "data/images/dcss/dungeon/floor/sandstone_floor_0.png"
  },
  {
    key: "floor_sandstone_floor_1",
    url: "data/images/dcss/dungeon/floor/sandstone_floor_1.png"
  },
  {
    key: "floor_sandstone_floor_2",
    url: "data/images/dcss/dungeon/floor/sandstone_floor_2.png"
  },
  {
    key: "floor_sandstone_floor_3",
    url: "data/images/dcss/dungeon/floor/sandstone_floor_3.png"
  },
  {
    key: "floor_sandstone_floor_4",
    url: "data/images/dcss/dungeon/floor/sandstone_floor_4.png"
  },
  {
    key: "floor_sandstone_floor_5",
    url: "data/images/dcss/dungeon/floor/sandstone_floor_5.png"
  },
  {
    key: "floor_sandstone_floor_6",
    url: "data/images/dcss/dungeon/floor/sandstone_floor_6.png"
  },
  {
    key: "floor_sandstone_floor_7",
    url: "data/images/dcss/dungeon/floor/sandstone_floor_7.png"
  },
  {
    key: "floor_sandstone_floor_8",
    url: "data/images/dcss/dungeon/floor/sandstone_floor_8.png"
  },
  {
    key: "floor_sandstone_floor_9",
    url: "data/images/dcss/dungeon/floor/sandstone_floor_9.png"
  },
  {
    key: "floor_sigil_algiz_left",
    url: "data/images/dcss/dungeon/floor/sigil_algiz_left.png"
  },
  {
    key: "floor_sigil_algiz_right",
    url: "data/images/dcss/dungeon/floor/sigil_algiz_right.png"
  },
  {
    key: "floor_sigil_circle",
    url: "data/images/dcss/dungeon/floor/sigil_circle.png"
  },
  {
    key: "floor_sigil_cross",
    url: "data/images/dcss/dungeon/floor/sigil_cross.png"
  },
  {
    key: "floor_sigil_curve_north_east",
    url: "data/images/dcss/dungeon/floor/sigil_curve_north_east.png"
  },
  {
    key: "floor_sigil_curve_north_west",
    url: "data/images/dcss/dungeon/floor/sigil_curve_north_west.png"
  },
  {
    key: "floor_sigil_curve_south_east",
    url: "data/images/dcss/dungeon/floor/sigil_curve_south_east.png"
  },
  {
    key: "floor_sigil_curve_south_west",
    url: "data/images/dcss/dungeon/floor/sigil_curve_south_west.png"
  },
  {
    key: "floor_sigil_rhombus",
    url: "data/images/dcss/dungeon/floor/sigil_rhombus.png"
  },
  {
    key: "floor_sigil_sharp_east_northeast",
    url: "data/images/dcss/dungeon/floor/sigil_sharp_east_northeast.png"
  },
  {
    key: "floor_sigil_sharp_west_southwest",
    url: "data/images/dcss/dungeon/floor/sigil_sharp_west_southwest.png"
  },
  {
    key: "floor_sigil_straight_east_northeast_southwest",
    url: "data/images/dcss/dungeon/floor/sigil_straight_east_northeast_southwest.png"
  },
  {
    key: "floor_sigil_straight_east_west",
    url: "data/images/dcss/dungeon/floor/sigil_straight_east_west.png"
  },
  {
    key: "floor_sigil_straight_east_west_northeast_northwest",
    url: "data/images/dcss/dungeon/floor/sigil_straight_east_west_northeast_northwest.png"
  },
  {
    key: "floor_sigil_straight_north_south",
    url: "data/images/dcss/dungeon/floor/sigil_straight_north_south.png"
  },
  {
    key: "floor_sigil_straight_northeast_southwest",
    url: "data/images/dcss/dungeon/floor/sigil_straight_northeast_southwest.png"
  },
  {
    key: "floor_sigil_straight_northwest_southeast",
    url: "data/images/dcss/dungeon/floor/sigil_straight_northwest_southeast.png"
  },
  {
    key: "floor_sigil_wide_east_northwest",
    url: "data/images/dcss/dungeon/floor/sigil_wide_east_northwest.png"
  },
  {
    key: "floor_sigil_wide_east_southwest",
    url: "data/images/dcss/dungeon/floor/sigil_wide_east_southwest.png"
  },
  {
    key: "floor_sigil_wide_north_southeast",
    url: "data/images/dcss/dungeon/floor/sigil_wide_north_southeast.png"
  },
  {
    key: "floor_sigil_wide_north_southwest",
    url: "data/images/dcss/dungeon/floor/sigil_wide_north_southwest.png"
  },
  {
    key: "floor_sigil_wide_south_northeast",
    url: "data/images/dcss/dungeon/floor/sigil_wide_south_northeast.png"
  },
  {
    key: "floor_sigil_wide_south_northwest",
    url: "data/images/dcss/dungeon/floor/sigil_wide_south_northwest.png"
  },
  {
    key: "floor_sigil_wide_west_northeast",
    url: "data/images/dcss/dungeon/floor/sigil_wide_west_northeast.png"
  },
  {
    key: "floor_sigil_wide_west_southeast",
    url: "data/images/dcss/dungeon/floor/sigil_wide_west_southeast.png"
  },
  {
    key: "floor_sigil_y_east",
    url: "data/images/dcss/dungeon/floor/sigil_y_east.png"
  },
  {
    key: "floor_sigil_y_left",
    url: "data/images/dcss/dungeon/floor/sigil_y_left.png"
  },
  {
    key: "floor_sigil_y_north",
    url: "data/images/dcss/dungeon/floor/sigil_y_north.png"
  },
  {
    key: "floor_sigil_y_right",
    url: "data/images/dcss/dungeon/floor/sigil_y_right.png"
  },
  {
    key: "floor_sigil_y_south",
    url: "data/images/dcss/dungeon/floor/sigil_y_south.png"
  },
  {
    key: "floor_sigil_y_west",
    url: "data/images/dcss/dungeon/floor/sigil_y_west.png"
  },
  {
    key: "floor_slime_overlay_east",
    url: "data/images/dcss/dungeon/floor/slime_overlay_east.png"
  },
  {
    key: "floor_slime_overlay_north",
    url: "data/images/dcss/dungeon/floor/slime_overlay_north.png"
  },
  {
    key: "floor_slime_overlay_northeast",
    url: "data/images/dcss/dungeon/floor/slime_overlay_northeast.png"
  },
  {
    key: "floor_slime_overlay_northwest",
    url: "data/images/dcss/dungeon/floor/slime_overlay_northwest.png"
  },
  {
    key: "floor_slime_overlay_south",
    url: "data/images/dcss/dungeon/floor/slime_overlay_south.png"
  },
  {
    key: "floor_slime_overlay_southeast",
    url: "data/images/dcss/dungeon/floor/slime_overlay_southeast.png"
  },
  {
    key: "floor_slime_overlay_southwest",
    url: "data/images/dcss/dungeon/floor/slime_overlay_southwest.png"
  },
  {
    key: "floor_slime_overlay_west",
    url: "data/images/dcss/dungeon/floor/slime_overlay_west.png"
  },
  {
    key: "floor_snake-a_0",
    url: "data/images/dcss/dungeon/floor/snake-a_0.png"
  },
  {
    key: "floor_snake-a_1",
    url: "data/images/dcss/dungeon/floor/snake-a_1.png"
  },
  {
    key: "floor_snake-a_2",
    url: "data/images/dcss/dungeon/floor/snake-a_2.png"
  },
  {
    key: "floor_snake-a_3",
    url: "data/images/dcss/dungeon/floor/snake-a_3.png"
  },
  {
    key: "floor_snake-c_0",
    url: "data/images/dcss/dungeon/floor/snake-c_0.png"
  },
  {
    key: "floor_snake-c_1",
    url: "data/images/dcss/dungeon/floor/snake-c_1.png"
  },
  {
    key: "floor_snake-c_2",
    url: "data/images/dcss/dungeon/floor/snake-c_2.png"
  },
  {
    key: "floor_snake-c_3",
    url: "data/images/dcss/dungeon/floor/snake-c_3.png"
  },
  {
    key: "floor_snake-d_0",
    url: "data/images/dcss/dungeon/floor/snake-d_0.png"
  },
  {
    key: "floor_snake-d_1",
    url: "data/images/dcss/dungeon/floor/snake-d_1.png"
  },
  {
    key: "floor_snake-d_2",
    url: "data/images/dcss/dungeon/floor/snake-d_2.png"
  },
  {
    key: "floor_snake-d_3",
    url: "data/images/dcss/dungeon/floor/snake-d_3.png"
  },
  {
    key: "floor_snake_0",
    url: "data/images/dcss/dungeon/floor/snake_0.png"
  },
  {
    key: "floor_snake_1",
    url: "data/images/dcss/dungeon/floor/snake_1.png"
  },
  {
    key: "floor_snake_2",
    url: "data/images/dcss/dungeon/floor/snake_2.png"
  },
  {
    key: "floor_snake_3",
    url: "data/images/dcss/dungeon/floor/snake_3.png"
  },
  {
    key: "floor_swamp_0",
    url: "data/images/dcss/dungeon/floor/swamp_0_old.png"
  },
  {
    key: "floor_swamp_1",
    url: "data/images/dcss/dungeon/floor/swamp_1_old.png"
  },
  {
    key: "floor_swamp_2",
    url: "data/images/dcss/dungeon/floor/swamp_2_old.png"
  },
  {
    key: "floor_swamp_3",
    url: "data/images/dcss/dungeon/floor/swamp_3_old.png"
  },
  {
    key: "floor_tomb_0",
    url: "data/images/dcss/dungeon/floor/tomb_0_old.png"
  },
  {
    key: "floor_tomb_1",
    url: "data/images/dcss/dungeon/floor/tomb_1_old.png"
  },
  {
    key: "floor_tomb_2",
    url: "data/images/dcss/dungeon/floor/tomb_2_old.png"
  },
  {
    key: "floor_tomb_3",
    url: "data/images/dcss/dungeon/floor/tomb_3_old.png"
  },
  {
    key: "floor_tutorial_pad",
    url: "data/images/dcss/dungeon/floor/tutorial_pad.png"
  },
  {
    key: "floor_volcanic_floor_0",
    url: "data/images/dcss/dungeon/floor/volcanic_floor_0.png"
  },
  {
    key: "floor_volcanic_floor_1",
    url: "data/images/dcss/dungeon/floor/volcanic_floor_1.png"
  },
  {
    key: "floor_volcanic_floor_2",
    url: "data/images/dcss/dungeon/floor/volcanic_floor_2.png"
  },
  {
    key: "floor_volcanic_floor_3",
    url: "data/images/dcss/dungeon/floor/volcanic_floor_3.png"
  },
  {
    key: "floor_volcanic_floor_4",
    url: "data/images/dcss/dungeon/floor/volcanic_floor_4.png"
  },
  {
    key: "floor_volcanic_floor_5",
    url: "data/images/dcss/dungeon/floor/volcanic_floor_5.png"
  },
  {
    key: "floor_volcanic_floor_6",
    url: "data/images/dcss/dungeon/floor/volcanic_floor_6.png"
  },
  {
    key: "floor_white_marble_0",
    url: "data/images/dcss/dungeon/floor/white_marble_0.png"
  },
  {
    key: "floor_white_marble_1",
    url: "data/images/dcss/dungeon/floor/white_marble_1.png"
  },
  {
    key: "floor_white_marble_2",
    url: "data/images/dcss/dungeon/floor/white_marble_2.png"
  },
  {
    key: "floor_white_marble_3",
    url: "data/images/dcss/dungeon/floor/white_marble_3.png"
  },
  {
    key: "floor_white_marble_4",
    url: "data/images/dcss/dungeon/floor/white_marble_4.png"
  },
  {
    key: "floor_white_marble_5",
    url: "data/images/dcss/dungeon/floor/white_marble_5.png"
  },
  {
    key: "floor_white_marble_6",
    url: "data/images/dcss/dungeon/floor/white_marble_6.png"
  },
  {
    key: "floor_white_marble_7",
    url: "data/images/dcss/dungeon/floor/white_marble_7.png"
  },
  {
    key: "floor_white_marble_8",
    url: "data/images/dcss/dungeon/floor/white_marble_8.png"
  },
  {
    key: "floor_white_marble_9",
    url: "data/images/dcss/dungeon/floor/white_marble_9.png"
  },
  {
    key: "door_closed_door",
    url: "data/images/dcss/dungeon/doors/closed_door.png"
  },
  {
    key: "door_detected_secret_door",
    url: "data/images/dcss/dungeon/doors/detected_secret_door.png"
  },
  {
    key: "door_fleshy_orifice_closed",
    url: "data/images/dcss/dungeon/doors/fleshy_orifice_closed.png"
  },
  {
    key: "door_gate_closed_left",
    url: "data/images/dcss/dungeon/doors/gate_closed_left.png"
  },
  {
    key: "door_gate_closed_middle",
    url: "data/images/dcss/dungeon/doors/gate_closed_middle.png"
  },
  {
    key: "door_gate_closed_right",
    url: "data/images/dcss/dungeon/doors/gate_closed_right.png"
  },
  {
    key: "door_gate_open_left",
    url: "data/images/dcss/dungeon/doors/gate_open_left.png"
  },
  {
    key: "door_gate_open_middle",
    url: "data/images/dcss/dungeon/doors/gate_open_middle.png"
  },
  {
    key: "door_gate_open_right",
    url: "data/images/dcss/dungeon/doors/gate_open_right.png"
  },
  {
    key: "door_gate_runed_left",
    url: "data/images/dcss/dungeon/doors/gate_runed_left.png"
  },
  {
    key: "door_gate_runed_middle",
    url: "data/images/dcss/dungeon/doors/gate_runed_middle.png"
  },
  {
    key: "door_gate_runed_right",
    url: "data/images/dcss/dungeon/doors/gate_runed_right.png"
  },
  {
    key: "door_gate_sealed_left",
    url: "data/images/dcss/dungeon/doors/gate_sealed_left.png"
  },
  {
    key: "door_gate_sealed_middle",
    url: "data/images/dcss/dungeon/doors/gate_sealed_middle.png"
  },
  {
    key: "door_gate_sealed_right",
    url: "data/images/dcss/dungeon/doors/gate_sealed_right.png"
  },
  {
    key: "door_open_door",
    url: "data/images/dcss/dungeon/doors/open_door.png"
  },
  {
    key: "door_runed_door",
    url: "data/images/dcss/dungeon/doors/runed_door.png"
  },
  {
    key: "door_sealed_door",
    url: "data/images/dcss/dungeon/doors/sealed_door.png"
  },
  {
    key: "door_vgate_closed_down",
    url: "data/images/dcss/dungeon/doors/vgate_closed_down.png"
  },
  {
    key: "door_vgate_closed_middle",
    url: "data/images/dcss/dungeon/doors/vgate_closed_middle.png"
  },
  {
    key: "door_vgate_closed_up",
    url: "data/images/dcss/dungeon/doors/vgate_closed_up.png"
  },
  {
    key: "door_vgate_open_down",
    url: "data/images/dcss/dungeon/doors/vgate_open_down.png"
  },
  {
    key: "door_vgate_open_middle",
    url: "data/images/dcss/dungeon/doors/vgate_open_middle.png"
  },
  {
    key: "door_vgate_open_up",
    url: "data/images/dcss/dungeon/doors/vgate_open_up.png"
  },
  {
    key: "door_vgate_runed_down",
    url: "data/images/dcss/dungeon/doors/vgate_runed_down.png"
  },
  {
    key: "door_vgate_runed_middle",
    url: "data/images/dcss/dungeon/doors/vgate_runed_middle.png"
  },
  {
    key: "door_vgate_runed_up",
    url: "data/images/dcss/dungeon/doors/vgate_runed_up.png"
  },
  {
    key: "door_vgate_sealed_down",
    url: "data/images/dcss/dungeon/doors/vgate_sealed_down.png"
  },
  {
    key: "door_vgate_sealed_middle",
    url: "data/images/dcss/dungeon/doors/vgate_sealed_middle.png"
  },
  {
    key: "door_vgate_sealed_up",
    url: "data/images/dcss/dungeon/doors/vgate_sealed_up.png"
  },
  {
    key: "food_apple",
    url: "data/images/dcss/item/food/apple.png"
  },
  {
    key: "food_apricot",
    url: "data/images/dcss/item/food/apricot_old.png"
  },
  {
    key: "food_banana",
    url: "data/images/dcss/item/food/banana_old.png"
  },
  {
    key: "food_beef_jerky",
    url: "data/images/dcss/item/food/beef_jerky_old.png"
  },
  {
    key: "food_bone",
    url: "data/images/dcss/item/food/bone.png"
  },
  {
    key: "food_bread_ration",
    url: "data/images/dcss/item/food/bread_ration_old.png"
  },
  {
    key: "food_cheese",
    url: "data/images/dcss/item/food/cheese.png"
  },
  {
    key: "food_choko",
    url: "data/images/dcss/item/food/choko.png"
  },
  {
    key: "food_chunk",
    url: "data/images/dcss/item/food/chunk.png"
  },
  {
    key: "food_chunk_rotten",
    url: "data/images/dcss/item/food/chunk_rotten.png"
  },
  {
    key: "food_fruit",
    url: "data/images/dcss/item/food/fruit.png"
  },
  {
    key: "food_grape",
    url: "data/images/dcss/item/food/grape.png"
  },
  {
    key: "food_honeycomb",
    url: "data/images/dcss/item/food/honeycomb_old.png"
  },
  {
    key: "food_lemon",
    url: "data/images/dcss/item/food/lemon_old.png"
  },
  {
    key: "food_lump_of_royal_jelly",
    url: "data/images/dcss/item/food/lump_of_royal_jelly_old.png"
  },
  {
    key: "food_lychee",
    url: "data/images/dcss/item/food/lychee_old.png"
  },
  {
    key: "food_meat_ration",
    url: "data/images/dcss/item/food/meat_ration_old.png"
  },
  {
    key: "food_orange",
    url: "data/images/dcss/item/food/orange.png"
  },
  {
    key: "food_pear",
    url: "data/images/dcss/item/food/pear.png"
  },
  {
    key: "food_piece_of_ambrosia",
    url: "data/images/dcss/item/food/piece_of_ambrosia_old.png"
  },
  {
    key: "food_pizza",
    url: "data/images/dcss/item/food/pizza_old.png"
  },
  {
    key: "food_rambutan",
    url: "data/images/dcss/item/food/rambutan_old.png"
  },
  {
    key: "food_sausage",
    url: "data/images/dcss/item/food/sausage.png"
  },
  {
    key: "food_snozzcumber",
    url: "data/images/dcss/item/food/snozzcumber.png"
  },
  {
    key: "food_strawberry",
    url: "data/images/dcss/item/food/strawberry_old.png"
  },
  {
    key: "food_sultana",
    url: "data/images/dcss/item/food/sultana.png"
  },
  {
    key: "monster_unseen_horror",
    url: "data/images/dcss/monster/aberration/unseen_horror_old.png"
  },
  {
    key: "monster_ancient_zyme",
    url: "data/images/dcss/monster/abyss/ancient_zyme.png"
  },
  {
    key: "monster_apocalypse_crab",
    url: "data/images/dcss/monster/abyss/apocalypse_crab.png"
  },
  {
    key: "monster_lurking_horror",
    url: "data/images/dcss/monster/abyss/lurking_horror.png"
  },
  {
    key: "monster_silver_star",
    url: "data/images/dcss/monster/abyss/silver_star.png"
  },
  {
    key: "monster_starcursed_mass",
    url: "data/images/dcss/monster/abyss/starcursed_mass.png"
  },
  {
    key: "monster_tentacled_starspawn",
    url: "data/images/dcss/monster/abyss/tentacled_starspawn.png"
  },
  {
    key: "monster_worldbinder",
    url: "data/images/dcss/monster/abyss/worldbinder.png"
  },
  {
    key: "monster_wretched_star",
    url: "data/images/dcss/monster/abyss/wretched_star.png"
  },
  {
    key: "monster_acid_blob",
    url: "data/images/dcss/monster/amorphous/acid_blob.png"
  },
  {
    key: "monster_azure_jelly",
    url: "data/images/dcss/monster/amorphous/azure_jelly_old.png"
  },
  {
    key: "monster_death_ooze",
    url: "data/images/dcss/monster/amorphous/death_ooze_old.png"
  },
  {
    key: "monster_jelly",
    url: "data/images/dcss/monster/amorphous/jelly.png"
  },
  {
    key: "monster_ooze",
    url: "data/images/dcss/monster/amorphous/ooze_old.png"
  },
  {
    key: "monster_adder",
    url: "data/images/dcss/monster/animals/adder.png"
  },
  {
    key: "monster_alligator",
    url: "data/images/dcss/monster/animals/alligator.png"
  },
  {
    key: "monster_alligator_baby",
    url: "data/images/dcss/monster/animals/alligator_baby.png"
  },
  {
    key: "monster_alligator_snapping_turtle",
    url: "data/images/dcss/monster/animals/alligator_snapping_turtle_old.png"
  },
  {
    key: "monster_alligator_snapping_turtle_shell",
    url: "data/images/dcss/monster/animals/alligator_snapping_turtle_shell.png"
  },
  {
    key: "monster_anaconda",
    url: "data/images/dcss/monster/animals/anaconda_old.png"
  },
  {
    key: "monster_ball_python",
    url: "data/images/dcss/monster/animals/ball_python.png"
  },
  {
    key: "monster_basilisk",
    url: "data/images/dcss/monster/animals/basilisk.png"
  },
  {
    key: "monster_bat",
    url: "data/images/dcss/monster/animals/bat.png"
  },
  {
    key: "monster_bear",
    url: "data/images/dcss/monster/animals/bear.png"
  },
  {
    key: "monster_big_fish",
    url: "data/images/dcss/monster/animals/big_fish.png"
  },
  {
    key: "monster_black_bear",
    url: "data/images/dcss/monster/animals/black_bear_old.png"
  },
  {
    key: "monster_black_mamba",
    url: "data/images/dcss/monster/animals/black_mamba_old.png"
  },
  {
    key: "monster_black_sheep",
    url: "data/images/dcss/monster/animals/black_sheep.png"
  },
  {
    key: "monster_blink_frog",
    url: "data/images/dcss/monster/animals/blink_frog_old.png"
  },
  {
    key: "monster_boring_beetle",
    url: "data/images/dcss/monster/animals/boring_beetle.png"
  },
  {
    key: "monster_boulder_beetle",
    url: "data/images/dcss/monster/animals/boulder_beetle.png"
  },
  {
    key: "monster_brain_worm",
    url: "data/images/dcss/monster/animals/brain_worm_old.png"
  },
  {
    key: "monster_bumblebee",
    url: "data/images/dcss/monster/animals/bumblebee.png"
  },
  {
    key: "monster_butterfly_10",
    url: "data/images/dcss/monster/animals/butterfly_10.png"
  },
  {
    key: "monster_butterfly_1",
    url: "data/images/dcss/monster/animals/butterfly_1_old.png"
  },
  {
    key: "monster_butterfly_2",
    url: "data/images/dcss/monster/animals/butterfly_2.png"
  },
  {
    key: "monster_butterfly_3",
    url: "data/images/dcss/monster/animals/butterfly_3_old.png"
  },
  {
    key: "monster_butterfly_4",
    url: "data/images/dcss/monster/animals/butterfly_4_old.png"
  },
  {
    key: "monster_butterfly_5",
    url: "data/images/dcss/monster/animals/butterfly_5.png"
  },
  {
    key: "monster_butterfly_6",
    url: "data/images/dcss/monster/animals/butterfly_6_old.png"
  },
  {
    key: "monster_butterfly_7",
    url: "data/images/dcss/monster/animals/butterfly_7.png"
  },
  {
    key: "monster_butterfly_8",
    url: "data/images/dcss/monster/animals/butterfly_8.png"
  },
  {
    key: "monster_butterfly_9",
    url: "data/images/dcss/monster/animals/butterfly_9.png"
  },
  {
    key: "monster_butterfly",
    url: "data/images/dcss/monster/animals/butterfly_old.png"
  },
  {
    key: "monster_catoblepas",
    url: "data/images/dcss/monster/animals/catoblepas.png"
  },
  {
    key: "monster_caustic_shrike",
    url: "data/images/dcss/monster/animals/caustic_shrike.png"
  },
  {
    key: "monster_crocodile",
    url: "data/images/dcss/monster/animals/crocodile.png"
  },
  {
    key: "monster_death_yak",
    url: "data/images/dcss/monster/animals/death_yak_old.png"
  },
  {
    key: "monster_elephant_demonic",
    url: "data/images/dcss/monster/animals/elephant_demonic_old.png"
  },
  {
    key: "monster_elephant_dire",
    url: "data/images/dcss/monster/animals/elephant_dire_old.png"
  },
  {
    key: "monster_elephant",
    url: "data/images/dcss/monster/animals/elephant_old.png"
  },
  {
    key: "monster_elephant_slug",
    url: "data/images/dcss/monster/animals/elephant_slug.png"
  },
  {
    key: "monster_emperor_scorpion",
    url: "data/images/dcss/monster/animals/emperor_scorpion.png"
  },
  {
    key: "monster_fire_bat",
    url: "data/images/dcss/monster/animals/fire_bat.png"
  },
  {
    key: "monster_fire_crab",
    url: "data/images/dcss/monster/animals/fire_crab.png"
  },
  {
    key: "monster_ghost_moth",
    url: "data/images/dcss/monster/animals/ghost_moth_old.png"
  },
  {
    key: "monster_giant_ant",
    url: "data/images/dcss/monster/animals/giant_ant.png"
  },
  {
    key: "monster_giant_bat",
    url: "data/images/dcss/monster/animals/giant_bat.png"
  },
  {
    key: "monster_giant_beetle",
    url: "data/images/dcss/monster/animals/giant_beetle.png"
  },
  {
    key: "monster_giant_blowfly",
    url: "data/images/dcss/monster/animals/giant_blowfly.png"
  },
  {
    key: "monster_giant_centipede",
    url: "data/images/dcss/monster/animals/giant_centipede.png"
  },
  {
    key: "monster_giant_cockroach",
    url: "data/images/dcss/monster/animals/giant_cockroach_old.png"
  },
  {
    key: "monster_giant_firefly",
    url: "data/images/dcss/monster/animals/giant_firefly.png"
  },
  {
    key: "monster_giant_frog",
    url: "data/images/dcss/monster/animals/giant_frog.png"
  },
  {
    key: "monster_giant_gecko",
    url: "data/images/dcss/monster/animals/giant_gecko.png"
  },
  {
    key: "monster_giant_goldfish",
    url: "data/images/dcss/monster/animals/giant_goldfish.png"
  },
  {
    key: "monster_giant_leech",
    url: "data/images/dcss/monster/animals/giant_leech_old.png"
  },
  {
    key: "monster_giant_lizard",
    url: "data/images/dcss/monster/animals/giant_lizard.png"
  },
  {
    key: "monster_giant_mite",
    url: "data/images/dcss/monster/animals/giant_mite.png"
  },
  {
    key: "monster_giant_mosquito",
    url: "data/images/dcss/monster/animals/giant_mosquito.png"
  },
  {
    key: "monster_giant_newt",
    url: "data/images/dcss/monster/animals/giant_newt_old.png"
  },
  {
    key: "monster_giant_scorpion",
    url: "data/images/dcss/monster/animals/giant_scorpion.png"
  },
  {
    key: "monster_giant_slug",
    url: "data/images/dcss/monster/animals/giant_slug.png"
  },
  {
    key: "monster_giant_snail",
    url: "data/images/dcss/monster/animals/giant_snail.png"
  },
  {
    key: "monster_giant_toad",
    url: "data/images/dcss/monster/animals/giant_toad.png"
  },
  {
    key: "monster_gila_monster",
    url: "data/images/dcss/monster/animals/gila_monster.png"
  },
  {
    key: "monster_green_rat",
    url: "data/images/dcss/monster/animals/green_rat.png"
  },
  {
    key: "monster_grey_rat",
    url: "data/images/dcss/monster/animals/grey_rat.png"
  },
  {
    key: "monster_grey_snake",
    url: "data/images/dcss/monster/animals/grey_snake.png"
  },
  {
    key: "monster_grizzly_bear",
    url: "data/images/dcss/monster/animals/grizzly_bear.png"
  },
  {
    key: "monster_hell_hog",
    url: "data/images/dcss/monster/animals/hell_hog_old.png"
  },
  {
    key: "monster_hell_hound",
    url: "data/images/dcss/monster/animals/hell_hound_old.png"
  },
  {
    key: "monster_hog",
    url: "data/images/dcss/monster/animals/hog_old.png"
  },
  {
    key: "monster_holy_swine",
    url: "data/images/dcss/monster/animals/holy_swine.png"
  },
  {
    key: "monster_hound",
    url: "data/images/dcss/monster/animals/hound.png"
  },
  {
    key: "monster_ice_beast",
    url: "data/images/dcss/monster/animals/ice_beast.png"
  },
  {
    key: "monster_iguana",
    url: "data/images/dcss/monster/animals/iguana.png"
  },
  {
    key: "monster_jackal",
    url: "data/images/dcss/monster/animals/jackal_old.png"
  },
  {
    key: "monster_jellyfish",
    url: "data/images/dcss/monster/animals/jellyfish.png"
  },
  {
    key: "monster_jumping_spider",
    url: "data/images/dcss/monster/animals/jumping_spider_old.png"
  },
  {
    key: "monster_killer_bee",
    url: "data/images/dcss/monster/animals/killer_bee.png"
  },
  {
    key: "monster_killer_bee_larva",
    url: "data/images/dcss/monster/animals/killer_bee_larva.png"
  },
  {
    key: "monster_komodo_dragon",
    url: "data/images/dcss/monster/animals/komodo_dragon.png"
  },
  {
    key: "monster_lava_fish",
    url: "data/images/dcss/monster/animals/lava_fish.png"
  },
  {
    key: "monster_lava_worm",
    url: "data/images/dcss/monster/animals/lava_worm.png"
  },
  {
    key: "monster_mana_viper",
    url: "data/images/dcss/monster/animals/mana_viper.png"
  },
  {
    key: "monster_moth_of_wrath",
    url: "data/images/dcss/monster/animals/moth_of_wrath_old.png"
  },
  {
    key: "monster_orange_rat",
    url: "data/images/dcss/monster/animals/orange_rat.png"
  },
  {
    key: "monster_orb_spider",
    url: "data/images/dcss/monster/animals/orb_spider.png"
  },
  {
    key: "monster_polar_bear",
    url: "data/images/dcss/monster/animals/polar_bear.png"
  },
  {
    key: "monster_queen_ant",
    url: "data/images/dcss/monster/animals/queen_ant_old.png"
  },
  {
    key: "monster_queen_bee",
    url: "data/images/dcss/monster/animals/queen_bee.png"
  },
  {
    key: "monster_quokka",
    url: "data/images/dcss/monster/animals/quokka_old.png"
  },
  {
    key: "monster_raiju",
    url: "data/images/dcss/monster/animals/raiju.png"
  },
  {
    key: "monster_rat",
    url: "data/images/dcss/monster/animals/rat.png"
  },
  {
    key: "monster_red_wasp",
    url: "data/images/dcss/monster/animals/red_wasp.png"
  },
  {
    key: "monster_redback",
    url: "data/images/dcss/monster/animals/redback_old.png"
  },
  {
    key: "monster_rock_worm",
    url: "data/images/dcss/monster/animals/rock_worm.png"
  },
  {
    key: "monster_salamander",
    url: "data/images/dcss/monster/animals/salamander.png"
  },
  {
    key: "monster_scorpion",
    url: "data/images/dcss/monster/animals/scorpion_old.png"
  },
  {
    key: "monster_sea_snake",
    url: "data/images/dcss/monster/animals/sea_snake_old.png"
  },
  {
    key: "monster_sheep",
    url: "data/images/dcss/monster/animals/sheep.png"
  },
  {
    key: "monster_shock_serpent",
    url: "data/images/dcss/monster/animals/shock_serpent.png"
  },
  {
    key: "monster_small_snake",
    url: "data/images/dcss/monster/animals/small_snake.png"
  },
  {
    key: "monster_snake",
    url: "data/images/dcss/monster/animals/snake.png"
  },
  {
    key: "monster_snapping_turtle",
    url: "data/images/dcss/monster/animals/snapping_turtle_old.png"
  },
  {
    key: "monster_snapping_turtle_shell",
    url: "data/images/dcss/monster/animals/snapping_turtle_shell.png"
  },
  {
    key: "monster_soldier_ant",
    url: "data/images/dcss/monster/animals/soldier_ant_old.png"
  },
  {
    key: "monster_spider",
    url: "data/images/dcss/monster/animals/spider.png"
  },
  {
    key: "monster_spiny_frog",
    url: "data/images/dcss/monster/animals/spiny_frog.png"
  },
  {
    key: "monster_spiny_worm",
    url: "data/images/dcss/monster/animals/spiny_worm.png"
  },
  {
    key: "monster_tarantella",
    url: "data/images/dcss/monster/animals/tarantella_old.png"
  },
  {
    key: "monster_trapdoor_spider",
    url: "data/images/dcss/monster/animals/trapdoor_spider_old.png"
  },
  {
    key: "monster_turtle",
    url: "data/images/dcss/monster/animals/turtle.png"
  },
  {
    key: "monster_viper",
    url: "data/images/dcss/monster/animals/viper.png"
  },
  {
    key: "monster_war_dog",
    url: "data/images/dcss/monster/animals/war_dog.png"
  },
  {
    key: "monster_warg",
    url: "data/images/dcss/monster/animals/warg.png"
  },
  {
    key: "monster_water_moccasin",
    url: "data/images/dcss/monster/animals/water_moccasin_old.png"
  },
  {
    key: "monster_wolf",
    url: "data/images/dcss/monster/animals/wolf.png"
  },
  {
    key: "monster_wolf_spider",
    url: "data/images/dcss/monster/animals/wolf_spider_old.png"
  },
  {
    key: "monster_worker_ant",
    url: "data/images/dcss/monster/animals/worker_ant.png"
  },
  {
    key: "monster_worm",
    url: "data/images/dcss/monster/animals/worm_old.png"
  },
  {
    key: "monster_yak",
    url: "data/images/dcss/monster/animals/yak_old.png"
  },
  {
    key: "monster_yellow_snake",
    url: "data/images/dcss/monster/animals/yellow_snake.png"
  },
  {
    key: "monster_yellow_wasp",
    url: "data/images/dcss/monster/animals/yellow_wasp.png"
  },
  {
    key: "monster_anubis_guard",
    url: "data/images/dcss/monster/anubis_guard.png"
  },
  {
    key: "monster_big_kobold",
    url: "data/images/dcss/monster/big_kobold_old.png"
  },
  {
    key: "monster_boggart",
    url: "data/images/dcss/monster/boggart_old.png"
  },
  {
    key: "monster_brown_ooze",
    url: "data/images/dcss/monster/brown_ooze.png"
  },
  {
    key: "monster_centaur-melee",
    url: "data/images/dcss/monster/centaur-melee.png"
  },
  {
    key: "monster_centaur",
    url: "data/images/dcss/monster/centaur.png"
  },
  {
    key: "monster_centaur_warrior-melee",
    url: "data/images/dcss/monster/centaur_warrior-melee.png"
  },
  {
    key: "monster_centaur_warrior",
    url: "data/images/dcss/monster/centaur_warrior.png"
  },
  {
    key: "monster_cyclops",
    url: "data/images/dcss/monster/cyclops_old.png"
  },
  {
    key: "monster_daeva",
    url: "data/images/dcss/monster/daeva.png"
  },
  {
    key: "monster_death_drake",
    url: "data/images/dcss/monster/death_drake.png"
  },
  {
    key: "monster_death_knight",
    url: "data/images/dcss/monster/death_knight.png"
  },
  {
    key: "monster_deep_dwarf",
    url: "data/images/dcss/monster/deep_dwarf.png"
  },
  {
    key: "monster_deep_dwarf_artificer",
    url: "data/images/dcss/monster/deep_dwarf_artificer.png"
  },
  {
    key: "monster_deep_dwarf_berserker",
    url: "data/images/dcss/monster/deep_dwarf_berserker.png"
  },
  {
    key: "monster_deep_dwarf_death_knight",
    url: "data/images/dcss/monster/deep_dwarf_death_knight.png"
  },
  {
    key: "monster_deep_elf_annihilator",
    url: "data/images/dcss/monster/deep_elf_annihilator.png"
  },
  {
    key: "monster_deep_elf_blademaster",
    url: "data/images/dcss/monster/deep_elf_blademaster.png"
  },
  {
    key: "monster_deep_elf_conjurer",
    url: "data/images/dcss/monster/deep_elf_conjurer.png"
  },
  {
    key: "monster_deep_elf_death_mage",
    url: "data/images/dcss/monster/deep_elf_death_mage.png"
  },
  {
    key: "monster_deep_elf_demonologist",
    url: "data/images/dcss/monster/deep_elf_demonologist.png"
  },
  {
    key: "monster_deep_elf_fighter",
    url: "data/images/dcss/monster/deep_elf_fighter_old.png"
  },
  {
    key: "monster_deep_elf_high_priest",
    url: "data/images/dcss/monster/deep_elf_high_priest.png"
  },
  {
    key: "monster_deep_elf_knight",
    url: "data/images/dcss/monster/deep_elf_knight_old.png"
  },
  {
    key: "monster_deep_elf_mage",
    url: "data/images/dcss/monster/deep_elf_mage.png"
  },
  {
    key: "monster_deep_elf_master_archer",
    url: "data/images/dcss/monster/deep_elf_master_archer.png"
  },
  {
    key: "monster_deep_elf_priest",
    url: "data/images/dcss/monster/deep_elf_priest.png"
  },
  {
    key: "monster_deep_elf_soldier",
    url: "data/images/dcss/monster/deep_elf_soldier.png"
  },
  {
    key: "monster_deep_elf_sorcerer",
    url: "data/images/dcss/monster/deep_elf_sorcerer.png"
  },
  {
    key: "monster_deep_elf_summoner",
    url: "data/images/dcss/monster/deep_elf_summoner.png"
  },
  {
    key: "monster_deep_troll",
    url: "data/images/dcss/monster/deep_troll.png"
  },
  {
    key: "monster_deep_troll_berserker",
    url: "data/images/dcss/monster/deep_troll_berserker.png"
  },
  {
    key: "monster_deep_troll_earth_mage",
    url: "data/images/dcss/monster/deep_troll_earth_mage.png"
  },
  {
    key: "monster_deep_troll_shaman",
    url: "data/images/dcss/monster/deep_troll_shaman.png"
  },
  {
    key: "monster_abomination_large",
    url: "data/images/dcss/monster/demons/abomination_large.png"
  },
  {
    key: "monster_abomination_large_1",
    url: "data/images/dcss/monster/demons/abomination_large_1.png"
  },
  {
    key: "monster_abomination_large_2",
    url: "data/images/dcss/monster/demons/abomination_large_2.png"
  },
  {
    key: "monster_abomination_large_3",
    url: "data/images/dcss/monster/demons/abomination_large_3.png"
  },
  {
    key: "monster_abomination_large_4",
    url: "data/images/dcss/monster/demons/abomination_large_4.png"
  },
  {
    key: "monster_abomination_large_5",
    url: "data/images/dcss/monster/demons/abomination_large_5.png"
  },
  {
    key: "monster_abomination_large_6",
    url: "data/images/dcss/monster/demons/abomination_large_6.png"
  },
  {
    key: "monster_abomination_small",
    url: "data/images/dcss/monster/demons/abomination_small.png"
  },
  {
    key: "monster_abomination_small_1",
    url: "data/images/dcss/monster/demons/abomination_small_1.png"
  },
  {
    key: "monster_balrug",
    url: "data/images/dcss/monster/demons/balrug_old.png"
  },
  {
    key: "monster_beast",
    url: "data/images/dcss/monster/demons/beast.png"
  },
  {
    key: "monster_blizzard_demon",
    url: "data/images/dcss/monster/demons/blizzard_demon.png"
  },
  {
    key: "monster_blue_death",
    url: "data/images/dcss/monster/demons/blue_death.png"
  },
  {
    key: "monster_blue_devil",
    url: "data/images/dcss/monster/demons/blue_devil_old.png"
  },
  {
    key: "monster_cacodemon",
    url: "data/images/dcss/monster/demons/cacodemon.png"
  },
  {
    key: "monster_chaos_spawn",
    url: "data/images/dcss/monster/demons/chaos_spawn.png"
  },
  {
    key: "monster_chaos_spawn_1",
    url: "data/images/dcss/monster/demons/chaos_spawn_1.png"
  },
  {
    key: "monster_chaos_spawn_2",
    url: "data/images/dcss/monster/demons/chaos_spawn_2.png"
  },
  {
    key: "monster_chaos_spawn_3",
    url: "data/images/dcss/monster/demons/chaos_spawn_3.png"
  },
  {
    key: "monster_chaos_spawn_4",
    url: "data/images/dcss/monster/demons/chaos_spawn_4.png"
  },
  {
    key: "monster_chaos_spawn_5",
    url: "data/images/dcss/monster/demons/chaos_spawn_5.png"
  },
  {
    key: "monster_cigotuvis_monster",
    url: "data/images/dcss/monster/demons/cigotuvis_monster.png"
  },
  {
    key: "monster_demonic_crawler",
    url: "data/images/dcss/monster/demons/demonic_crawler.png"
  },
  {
    key: "monster_dimme",
    url: "data/images/dcss/monster/demons/dimme.png"
  },
  {
    key: "monster_efreet",
    url: "data/images/dcss/monster/demons/efreet.png"
  },
  {
    key: "monster_executioner",
    url: "data/images/dcss/monster/demons/executioner.png"
  },
  {
    key: "monster_fiend",
    url: "data/images/dcss/monster/demons/fiend.png"
  },
  {
    key: "monster_green_death",
    url: "data/images/dcss/monster/demons/green_death.png"
  },
  {
    key: "monster_hairy_devil",
    url: "data/images/dcss/monster/demons/hairy_devil.png"
  },
  {
    key: "monster_hell_sentinel",
    url: "data/images/dcss/monster/demons/hell_sentinel.png"
  },
  {
    key: "monster_hellion",
    url: "data/images/dcss/monster/demons/hellion_old.png"
  },
  {
    key: "monster_hellwing",
    url: "data/images/dcss/monster/demons/hellwing.png"
  },
  {
    key: "monster_ice_devil",
    url: "data/images/dcss/monster/demons/ice_devil.png"
  },
  {
    key: "monster_ice_fiend",
    url: "data/images/dcss/monster/demons/ice_fiend.png"
  },
  {
    key: "monster_imp",
    url: "data/images/dcss/monster/demons/imp.png"
  },
  {
    key: "monster_iron_devil",
    url: "data/images/dcss/monster/demons/iron_devil.png"
  },
  {
    key: "monster_iron_imp",
    url: "data/images/dcss/monster/demons/iron_imp_old.png"
  },
  {
    key: "monster_lemure",
    url: "data/images/dcss/monster/demons/lemure.png"
  },
  {
    key: "monster_lorocyproca",
    url: "data/images/dcss/monster/demons/lorocyproca_old.png"
  },
  {
    key: "monster_midge",
    url: "data/images/dcss/monster/demons/midge.png"
  },
  {
    key: "monster_neqoxec",
    url: "data/images/dcss/monster/demons/neqoxec_old.png"
  },
  {
    key: "monster_orange_demon",
    url: "data/images/dcss/monster/demons/orange_demon_old.png"
  },
  {
    key: "monster_pit_fiend",
    url: "data/images/dcss/monster/demons/pit_fiend.png"
  },
  {
    key: "monster_quasit",
    url: "data/images/dcss/monster/demons/quasit_old.png"
  },
  {
    key: "monster_rakshasa",
    url: "data/images/dcss/monster/demons/rakshasa.png"
  },
  {
    key: "monster_reaper",
    url: "data/images/dcss/monster/demons/reaper_old.png"
  },
  {
    key: "monster_red_devil",
    url: "data/images/dcss/monster/demons/red_devil_old.png"
  },
  {
    key: "monster_rotting_devil",
    url: "data/images/dcss/monster/demons/rotting_devil.png"
  },
  {
    key: "monster_rust_devil",
    url: "data/images/dcss/monster/demons/rust_devil.png"
  },
  {
    key: "monster_shadow_demon",
    url: "data/images/dcss/monster/demons/shadow_demon.png"
  },
  {
    key: "monster_shadow_fiend",
    url: "data/images/dcss/monster/demons/shadow_fiend_old.png"
  },
  {
    key: "monster_shadow_imp",
    url: "data/images/dcss/monster/demons/shadow_imp_old.png"
  },
  {
    key: "monster_sixfirhy",
    url: "data/images/dcss/monster/demons/sixfirhy_old.png"
  },
  {
    key: "monster_smoke_demon",
    url: "data/images/dcss/monster/demons/smoke_demon_old.png"
  },
  {
    key: "monster_soul_eater",
    url: "data/images/dcss/monster/demons/soul_eater.png"
  },
  {
    key: "monster_sun_demon",
    url: "data/images/dcss/monster/demons/sun_demon.png"
  },
  {
    key: "monster_tentacled_monstrosity",
    url: "data/images/dcss/monster/demons/tentacled_monstrosity.png"
  },
  {
    key: "monster_tormentor",
    url: "data/images/dcss/monster/demons/tormentor_old.png"
  },
  {
    key: "monster_ufetubus",
    url: "data/images/dcss/monster/demons/ufetubus.png"
  },
  {
    key: "monster_ugly_thing",
    url: "data/images/dcss/monster/demons/ugly_thing.png"
  },
  {
    key: "monster_ugly_thing_1",
    url: "data/images/dcss/monster/demons/ugly_thing_1.png"
  },
  {
    key: "monster_ugly_thing_2",
    url: "data/images/dcss/monster/demons/ugly_thing_2.png"
  },
  {
    key: "monster_ugly_thing_3",
    url: "data/images/dcss/monster/demons/ugly_thing_3.png"
  },
  {
    key: "monster_ugly_thing_4",
    url: "data/images/dcss/monster/demons/ugly_thing_4.png"
  },
  {
    key: "monster_ugly_thing_5",
    url: "data/images/dcss/monster/demons/ugly_thing_5.png"
  },
  {
    key: "monster_unspeakable_bottom",
    url: "data/images/dcss/monster/demons/unspeakable_bottom.png"
  },
  {
    key: "monster_unspeakable_top",
    url: "data/images/dcss/monster/demons/unspeakable_top.png"
  },
  {
    key: "monster_very_ugly_thing",
    url: "data/images/dcss/monster/demons/very_ugly_thing.png"
  },
  {
    key: "monster_very_ugly_thing_1",
    url: "data/images/dcss/monster/demons/very_ugly_thing_1.png"
  },
  {
    key: "monster_very_ugly_thing_2",
    url: "data/images/dcss/monster/demons/very_ugly_thing_2.png"
  },
  {
    key: "monster_very_ugly_thing_3",
    url: "data/images/dcss/monster/demons/very_ugly_thing_3.png"
  },
  {
    key: "monster_very_ugly_thing_4",
    url: "data/images/dcss/monster/demons/very_ugly_thing_4.png"
  },
  {
    key: "monster_very_ugly_thing_5",
    url: "data/images/dcss/monster/demons/very_ugly_thing_5.png"
  },
  {
    key: "monster_white_imp",
    url: "data/images/dcss/monster/demons/white_imp.png"
  },
  {
    key: "monster_ynoxinul",
    url: "data/images/dcss/monster/demons/ynoxinul_old.png"
  },
  {
    key: "monster_black_sun",
    url: "data/images/dcss/monster/demonspawn/black_sun.png"
  },
  {
    key: "monster_blood_saint",
    url: "data/images/dcss/monster/demonspawn/blood_saint.png"
  },
  {
    key: "monster_chaos_champion",
    url: "data/images/dcss/monster/demonspawn/chaos_champion.png"
  },
  {
    key: "monster_corrupter",
    url: "data/images/dcss/monster/demonspawn/corrupter.png"
  },
  {
    key: "monster_demonspawn",
    url: "data/images/dcss/monster/demonspawn/demonspawn.png"
  },
  {
    key: "monster_gelid",
    url: "data/images/dcss/monster/demonspawn/gelid.png"
  },
  {
    key: "monster_infernal",
    url: "data/images/dcss/monster/demonspawn/infernal.png"
  },
  {
    key: "monster_monstrous",
    url: "data/images/dcss/monster/demonspawn/monstrous.png"
  },
  {
    key: "monster_putrid",
    url: "data/images/dcss/monster/demonspawn/putrid.png"
  },
  {
    key: "monster_torturous",
    url: "data/images/dcss/monster/demonspawn/torturous.png"
  },
  {
    key: "monster_warmonger",
    url: "data/images/dcss/monster/demonspawn/warmonger.png"
  },
  {
    key: "monster_dryad",
    url: "data/images/dcss/monster/dryad.png"
  },
  {
    key: "monster_dwarf",
    url: "data/images/dcss/monster/dwarf_old.png"
  },
  {
    key: "monster_elf",
    url: "data/images/dcss/monster/elf_old.png"
  },
  {
    key: "monster_enchantress_human",
    url: "data/images/dcss/monster/enchantress_human.png"
  },
  {
    key: "monster_entropy_weaver",
    url: "data/images/dcss/monster/entropy_weaver.png"
  },
  {
    key: "monster_ettin",
    url: "data/images/dcss/monster/ettin_old.png"
  },
  {
    key: "monster_eye_of_devastation",
    url: "data/images/dcss/monster/eyes/eye_of_devastation_old.png"
  },
  {
    key: "monster_eye_of_draining",
    url: "data/images/dcss/monster/eyes/eye_of_draining.png"
  },
  {
    key: "monster_giant_eyeball",
    url: "data/images/dcss/monster/eyes/giant_eyeball.png"
  },
  {
    key: "monster_golden_eye",
    url: "data/images/dcss/monster/eyes/golden_eye_old.png"
  },
  {
    key: "monster_great_orb_of_eyes",
    url: "data/images/dcss/monster/eyes/great_orb_of_eyes.png"
  },
  {
    key: "monster_shining_eye",
    url: "data/images/dcss/monster/eyes/shining_eye_old.png"
  },
  {
    key: "monster_faun",
    url: "data/images/dcss/monster/faun.png"
  },
  {
    key: "monster_fire_drake",
    url: "data/images/dcss/monster/fire_drake.png"
  },
  {
    key: "monster_fire_giant",
    url: "data/images/dcss/monster/fire_giant_old.png"
  },
  {
    key: "monster_forest_drake",
    url: "data/images/dcss/monster/forest_drake.png"
  },
  {
    key: "monster_formicid",
    url: "data/images/dcss/monster/formicid.png"
  },
  {
    key: "monster_formicid_venom_mage",
    url: "data/images/dcss/monster/formicid_venom_mage.png"
  },
  {
    key: "monster_frost_giant",
    url: "data/images/dcss/monster/frost_giant_old.png"
  },
  {
    key: "monster_briar_patch",
    url: "data/images/dcss/monster/fungi_plants/briar_patch.png"
  },
  {
    key: "monster_deathcap",
    url: "data/images/dcss/monster/fungi_plants/deathcap.png"
  },
  {
    key: "monster_giant_spore",
    url: "data/images/dcss/monster/fungi_plants/giant_spore.png"
  },
  {
    key: "monster_hyperactive_ballistomycete",
    url: "data/images/dcss/monster/fungi_plants/hyperactive_ballistomycete.png"
  },
  {
    key: "monster_oklob_plant",
    url: "data/images/dcss/monster/fungi_plants/oklob_plant.png"
  },
  {
    key: "monster_plant",
    url: "data/images/dcss/monster/fungi_plants/plant.png"
  },
  {
    key: "monster_plant_crypt",
    url: "data/images/dcss/monster/fungi_plants/plant_crypt.png"
  },
  {
    key: "monster_plant_demonic",
    url: "data/images/dcss/monster/fungi_plants/plant_demonic.png"
  },
  {
    key: "monster_thorn_hunter",
    url: "data/images/dcss/monster/fungi_plants/thorn_hunter.png"
  },
  {
    key: "monster_thorn_lotus",
    url: "data/images/dcss/monster/fungi_plants/thorn_lotus.png"
  },
  {
    key: "monster_treant",
    url: "data/images/dcss/monster/fungi_plants/treant.png"
  },
  {
    key: "monster_vine_stalker",
    url: "data/images/dcss/monster/fungi_plants/vine_stalker.png"
  },
  {
    key: "monster_wandering_mushroom",
    url: "data/images/dcss/monster/fungi_plants/wandering_mushroom_old.png"
  },
  {
    key: "monster_giant_amoeba",
    url: "data/images/dcss/monster/giant_amoeba_old.png"
  },
  {
    key: "monster_giant_orange_brain",
    url: "data/images/dcss/monster/giant_orange_brain.png"
  },
  {
    key: "monster_glowing_shapeshifter",
    url: "data/images/dcss/monster/glowing_shapeshifter.png"
  },
  {
    key: "monster_gnoll",
    url: "data/images/dcss/monster/gnoll_old.png"
  },
  {
    key: "monster_gnoll_sergeant",
    url: "data/images/dcss/monster/gnoll_sergeant.png"
  },
  {
    key: "monster_gnoll_shaman",
    url: "data/images/dcss/monster/gnoll_shaman.png"
  },
  {
    key: "monster_gnome",
    url: "data/images/dcss/monster/gnome.png"
  },
  {
    key: "monster_goblin",
    url: "data/images/dcss/monster/goblin_old.png"
  },
  {
    key: "monster_golden_dragon",
    url: "data/images/dcss/monster/golden_dragon.png"
  },
  {
    key: "monster_grand_avatar",
    url: "data/images/dcss/monster/grand_avatar.png"
  },
  {
    key: "monster_greater_naga",
    url: "data/images/dcss/monster/greater_naga.png"
  },
  {
    key: "monster_griffon",
    url: "data/images/dcss/monster/griffon.png"
  },
  {
    key: "monster_guardian_naga",
    url: "data/images/dcss/monster/guardian_naga.png"
  },
  {
    key: "monster_guardian_serpent",
    url: "data/images/dcss/monster/guardian_serpent_old.png"
  },
  {
    key: "monster_halfling",
    url: "data/images/dcss/monster/halfling_old.png"
  },
  {
    key: "monster_harpy",
    url: "data/images/dcss/monster/harpy.png"
  },
  {
    key: "monster_hell_knight",
    url: "data/images/dcss/monster/hell_knight_old.png"
  },
  {
    key: "monster_hill_giant",
    url: "data/images/dcss/monster/hill_giant_old.png"
  },
  {
    key: "monster_hippogriff",
    url: "data/images/dcss/monster/hippogriff_old.png"
  },
  {
    key: "monster_hobgoblin",
    url: "data/images/dcss/monster/hobgoblin_old.png"
  },
  {
    key: "monster_angel_mace",
    url: "data/images/dcss/monster/holy/angel_mace.png"
  },
  {
    key: "monster_angel",
    url: "data/images/dcss/monster/holy/angel_old.png"
  },
  {
    key: "monster_apis",
    url: "data/images/dcss/monster/holy/apis.png"
  },
  {
    key: "monster_centaur_paladin",
    url: "data/images/dcss/monster/holy/centaur_paladin.png"
  },
  {
    key: "monster_cherub",
    url: "data/images/dcss/monster/holy/cherub.png"
  },
  {
    key: "monster_eastern_dragon",
    url: "data/images/dcss/monster/holy/eastern_dragon.png"
  },
  {
    key: "monster_holy_dragon",
    url: "data/images/dcss/monster/holy/holy_dragon.png"
  },
  {
    key: "monster_ophan",
    url: "data/images/dcss/monster/holy/ophan.png"
  },
  {
    key: "monster_paladin",
    url: "data/images/dcss/monster/holy/paladin.png"
  },
  {
    key: "monster_seraph_bottom",
    url: "data/images/dcss/monster/holy/seraph_bottom.png"
  },
  {
    key: "monster_seraph_top",
    url: "data/images/dcss/monster/holy/seraph_top.png"
  },
  {
    key: "monster_shedu",
    url: "data/images/dcss/monster/holy/shedu_old.png"
  },
  {
    key: "monster_human_monk_ghost",
    url: "data/images/dcss/monster/human_monk_ghost.png"
  },
  {
    key: "monster_human",
    url: "data/images/dcss/monster/human_old.png"
  },
  {
    key: "monster_human_slave",
    url: "data/images/dcss/monster/human_slave.png"
  },
  {
    key: "monster_hydrataur",
    url: "data/images/dcss/monster/hydrataur.png"
  },
  {
    key: "monster_iron_troll",
    url: "data/images/dcss/monster/iron_troll.png"
  },
  {
    key: "monster_iron_troll_monk_ghost",
    url: "data/images/dcss/monster/iron_troll_monk_ghost.png"
  },
  {
    key: "monster_ironbrand_convoker",
    url: "data/images/dcss/monster/ironbrand_convoker.png"
  },
  {
    key: "monster_ironheart_preserver",
    url: "data/images/dcss/monster/ironheart_preserver.png"
  },
  {
    key: "monster_juggernaut",
    url: "data/images/dcss/monster/juggernaut.png"
  },
  {
    key: "monster_kenku_winged",
    url: "data/images/dcss/monster/kenku_winged.png"
  },
  {
    key: "monster_killer_klown",
    url: "data/images/dcss/monster/killer_klown.png"
  },
  {
    key: "monster_killer_klown_blue",
    url: "data/images/dcss/monster/killer_klown_blue.png"
  },
  {
    key: "monster_killer_klown_green",
    url: "data/images/dcss/monster/killer_klown_green.png"
  },
  {
    key: "monster_killer_klown_purple",
    url: "data/images/dcss/monster/killer_klown_purple.png"
  },
  {
    key: "monster_killer_klown_red",
    url: "data/images/dcss/monster/killer_klown_red.png"
  },
  {
    key: "monster_killer_klown_yellow",
    url: "data/images/dcss/monster/killer_klown_yellow.png"
  },
  {
    key: "monster_kobold_demonologist",
    url: "data/images/dcss/monster/kobold_demonologist.png"
  },
  {
    key: "monster_kobold",
    url: "data/images/dcss/monster/kobold_old.png"
  },
  {
    key: "monster_labrat_unseen",
    url: "data/images/dcss/monster/labrat_unseen.png"
  },
  {
    key: "monster_lindwurm",
    url: "data/images/dcss/monster/lindwurm.png"
  },
  {
    key: "monster_manticore",
    url: "data/images/dcss/monster/manticore.png"
  },
  {
    key: "monster_merfolk",
    url: "data/images/dcss/monster/merfolk.png"
  },
  {
    key: "monster_merfolk_aquamancer",
    url: "data/images/dcss/monster/merfolk_aquamancer_old.png"
  },
  {
    key: "monster_merfolk_aquamancer_water",
    url: "data/images/dcss/monster/merfolk_aquamancer_water_old.png"
  },
  {
    key: "monster_merfolk_avatar",
    url: "data/images/dcss/monster/merfolk_avatar.png"
  },
  {
    key: "monster_merfolk_avatar_water",
    url: "data/images/dcss/monster/merfolk_avatar_water.png"
  },
  {
    key: "monster_merfolk_fighter",
    url: "data/images/dcss/monster/merfolk_fighter.png"
  },
  {
    key: "monster_merfolk_fighter_water",
    url: "data/images/dcss/monster/merfolk_fighter_water.png"
  },
  {
    key: "monster_merfolk_impaler",
    url: "data/images/dcss/monster/merfolk_impaler_old.png"
  },
  {
    key: "monster_merfolk_impaler_water",
    url: "data/images/dcss/monster/merfolk_impaler_water_old.png"
  },
  {
    key: "monster_merfolk_javelineer",
    url: "data/images/dcss/monster/merfolk_javelineer_old.png"
  },
  {
    key: "monster_merfolk_javelineer_water",
    url: "data/images/dcss/monster/merfolk_javelineer_water_old.png"
  },
  {
    key: "monster_merfolk_plain",
    url: "data/images/dcss/monster/merfolk_plain.png"
  },
  {
    key: "monster_merfolk_plain_water",
    url: "data/images/dcss/monster/merfolk_plain_water.png"
  },
  {
    key: "monster_merfolk_water",
    url: "data/images/dcss/monster/merfolk_water.png"
  },
  {
    key: "monster_mermaid",
    url: "data/images/dcss/monster/mermaid.png"
  },
  {
    key: "monster_mermaid_water",
    url: "data/images/dcss/monster/mermaid_water.png"
  },
  {
    key: "monster_minotaur",
    url: "data/images/dcss/monster/minotaur.png"
  },
  {
    key: "monster_moth_of_suppression",
    url: "data/images/dcss/monster/moth_of_suppression.png"
  },
  {
    key: "monster_mutant_beast",
    url: "data/images/dcss/monster/mutant_beast.png"
  },
  {
    key: "monster_naga",
    url: "data/images/dcss/monster/naga.png"
  },
  {
    key: "monster_naga_mage",
    url: "data/images/dcss/monster/naga_mage.png"
  },
  {
    key: "monster_naga_ritualist",
    url: "data/images/dcss/monster/naga_ritualist.png"
  },
  {
    key: "monster_naga_sharpshooter",
    url: "data/images/dcss/monster/naga_sharpshooter.png"
  },
  {
    key: "monster_naga_warrior",
    url: "data/images/dcss/monster/naga_warrior.png"
  },
  {
    key: "monster_naga_warrior_unique",
    url: "data/images/dcss/monster/naga_warrior_unique.png"
  },
  {
    key: "monster_necromancer",
    url: "data/images/dcss/monster/necromancer_old.png"
  },
  {
    key: "monster_ogre_mage",
    url: "data/images/dcss/monster/ogre_mage_old.png"
  },
  {
    key: "monster_ogre",
    url: "data/images/dcss/monster/ogre_old.png"
  },
  {
    key: "monster_orb_guardian",
    url: "data/images/dcss/monster/orb_guardian_old.png"
  },
  {
    key: "monster_orc_high_priest",
    url: "data/images/dcss/monster/orc_high_priest_old.png"
  },
  {
    key: "monster_orc_knight",
    url: "data/images/dcss/monster/orc_knight_old.png"
  },
  {
    key: "monster_orc",
    url: "data/images/dcss/monster/orc_old.png"
  },
  {
    key: "monster_orc_priest",
    url: "data/images/dcss/monster/orc_priest_old.png"
  },
  {
    key: "monster_orc_sorcerer",
    url: "data/images/dcss/monster/orc_sorcerer_old.png"
  },
  {
    key: "monster_orc_warlord",
    url: "data/images/dcss/monster/orc_warlord.png"
  },
  {
    key: "monster_orc_warrior",
    url: "data/images/dcss/monster/orc_warrior_old.png"
  },
  {
    key: "monster_orc_wizard",
    url: "data/images/dcss/monster/orc_wizard_old.png"
  },
  {
    key: "monster_demon_body_armor_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_armor_bottom.png"
  },
  {
    key: "monster_demon_body_armor_top",
    url: "data/images/dcss/monster/panlord/demon_body_armor_top.png"
  },
  {
    key: "monster_demon_body_caterpillar_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_caterpillar_bottom.png"
  },
  {
    key: "monster_demon_body_caterpillar_top",
    url: "data/images/dcss/monster/panlord/demon_body_caterpillar_top.png"
  },
  {
    key: "monster_demon_body_crouch_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_crouch_bottom.png"
  },
  {
    key: "monster_demon_body_crouch_top",
    url: "data/images/dcss/monster/panlord/demon_body_crouch_top.png"
  },
  {
    key: "monster_demon_body_fat_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_fat_bottom_old.png"
  },
  {
    key: "monster_demon_body_fat_top",
    url: "data/images/dcss/monster/panlord/demon_body_fat_top_old.png"
  },
  {
    key: "monster_demon_body_fatter_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_fatter_bottom_old.png"
  },
  {
    key: "monster_demon_body_fatter_top",
    url: "data/images/dcss/monster/panlord/demon_body_fatter_top_old.png"
  },
  {
    key: "monster_demon_body_mantis_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_mantis_bottom.png"
  },
  {
    key: "monster_demon_body_mantis_top",
    url: "data/images/dcss/monster/panlord/demon_body_mantis_top.png"
  },
  {
    key: "monster_demon_body_normal_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_normal_bottom_old.png"
  },
  {
    key: "monster_demon_body_normal_top",
    url: "data/images/dcss/monster/panlord/demon_body_normal_top_old.png"
  },
  {
    key: "monster_demon_body_skeletal_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_skeletal_bottom.png"
  },
  {
    key: "monster_demon_body_skeletal_top",
    url: "data/images/dcss/monster/panlord/demon_body_skeletal_top.png"
  },
  {
    key: "monster_demon_body_spiked_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_spiked_bottom_old.png"
  },
  {
    key: "monster_demon_body_spiked_top",
    url: "data/images/dcss/monster/panlord/demon_body_spiked_top_old.png"
  },
  {
    key: "monster_demon_body_spotty_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_spotty_bottom_old.png"
  },
  {
    key: "monster_demon_body_spotty_top",
    url: "data/images/dcss/monster/panlord/demon_body_spotty_top_old.png"
  },
  {
    key: "monster_demon_body_succubus_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_succubus_bottom.png"
  },
  {
    key: "monster_demon_body_succubus_top",
    url: "data/images/dcss/monster/panlord/demon_body_succubus_top.png"
  },
  {
    key: "monster_demon_body_tentacley_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_tentacley_bottom.png"
  },
  {
    key: "monster_demon_body_tentacley_top",
    url: "data/images/dcss/monster/panlord/demon_body_tentacley_top.png"
  },
  {
    key: "monster_demon_body_thin_bottom",
    url: "data/images/dcss/monster/panlord/demon_body_thin_bottom_old.png"
  },
  {
    key: "monster_demon_body_thin_top",
    url: "data/images/dcss/monster/panlord/demon_body_thin_top_old.png"
  },
  {
    key: "monster_demon_head_bird_top",
    url: "data/images/dcss/monster/panlord/demon_head_bird_top_old.png"
  },
  {
    key: "monster_demon_head_boxes_top",
    url: "data/images/dcss/monster/panlord/demon_head_boxes_top.png"
  },
  {
    key: "monster_demon_head_brain_top",
    url: "data/images/dcss/monster/panlord/demon_head_brain_top.png"
  },
  {
    key: "monster_demon_head_butterfly_top",
    url: "data/images/dcss/monster/panlord/demon_head_butterfly_top.png"
  },
  {
    key: "monster_demon_head_cow_skull_top",
    url: "data/images/dcss/monster/panlord/demon_head_cow_skull_top.png"
  },
  {
    key: "monster_demon_head_cthulhu_top",
    url: "data/images/dcss/monster/panlord/demon_head_cthulhu_top_old.png"
  },
  {
    key: "monster_demon_head_elephant_top",
    url: "data/images/dcss/monster/panlord/demon_head_elephant_top_old.png"
  },
  {
    key: "monster_demon_head_eyeball_top",
    url: "data/images/dcss/monster/panlord/demon_head_eyeball_top_old.png"
  },
  {
    key: "monster_demon_head_fly_top",
    url: "data/images/dcss/monster/panlord/demon_head_fly_top.png"
  },
  {
    key: "monster_demon_head_frog_top",
    url: "data/images/dcss/monster/panlord/demon_head_frog_top.png"
  },
  {
    key: "monster_demon_head_fungus_top",
    url: "data/images/dcss/monster/panlord/demon_head_fungus_top.png"
  },
  {
    key: "monster_demon_head_hair_top",
    url: "data/images/dcss/monster/panlord/demon_head_hair_top.png"
  },
  {
    key: "monster_demon_head_heads_top",
    url: "data/images/dcss/monster/panlord/demon_head_heads_top.png"
  },
  {
    key: "monster_demon_head_helmet_top",
    url: "data/images/dcss/monster/panlord/demon_head_helmet_top_old.png"
  },
  {
    key: "monster_demon_head_horn_top",
    url: "data/images/dcss/monster/panlord/demon_head_horn_top.png"
  },
  {
    key: "monster_demon_head_horns_top",
    url: "data/images/dcss/monster/panlord/demon_head_horns_top_old.png"
  },
  {
    key: "monster_demon_head_horse_top",
    url: "data/images/dcss/monster/panlord/demon_head_horse_top_old.png"
  },
  {
    key: "monster_demon_head_incubus_top",
    url: "data/images/dcss/monster/panlord/demon_head_incubus_top.png"
  },
  {
    key: "monster_demon_head_medusa_top",
    url: "data/images/dcss/monster/panlord/demon_head_medusa_top_old.png"
  },
  {
    key: "monster_demon_head_monkey_top",
    url: "data/images/dcss/monster/panlord/demon_head_monkey_top_old.png"
  },
  {
    key: "monster_demon_head_mouse_top",
    url: "data/images/dcss/monster/panlord/demon_head_mouse_top_old.png"
  },
  {
    key: "monster_demon_head_ram_top",
    url: "data/images/dcss/monster/panlord/demon_head_ram_top_old.png"
  },
  {
    key: "monster_demon_head_rhino_top",
    url: "data/images/dcss/monster/panlord/demon_head_rhino_top_old.png"
  },
  {
    key: "monster_demon_head_skull_top",
    url: "data/images/dcss/monster/panlord/demon_head_skull_top.png"
  },
  {
    key: "monster_demon_head_succubus_top",
    url: "data/images/dcss/monster/panlord/demon_head_succubus_top.png"
  },
  {
    key: "monster_demon_head_teeth_top",
    url: "data/images/dcss/monster/panlord/demon_head_teeth_top.png"
  },
  {
    key: "monster_demon_head_tentacles_top",
    url: "data/images/dcss/monster/panlord/demon_head_tentacles_top_old.png"
  },
  {
    key: "monster_demon_head_worm_top",
    url: "data/images/dcss/monster/panlord/demon_head_worm_top.png"
  },
  {
    key: "monster_demon_wings_bat_top",
    url: "data/images/dcss/monster/panlord/demon_wings_bat_top.png"
  },
  {
    key: "monster_demon_wings_bones_bottom",
    url: "data/images/dcss/monster/panlord/demon_wings_bones_bottom.png"
  },
  {
    key: "monster_demon_wings_bones_top",
    url: "data/images/dcss/monster/panlord/demon_wings_bones_top_old.png"
  },
  {
    key: "monster_demon_wings_butterfly_bottom",
    url: "data/images/dcss/monster/panlord/demon_wings_butterfly_bottom.png"
  },
  {
    key: "monster_demon_wings_butterfly_small_top",
    url: "data/images/dcss/monster/panlord/demon_wings_butterfly_small_top.png"
  },
  {
    key: "monster_demon_wings_butterfly_top",
    url: "data/images/dcss/monster/panlord/demon_wings_butterfly_top_old.png"
  },
  {
    key: "monster_demon_wings_demonic_top",
    url: "data/images/dcss/monster/panlord/demon_wings_demonic_top_old.png"
  },
  {
    key: "monster_demon_wings_dragonfly_top",
    url: "data/images/dcss/monster/panlord/demon_wings_dragonfly_top.png"
  },
  {
    key: "monster_demon_wings_hooked_top",
    url: "data/images/dcss/monster/panlord/demon_wings_hooked_top.png"
  },
  {
    key: "monster_demon_wings_knobs_top",
    url: "data/images/dcss/monster/panlord/demon_wings_knobs_top.png"
  },
  {
    key: "monster_demon_wings_large_bottom",
    url: "data/images/dcss/monster/panlord/demon_wings_large_bottom.png"
  },
  {
    key: "monster_demon_wings_large_top",
    url: "data/images/dcss/monster/panlord/demon_wings_large_top_old.png"
  },
  {
    key: "monster_demon_wings_medium_bottom",
    url: "data/images/dcss/monster/panlord/demon_wings_medium_bottom.png"
  },
  {
    key: "monster_demon_wings_medium_top",
    url: "data/images/dcss/monster/panlord/demon_wings_medium_top_old.png"
  },
  {
    key: "monster_demon_wings_red_bottom",
    url: "data/images/dcss/monster/panlord/demon_wings_red_bottom.png"
  },
  {
    key: "monster_demon_wings_red_top",
    url: "data/images/dcss/monster/panlord/demon_wings_red_top_old.png"
  },
  {
    key: "monster_demon_wings_sparrow_top",
    url: "data/images/dcss/monster/panlord/demon_wings_sparrow_top.png"
  },
  {
    key: "monster_demon_wings_torn_top",
    url: "data/images/dcss/monster/panlord/demon_wings_torn_top.png"
  },
  {
    key: "monster_pandemonium_demon",
    url: "data/images/dcss/monster/panlord/pandemonium_demon.png"
  },
  {
    key: "monster_phoenix",
    url: "data/images/dcss/monster/phoenix.png"
  },
  {
    key: "monster_pulsating_lump",
    url: "data/images/dcss/monster/pulsating_lump.png"
  },
  {
    key: "monster_raven",
    url: "data/images/dcss/monster/raven.png"
  },
  {
    key: "monster_rock_troll",
    url: "data/images/dcss/monster/rock_troll.png"
  },
  {
    key: "monster_rock_troll_monk_ghost",
    url: "data/images/dcss/monster/rock_troll_monk_ghost.png"
  },
  {
    key: "monster_salamander_firebrand",
    url: "data/images/dcss/monster/salamander_firebrand.png"
  },
  {
    key: "monster_salamander_mystic",
    url: "data/images/dcss/monster/salamander_mystic.png"
  },
  {
    key: "monster_salamander_stormcaller",
    url: "data/images/dcss/monster/salamander_stormcaller.png"
  },
  {
    key: "monster_satyr",
    url: "data/images/dcss/monster/satyr.png"
  },
  {
    key: "monster_shapeshifter",
    url: "data/images/dcss/monster/shapeshifter.png"
  },
  {
    key: "monster_siren",
    url: "data/images/dcss/monster/siren_old.png"
  },
  {
    key: "monster_siren_water",
    url: "data/images/dcss/monster/siren_water_old.png"
  },
  {
    key: "monster_slave_freed",
    url: "data/images/dcss/monster/slave_freed.png"
  },
  {
    key: "monster_sphinx",
    url: "data/images/dcss/monster/sphinx_old.png"
  },
  {
    key: "monster_spriggan",
    url: "data/images/dcss/monster/spriggan/spriggan.png"
  },
  {
    key: "monster_spriggan_air_mage",
    url: "data/images/dcss/monster/spriggan/spriggan_air_mage.png"
  },
  {
    key: "monster_spriggan_defender",
    url: "data/images/dcss/monster/spriggan/spriggan_defender.png"
  },
  {
    key: "monster_spriggan_druid",
    url: "data/images/dcss/monster/spriggan/spriggan_druid.png"
  },
  {
    key: "monster_spriggan_rider",
    url: "data/images/dcss/monster/spriggan/spriggan_rider.png"
  },
  {
    key: "monster_spriggan_berserker",
    url: "data/images/dcss/monster/spriggan_berserker.png"
  },
  {
    key: "monster_spriggan_defender_shieldless",
    url: "data/images/dcss/monster/spriggan_defender_shieldless.png"
  },
  {
    key: "monster_spriggan_enchanter",
    url: "data/images/dcss/monster/spriggan_enchanter.png"
  },
  {
    key: "monster_air_elementalist_statue",
    url: "data/images/dcss/monster/statues/air_elementalist_statue.png"
  },
  {
    key: "monster_block_of_ice",
    url: "data/images/dcss/monster/statues/block_of_ice.png"
  },
  {
    key: "monster_block_of_ice_2",
    url: "data/images/dcss/monster/statues/block_of_ice_2.png"
  },
  {
    key: "monster_chilling_statue",
    url: "data/images/dcss/monster/statues/chilling_statue.png"
  },
  {
    key: "monster_dark_vine_statue_base",
    url: "data/images/dcss/monster/statues/dark_vine_statue_base_old.png"
  },
  {
    key: "monster_earth_elementalist_statue",
    url: "data/images/dcss/monster/statues/earth_elementalist_statue.png"
  },
  {
    key: "monster_fire_elementalist_statue",
    url: "data/images/dcss/monster/statues/fire_elementalist_statue.png"
  },
  {
    key: "monster_firespitter_statue",
    url: "data/images/dcss/monster/statues/firespitter_statue_old.png"
  },
  {
    key: "monster_guardian-eyeclosed-flame_1",
    url: "data/images/dcss/monster/statues/guardian-eyeclosed-flame_1.png"
  },
  {
    key: "monster_guardian-eyeclosed-flame_2",
    url: "data/images/dcss/monster/statues/guardian-eyeclosed-flame_2.png"
  },
  {
    key: "monster_guardian-eyeclosed-flame_3",
    url: "data/images/dcss/monster/statues/guardian-eyeclosed-flame_3.png"
  },
  {
    key: "monster_guardian-eyeclosed-flame_4",
    url: "data/images/dcss/monster/statues/guardian-eyeclosed-flame_4.png"
  },
  {
    key: "monster_guardian-eyeopen-flame_1",
    url: "data/images/dcss/monster/statues/guardian-eyeopen-flame_1.png"
  },
  {
    key: "monster_guardian-eyeopen-flame_2",
    url: "data/images/dcss/monster/statues/guardian-eyeopen-flame_2.png"
  },
  {
    key: "monster_guardian-eyeopen-flame_3",
    url: "data/images/dcss/monster/statues/guardian-eyeopen-flame_3.png"
  },
  {
    key: "monster_guardian-eyeopen-flame_4",
    url: "data/images/dcss/monster/statues/guardian-eyeopen-flame_4.png"
  },
  {
    key: "monster_ice_statue",
    url: "data/images/dcss/monster/statues/ice_statue.png"
  },
  {
    key: "monster_light_vine_statue_base",
    url: "data/images/dcss/monster/statues/light_vine_statue_base_old.png"
  },
  {
    key: "monster_obelisk",
    url: "data/images/dcss/monster/statues/obelisk.png"
  },
  {
    key: "monster_orange_crystal_statue",
    url: "data/images/dcss/monster/statues/orange_crystal_statue_old.png"
  },
  {
    key: "monster_overlay_axe",
    url: "data/images/dcss/monster/statues/overlay_axe_old.png"
  },
  {
    key: "monster_overlay_bow",
    url: "data/images/dcss/monster/statues/overlay_bow_old.png"
  },
  {
    key: "monster_overlay_crossbow",
    url: "data/images/dcss/monster/statues/overlay_crossbow_old.png"
  },
  {
    key: "monster_overlay_mace",
    url: "data/images/dcss/monster/statues/overlay_mace_old.png"
  },
  {
    key: "monster_overlay_mage",
    url: "data/images/dcss/monster/statues/overlay_mage.png"
  },
  {
    key: "monster_overlay_mage_hat",
    url: "data/images/dcss/monster/statues/overlay_mage_hat_old.png"
  },
  {
    key: "monster_overlay_scythe",
    url: "data/images/dcss/monster/statues/overlay_scythe_old.png"
  },
  {
    key: "monster_overlay_sword",
    url: "data/images/dcss/monster/statues/overlay_sword_old.png"
  },
  {
    key: "monster_overlay_whip",
    url: "data/images/dcss/monster/statues/overlay_whip_old.png"
  },
  {
    key: "monster_pillar_of_salt",
    url: "data/images/dcss/monster/statues/pillar_of_salt.png"
  },
  {
    key: "monster_silver_statue",
    url: "data/images/dcss/monster/statues/silver_statue.png"
  },
  {
    key: "monster_snail_statue",
    url: "data/images/dcss/monster/statues/snail_statue.png"
  },
  {
    key: "monster_spooky_statue",
    url: "data/images/dcss/monster/statues/spooky_statue.png"
  },
  {
    key: "monster_statue_base",
    url: "data/images/dcss/monster/statues/statue_base_old.png"
  },
  {
    key: "monster_training_dummy",
    url: "data/images/dcss/monster/statues/training_dummy_old.png"
  },
  {
    key: "monster_water_elementalist_statue",
    url: "data/images/dcss/monster/statues/water_elementalist_statue.png"
  },
  {
    key: "monster_wucad_mu_statue",
    url: "data/images/dcss/monster/statues/wucad_mu_statue_old.png"
  },
  {
    key: "monster_zot_statue",
    url: "data/images/dcss/monster/statues/zot_statue.png"
  },
  {
    key: "monster_stone_giant",
    url: "data/images/dcss/monster/stone_giant_old.png"
  },
  {
    key: "monster_swamp_drake",
    url: "data/images/dcss/monster/swamp_drake.png"
  },
  {
    key: "monster_tengu",
    url: "data/images/dcss/monster/tengu.png"
  },
  {
    key: "monster_tengu_conjurer",
    url: "data/images/dcss/monster/tengu_conjurer.png"
  },
  {
    key: "monster_tengu_reaver",
    url: "data/images/dcss/monster/tengu_reaver.png"
  },
  {
    key: "monster_tengu_warrior",
    url: "data/images/dcss/monster/tengu_warrior.png"
  },
  {
    key: "monster_titan",
    url: "data/images/dcss/monster/titan_old.png"
  },
  {
    key: "monster_troll",
    url: "data/images/dcss/monster/troll.png"
  },
  {
    key: "monster_two_headed_ogre",
    url: "data/images/dcss/monster/two_headed_ogre_old.png"
  },
  {
    key: "monster_agnes",
    url: "data/images/dcss/monster/unique/agnes_old.png"
  },
  {
    key: "monster_aizul",
    url: "data/images/dcss/monster/unique/aizul_old.png"
  },
  {
    key: "monster_antaeus",
    url: "data/images/dcss/monster/unique/antaeus.png"
  },
  {
    key: "monster_asmodeus",
    url: "data/images/dcss/monster/unique/asmodeus.png"
  },
  {
    key: "monster_asmodeus_bottom",
    url: "data/images/dcss/monster/unique/asmodeus_bottom.png"
  },
  {
    key: "monster_asmodeus_small",
    url: "data/images/dcss/monster/unique/asmodeus_small.png"
  },
  {
    key: "monster_asmodeus_top",
    url: "data/images/dcss/monster/unique/asmodeus_top.png"
  },
  {
    key: "monster_azrael",
    url: "data/images/dcss/monster/unique/azrael.png"
  },
  {
    key: "monster_blork_the_orc",
    url: "data/images/dcss/monster/unique/blork_the_orc_old.png"
  },
  {
    key: "monster_boris",
    url: "data/images/dcss/monster/unique/boris_old.png"
  },
  {
    key: "monster_cerebov",
    url: "data/images/dcss/monster/unique/cerebov.png"
  },
  {
    key: "monster_cerebov_bottom",
    url: "data/images/dcss/monster/unique/cerebov_bottom.png"
  },
  {
    key: "monster_cerebov_top",
    url: "data/images/dcss/monster/unique/cerebov_top.png"
  },
  {
    key: "monster_chuck",
    url: "data/images/dcss/monster/unique/chuck.png"
  },
  {
    key: "monster_crazy_yiuf",
    url: "data/images/dcss/monster/unique/crazy_yiuf.png"
  },
  {
    key: "monster_dispater",
    url: "data/images/dcss/monster/unique/dispater.png"
  },
  {
    key: "monster_dispater_bottom",
    url: "data/images/dcss/monster/unique/dispater_bottom.png"
  },
  {
    key: "monster_dispater_small",
    url: "data/images/dcss/monster/unique/dispater_small.png"
  },
  {
    key: "monster_dispater_top",
    url: "data/images/dcss/monster/unique/dispater_top.png"
  },
  {
    key: "monster_dissolution",
    url: "data/images/dcss/monster/unique/dissolution_old.png"
  },
  {
    key: "monster_donald",
    url: "data/images/dcss/monster/unique/donald_old.png"
  },
  {
    key: "monster_duane",
    url: "data/images/dcss/monster/unique/duane.png"
  },
  {
    key: "monster_edmund",
    url: "data/images/dcss/monster/unique/edmund_old.png"
  },
  {
    key: "monster_enchantress",
    url: "data/images/dcss/monster/unique/enchantress.png"
  },
  {
    key: "monster_ereshkigal",
    url: "data/images/dcss/monster/unique/ereshkigal.png"
  },
  {
    key: "monster_ereshkigal_bottom",
    url: "data/images/dcss/monster/unique/ereshkigal_bottom.png"
  },
  {
    key: "monster_ereshkigal_small",
    url: "data/images/dcss/monster/unique/ereshkigal_small.png"
  },
  {
    key: "monster_ereshkigal_top",
    url: "data/images/dcss/monster/unique/ereshkigal_top.png"
  },
  {
    key: "monster_erica",
    url: "data/images/dcss/monster/unique/erica_old.png"
  },
  {
    key: "monster_erolcha",
    url: "data/images/dcss/monster/unique/erolcha_old.png"
  },
  {
    key: "monster_eustachio",
    url: "data/images/dcss/monster/unique/eustachio_old.png"
  },
  {
    key: "monster_fannar",
    url: "data/images/dcss/monster/unique/fannar.png"
  },
  {
    key: "monster_frances",
    url: "data/images/dcss/monster/unique/frances.png"
  },
  {
    key: "monster_frances_male",
    url: "data/images/dcss/monster/unique/frances_male.png"
  },
  {
    key: "monster_francis",
    url: "data/images/dcss/monster/unique/francis.png"
  },
  {
    key: "monster_frederick",
    url: "data/images/dcss/monster/unique/frederick_old.png"
  },
  {
    key: "monster_gastronok",
    url: "data/images/dcss/monster/unique/gastronok_old.png"
  },
  {
    key: "monster_geryon",
    url: "data/images/dcss/monster/unique/geryon_old.png"
  },
  {
    key: "monster_giaggostuono",
    url: "data/images/dcss/monster/unique/giaggostuono.png"
  },
  {
    key: "monster_gloorx_vloq",
    url: "data/images/dcss/monster/unique/gloorx_vloq.png"
  },
  {
    key: "monster_gloorx_vloq_bottom",
    url: "data/images/dcss/monster/unique/gloorx_vloq_bottom.png"
  },
  {
    key: "monster_gloorx_vloq_top",
    url: "data/images/dcss/monster/unique/gloorx_vloq_top.png"
  },
  {
    key: "monster_grinder_cleaver",
    url: "data/images/dcss/monster/unique/grinder_cleaver.png"
  },
  {
    key: "monster_grinder",
    url: "data/images/dcss/monster/unique/grinder_old.png"
  },
  {
    key: "monster_grum",
    url: "data/images/dcss/monster/unique/grum.png"
  },
  {
    key: "monster_harold",
    url: "data/images/dcss/monster/unique/harold.png"
  },
  {
    key: "monster_ignacio",
    url: "data/images/dcss/monster/unique/ignacio.png"
  },
  {
    key: "monster_ijyb",
    url: "data/images/dcss/monster/unique/ijyb_old.png"
  },
  {
    key: "monster_ilsuiw",
    url: "data/images/dcss/monster/unique/ilsuiw_old.png"
  },
  {
    key: "monster_ilsuiw_water",
    url: "data/images/dcss/monster/unique/ilsuiw_water_old.png"
  },
  {
    key: "monster_iron_giant",
    url: "data/images/dcss/monster/unique/iron_giant.png"
  },
  {
    key: "monster_jessica",
    url: "data/images/dcss/monster/unique/jessica_old.png"
  },
  {
    key: "monster_jorgrun",
    url: "data/images/dcss/monster/unique/jorgrun.png"
  },
  {
    key: "monster_jormungandr",
    url: "data/images/dcss/monster/unique/jormungandr.png"
  },
  {
    key: "monster_jory",
    url: "data/images/dcss/monster/unique/jory.png"
  },
  {
    key: "monster_joseph",
    url: "data/images/dcss/monster/unique/joseph_old.png"
  },
  {
    key: "monster_josephine",
    url: "data/images/dcss/monster/unique/josephine_old.png"
  },
  {
    key: "monster_jozef",
    url: "data/images/dcss/monster/unique/jozef.png"
  },
  {
    key: "monster_kirke",
    url: "data/images/dcss/monster/unique/kirke_old.png"
  },
  {
    key: "monster_lamia",
    url: "data/images/dcss/monster/unique/lamia.png"
  },
  {
    key: "monster_lernaean_hydra",
    url: "data/images/dcss/monster/unique/lernaean_hydra.png"
  },
  {
    key: "monster_lernaean_hydra_10_top",
    url: "data/images/dcss/monster/unique/lernaean_hydra_10_top.png"
  },
  {
    key: "monster_lernaean_hydra_1_bottom",
    url: "data/images/dcss/monster/unique/lernaean_hydra_1_bottom.png"
  },
  {
    key: "monster_lernaean_hydra_1_top",
    url: "data/images/dcss/monster/unique/lernaean_hydra_1_top.png"
  },
  {
    key: "monster_lernaean_hydra_2_top",
    url: "data/images/dcss/monster/unique/lernaean_hydra_2_top.png"
  },
  {
    key: "monster_lernaean_hydra_3_top",
    url: "data/images/dcss/monster/unique/lernaean_hydra_3_top.png"
  },
  {
    key: "monster_lernaean_hydra_4_top",
    url: "data/images/dcss/monster/unique/lernaean_hydra_4_top.png"
  },
  {
    key: "monster_lernaean_hydra_5_bottom",
    url: "data/images/dcss/monster/unique/lernaean_hydra_5_bottom.png"
  },
  {
    key: "monster_lernaean_hydra_5_top",
    url: "data/images/dcss/monster/unique/lernaean_hydra_5_top.png"
  },
  {
    key: "monster_lernaean_hydra_6_top",
    url: "data/images/dcss/monster/unique/lernaean_hydra_6_top.png"
  },
  {
    key: "monster_lernaean_hydra_7_bottom",
    url: "data/images/dcss/monster/unique/lernaean_hydra_7_bottom.png"
  },
  {
    key: "monster_lernaean_hydra_7_top",
    url: "data/images/dcss/monster/unique/lernaean_hydra_7_top.png"
  },
  {
    key: "monster_lernaean_hydra_8_bottom",
    url: "data/images/dcss/monster/unique/lernaean_hydra_8_bottom.png"
  },
  {
    key: "monster_lernaean_hydra_9_bottom",
    url: "data/images/dcss/monster/unique/lernaean_hydra_9_bottom.png"
  },
  {
    key: "monster_lernaean_hydra_9_top",
    url: "data/images/dcss/monster/unique/lernaean_hydra_9_top.png"
  },
  {
    key: "monster_leshy",
    url: "data/images/dcss/monster/unique/leshy.png"
  },
  {
    key: "monster_lom_lobon",
    url: "data/images/dcss/monster/unique/lom_lobon.png"
  },
  {
    key: "monster_lom_lobon_bottom",
    url: "data/images/dcss/monster/unique/lom_lobon_bottom.png"
  },
  {
    key: "monster_lom_lobon_top",
    url: "data/images/dcss/monster/unique/lom_lobon_top.png"
  },
  {
    key: "monster_louise",
    url: "data/images/dcss/monster/unique/louise.png"
  },
  {
    key: "monster_mara",
    url: "data/images/dcss/monster/unique/mara.png"
  },
  {
    key: "monster_margery",
    url: "data/images/dcss/monster/unique/margery_old.png"
  },
  {
    key: "monster_maud",
    url: "data/images/dcss/monster/unique/maud_old.png"
  },
  {
    key: "monster_maurice",
    url: "data/images/dcss/monster/unique/maurice_old.png"
  },
  {
    key: "monster_menkaure",
    url: "data/images/dcss/monster/unique/menkaure.png"
  },
  {
    key: "monster_mennas",
    url: "data/images/dcss/monster/unique/mennas.png"
  },
  {
    key: "monster_michael",
    url: "data/images/dcss/monster/unique/michael.png"
  },
  {
    key: "monster_mnoleg",
    url: "data/images/dcss/monster/unique/mnoleg.png"
  },
  {
    key: "monster_mnoleg_bottom",
    url: "data/images/dcss/monster/unique/mnoleg_bottom.png"
  },
  {
    key: "monster_mnoleg_top",
    url: "data/images/dcss/monster/unique/mnoleg_top.png"
  },
  {
    key: "monster_murray",
    url: "data/images/dcss/monster/unique/murray.png"
  },
  {
    key: "monster_natasha",
    url: "data/images/dcss/monster/unique/natasha.png"
  },
  {
    key: "monster_nellie",
    url: "data/images/dcss/monster/unique/nellie_old.png"
  },
  {
    key: "monster_nergalle",
    url: "data/images/dcss/monster/unique/nergalle_old.png"
  },
  {
    key: "monster_nessos",
    url: "data/images/dcss/monster/unique/nessos_old.png"
  },
  {
    key: "monster_norbert",
    url: "data/images/dcss/monster/unique/norbert.png"
  },
  {
    key: "monster_norris",
    url: "data/images/dcss/monster/unique/norris.png"
  },
  {
    key: "monster_norris_with_board",
    url: "data/images/dcss/monster/unique/norris_with_board.png"
  },
  {
    key: "monster_polyphemus",
    url: "data/images/dcss/monster/unique/polyphemus_old.png"
  },
  {
    key: "monster_prince_ribbit",
    url: "data/images/dcss/monster/unique/prince_ribbit.png"
  },
  {
    key: "monster_psyche",
    url: "data/images/dcss/monster/unique/psyche_old.png"
  },
  {
    key: "monster_purgy",
    url: "data/images/dcss/monster/unique/purgy_old.png"
  },
  {
    key: "monster_robin",
    url: "data/images/dcss/monster/unique/robin.png"
  },
  {
    key: "monster_roxanne",
    url: "data/images/dcss/monster/unique/roxanne_old.png"
  },
  {
    key: "monster_royal_jelly",
    url: "data/images/dcss/monster/unique/royal_jelly.png"
  },
  {
    key: "monster_royal_jelly_bottom",
    url: "data/images/dcss/monster/unique/royal_jelly_bottom.png"
  },
  {
    key: "monster_royal_jelly_top",
    url: "data/images/dcss/monster/unique/royal_jelly_top.png"
  },
  {
    key: "monster_rupert",
    url: "data/images/dcss/monster/unique/rupert_old.png"
  },
  {
    key: "monster_saint_roka",
    url: "data/images/dcss/monster/unique/saint_roka_old.png"
  },
  {
    key: "monster_serpent_of_hell-coc_bottom",
    url: "data/images/dcss/monster/unique/serpent_of_hell-coc_bottom.png"
  },
  {
    key: "monster_serpent_of_hell-coc_top",
    url: "data/images/dcss/monster/unique/serpent_of_hell-coc_top.png"
  },
  {
    key: "monster_serpent_of_hell-dis_bottom",
    url: "data/images/dcss/monster/unique/serpent_of_hell-dis_bottom.png"
  },
  {
    key: "monster_serpent_of_hell-dis_top",
    url: "data/images/dcss/monster/unique/serpent_of_hell-dis_top.png"
  },
  {
    key: "monster_serpent_of_hell-geh_bottom",
    url: "data/images/dcss/monster/unique/serpent_of_hell-geh_bottom.png"
  },
  {
    key: "monster_serpent_of_hell-geh_top",
    url: "data/images/dcss/monster/unique/serpent_of_hell-geh_top.png"
  },
  {
    key: "monster_serpent_of_hell-tar_bottom",
    url: "data/images/dcss/monster/unique/serpent_of_hell-tar_bottom.png"
  },
  {
    key: "monster_serpent_of_hell-tar_top",
    url: "data/images/dcss/monster/unique/serpent_of_hell-tar_top.png"
  },
  {
    key: "monster_serpent_of_hell",
    url: "data/images/dcss/monster/unique/serpent_of_hell.png"
  },
  {
    key: "monster_sigmund",
    url: "data/images/dcss/monster/unique/sigmund_old.png"
  },
  {
    key: "monster_snorg",
    url: "data/images/dcss/monster/unique/snorg_old.png"
  },
  {
    key: "monster_sojobo",
    url: "data/images/dcss/monster/unique/sojobo.png"
  },
  {
    key: "monster_sonja",
    url: "data/images/dcss/monster/unique/sonja_old.png"
  },
  {
    key: "monster_terence",
    url: "data/images/dcss/monster/unique/terence_old.png"
  },
  {
    key: "monster_tiamat",
    url: "data/images/dcss/monster/unique/tiamat.png"
  },
  {
    key: "monster_tiamat_black",
    url: "data/images/dcss/monster/unique/tiamat_black.png"
  },
  {
    key: "monster_tiamat_green",
    url: "data/images/dcss/monster/unique/tiamat_green.png"
  },
  {
    key: "monster_tiamat_grey",
    url: "data/images/dcss/monster/unique/tiamat_grey.png"
  },
  {
    key: "monster_tiamat_mottled",
    url: "data/images/dcss/monster/unique/tiamat_mottled.png"
  },
  {
    key: "monster_tiamat_pale",
    url: "data/images/dcss/monster/unique/tiamat_pale.png"
  },
  {
    key: "monster_tiamat_red",
    url: "data/images/dcss/monster/unique/tiamat_red.png"
  },
  {
    key: "monster_tiamat_white",
    url: "data/images/dcss/monster/unique/tiamat_white.png"
  },
  {
    key: "monster_tiamat_yellow",
    url: "data/images/dcss/monster/unique/tiamat_yellow.png"
  },
  {
    key: "monster_urug",
    url: "data/images/dcss/monster/unique/urug_old.png"
  },
  {
    key: "monster_vashnia",
    url: "data/images/dcss/monster/unique/vashnia.png"
  },
  {
    key: "monster_wiglaf",
    url: "data/images/dcss/monster/unique/wiglaf_old.png"
  },
  {
    key: "monster_xtahua",
    url: "data/images/dcss/monster/unique/xtahua_old.png"
  },
  {
    key: "monster_water_nymph",
    url: "data/images/dcss/monster/water_nymph.png"
  },
  {
    key: "monster_wizard",
    url: "data/images/dcss/monster/wizard.png"
  },
  {
    key: "monster_yaktaur-melee",
    url: "data/images/dcss/monster/yaktaur-melee_old.png"
  },
  {
    key: "monster_yaktaur_captain-melee",
    url: "data/images/dcss/monster/yaktaur_captain-melee_old.png"
  },
  {
    key: "monster_yaktaur_captain",
    url: "data/images/dcss/monster/yaktaur_captain_old.png"
  },
  {
    key: "monster_yaktaur",
    url: "data/images/dcss/monster/yaktaur_old.png"
  },
  {
    key: "plant_bush_2",
    url: "data/images/dcss/monster/fungi_plants/bush_2.png"
  },
  {
    key: "plant_bush_3",
    url: "data/images/dcss/monster/fungi_plants/bush_3.png"
  },
  {
    key: "plant_bush_4",
    url: "data/images/dcss/monster/fungi_plants/bush_4.png"
  },
  {
    key: "prop_chest",
    url: "data/images/dcss/dungeon/chest.png"
  },
  {
    key: "prop_chest_2_closed",
    url: "data/images/dcss/dungeon/chest_2_closed.png"
  },
  {
    key: "prop_large_box",
    url: "data/images/dcss/dungeon/large_box.png"
  },
  {
    key: "prop_misc_box",
    url: "data/images/dcss/item/misc/misc_box.png"
  }
];
