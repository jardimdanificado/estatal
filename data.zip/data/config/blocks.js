export default {
  GOLD: {
    id: 4,
    name: "Ouro",
    solid: true,
    maxHP: 150,
    breakDamage: 20,
    bulletSpeed: 0.32,
    bulletLifetime: 55,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "gold"
    },
    onUse: function(world, block, creature) {
    console.log('Bloco de ouro ativado!');
    block.material.forEach(mat => {
        mat.emissive = new THREE.Color(0xFFD700);
        mat.emissiveIntensity = 0.5;
    });
    setTimeout(() => {
        block.material.forEach(mat => {
            mat.emissiveIntensity = 0;
        });
    }, 1000);
}
  },
  WALL_WALL_ABYSS_0: {
    id: 9,
    name: "Parede Abyss 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_0"
    }
  },
  WALL_WALL_ABYSS_1: {
    id: 10,
    name: "Parede Abyss 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_1"
    }
  },
  WALL_WALL_ABYSS_2: {
    id: 11,
    name: "Parede Abyss 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_2"
    }
  },
  WALL_WALL_ABYSS_3: {
    id: 12,
    name: "Parede Abyss 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_3"
    }
  },
  WALL_WALL_ABYSS_4: {
    id: 13,
    name: "Parede Abyss 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_4"
    }
  },
  WALL_WALL_ABYSS_5: {
    id: 14,
    name: "Parede Abyss 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_5"
    }
  },
  WALL_WALL_ABYSS_6: {
    id: 15,
    name: "Parede Abyss 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_6"
    }
  },
  WALL_WALL_ABYSS_7: {
    id: 16,
    name: "Parede Abyss 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_7"
    }
  },
  WALL_WALL_ABYSS_BLUE_0: {
    id: 17,
    name: "Parede Abyss Blue 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_blue_0"
    }
  },
  WALL_WALL_ABYSS_BLUE_1: {
    id: 18,
    name: "Parede Abyss Blue 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_blue_1"
    }
  },
  WALL_WALL_ABYSS_BLUE_2: {
    id: 19,
    name: "Parede Abyss Blue 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_blue_2"
    }
  },
  WALL_WALL_ABYSS_BLUE_3: {
    id: 20,
    name: "Parede Abyss Blue 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_blue_3"
    }
  },
  WALL_WALL_ABYSS_BLUE_4: {
    id: 21,
    name: "Parede Abyss Blue 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_blue_4"
    }
  },
  WALL_WALL_ABYSS_BLUE_5: {
    id: 22,
    name: "Parede Abyss Blue 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_blue_5"
    }
  },
  WALL_WALL_ABYSS_BLUE_6: {
    id: 23,
    name: "Parede Abyss Blue 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_blue_6"
    }
  },
  WALL_WALL_ABYSS_BLUE_7: {
    id: 24,
    name: "Parede Abyss Blue 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_blue_7"
    }
  },
  WALL_WALL_ABYSS_BROWN_0: {
    id: 25,
    name: "Parede Abyss Brown 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_brown_0"
    }
  },
  WALL_WALL_ABYSS_BROWN_1: {
    id: 26,
    name: "Parede Abyss Brown 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_brown_1"
    }
  },
  WALL_WALL_ABYSS_BROWN_2: {
    id: 27,
    name: "Parede Abyss Brown 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_brown_2"
    }
  },
  WALL_WALL_ABYSS_BROWN_3: {
    id: 28,
    name: "Parede Abyss Brown 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_brown_3"
    }
  },
  WALL_WALL_ABYSS_BROWN_4: {
    id: 29,
    name: "Parede Abyss Brown 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_brown_4"
    }
  },
  WALL_WALL_ABYSS_BROWN_5: {
    id: 30,
    name: "Parede Abyss Brown 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_brown_5"
    }
  },
  WALL_WALL_ABYSS_BROWN_6: {
    id: 31,
    name: "Parede Abyss Brown 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_brown_6"
    }
  },
  WALL_WALL_ABYSS_BROWN_7: {
    id: 32,
    name: "Parede Abyss Brown 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_brown_7"
    }
  },
  WALL_WALL_ABYSS_CYAN_0: {
    id: 33,
    name: "Parede Abyss Cyan 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_cyan_0"
    }
  },
  WALL_WALL_ABYSS_CYAN_1: {
    id: 34,
    name: "Parede Abyss Cyan 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_cyan_1"
    }
  },
  WALL_WALL_ABYSS_CYAN_2: {
    id: 35,
    name: "Parede Abyss Cyan 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_cyan_2"
    }
  },
  WALL_WALL_ABYSS_CYAN_3: {
    id: 36,
    name: "Parede Abyss Cyan 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_cyan_3"
    }
  },
  WALL_WALL_ABYSS_CYAN_4: {
    id: 37,
    name: "Parede Abyss Cyan 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_cyan_4"
    }
  },
  WALL_WALL_ABYSS_CYAN_5: {
    id: 38,
    name: "Parede Abyss Cyan 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_cyan_5"
    }
  },
  WALL_WALL_ABYSS_CYAN_6: {
    id: 39,
    name: "Parede Abyss Cyan 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_cyan_6"
    }
  },
  WALL_WALL_ABYSS_CYAN_7: {
    id: 40,
    name: "Parede Abyss Cyan 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_cyan_7"
    }
  },
  WALL_WALL_ABYSS_DARKGRAY_0: {
    id: 41,
    name: "Parede Abyss Darkgray 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_darkgray_0"
    }
  },
  WALL_WALL_ABYSS_DARKGRAY_1: {
    id: 42,
    name: "Parede Abyss Darkgray 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_darkgray_1"
    }
  },
  WALL_WALL_ABYSS_DARKGRAY_2: {
    id: 43,
    name: "Parede Abyss Darkgray 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_darkgray_2"
    }
  },
  WALL_WALL_ABYSS_DARKGRAY_3: {
    id: 44,
    name: "Parede Abyss Darkgray 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_darkgray_3"
    }
  },
  WALL_WALL_ABYSS_DARKGRAY_4: {
    id: 45,
    name: "Parede Abyss Darkgray 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_darkgray_4"
    }
  },
  WALL_WALL_ABYSS_DARKGRAY_5: {
    id: 46,
    name: "Parede Abyss Darkgray 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_darkgray_5"
    }
  },
  WALL_WALL_ABYSS_DARKGRAY_6: {
    id: 47,
    name: "Parede Abyss Darkgray 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_darkgray_6"
    }
  },
  WALL_WALL_ABYSS_DARKGRAY_7: {
    id: 48,
    name: "Parede Abyss Darkgray 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_darkgray_7"
    }
  },
  WALL_WALL_ABYSS_GREEN_0: {
    id: 49,
    name: "Parede Abyss Green 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_green_0"
    }
  },
  WALL_WALL_ABYSS_GREEN_1: {
    id: 50,
    name: "Parede Abyss Green 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_green_1"
    }
  },
  WALL_WALL_ABYSS_GREEN_2: {
    id: 51,
    name: "Parede Abyss Green 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_green_2"
    }
  },
  WALL_WALL_ABYSS_GREEN_3: {
    id: 52,
    name: "Parede Abyss Green 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_green_3"
    }
  },
  WALL_WALL_ABYSS_GREEN_4: {
    id: 53,
    name: "Parede Abyss Green 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_green_4"
    }
  },
  WALL_WALL_ABYSS_GREEN_5: {
    id: 54,
    name: "Parede Abyss Green 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_green_5"
    }
  },
  WALL_WALL_ABYSS_GREEN_6: {
    id: 55,
    name: "Parede Abyss Green 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_green_6"
    }
  },
  WALL_WALL_ABYSS_GREEN_7: {
    id: 56,
    name: "Parede Abyss Green 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_green_7"
    }
  },
  WALL_WALL_ABYSS_LIGHTBLUE_0: {
    id: 57,
    name: "Parede Abyss Lightblue 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightblue_0"
    }
  },
  WALL_WALL_ABYSS_LIGHTBLUE_1: {
    id: 58,
    name: "Parede Abyss Lightblue 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightblue_1"
    }
  },
  WALL_WALL_ABYSS_LIGHTBLUE_2: {
    id: 59,
    name: "Parede Abyss Lightblue 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightblue_2"
    }
  },
  WALL_WALL_ABYSS_LIGHTBLUE_3: {
    id: 60,
    name: "Parede Abyss Lightblue 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightblue_3"
    }
  },
  WALL_WALL_ABYSS_LIGHTBLUE_4: {
    id: 61,
    name: "Parede Abyss Lightblue 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightblue_4"
    }
  },
  WALL_WALL_ABYSS_LIGHTBLUE_5: {
    id: 62,
    name: "Parede Abyss Lightblue 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightblue_5"
    }
  },
  WALL_WALL_ABYSS_LIGHTBLUE_6: {
    id: 63,
    name: "Parede Abyss Lightblue 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightblue_6"
    }
  },
  WALL_WALL_ABYSS_LIGHTBLUE_7: {
    id: 64,
    name: "Parede Abyss Lightblue 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightblue_7"
    }
  },
  WALL_WALL_ABYSS_LIGHTCYAN_0: {
    id: 65,
    name: "Parede Abyss Lightcyan 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightcyan_0"
    }
  },
  WALL_WALL_ABYSS_LIGHTCYAN_1: {
    id: 66,
    name: "Parede Abyss Lightcyan 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightcyan_1"
    }
  },
  WALL_WALL_ABYSS_LIGHTCYAN_2: {
    id: 67,
    name: "Parede Abyss Lightcyan 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightcyan_2"
    }
  },
  WALL_WALL_ABYSS_LIGHTCYAN_3: {
    id: 68,
    name: "Parede Abyss Lightcyan 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightcyan_3"
    }
  },
  WALL_WALL_ABYSS_LIGHTCYAN_4: {
    id: 69,
    name: "Parede Abyss Lightcyan 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightcyan_4"
    }
  },
  WALL_WALL_ABYSS_LIGHTCYAN_5: {
    id: 70,
    name: "Parede Abyss Lightcyan 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightcyan_5"
    }
  },
  WALL_WALL_ABYSS_LIGHTCYAN_6: {
    id: 71,
    name: "Parede Abyss Lightcyan 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightcyan_6"
    }
  },
  WALL_WALL_ABYSS_LIGHTCYAN_7: {
    id: 72,
    name: "Parede Abyss Lightcyan 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightcyan_7"
    }
  },
  WALL_WALL_ABYSS_LIGHTGRAY_0: {
    id: 73,
    name: "Parede Abyss Lightgray 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgray_0"
    }
  },
  WALL_WALL_ABYSS_LIGHTGRAY_1: {
    id: 74,
    name: "Parede Abyss Lightgray 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgray_1"
    }
  },
  WALL_WALL_ABYSS_LIGHTGRAY_2: {
    id: 75,
    name: "Parede Abyss Lightgray 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgray_2"
    }
  },
  WALL_WALL_ABYSS_LIGHTGRAY_3: {
    id: 76,
    name: "Parede Abyss Lightgray 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgray_3"
    }
  },
  WALL_WALL_ABYSS_LIGHTGRAY_4: {
    id: 77,
    name: "Parede Abyss Lightgray 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgray_4"
    }
  },
  WALL_WALL_ABYSS_LIGHTGRAY_5: {
    id: 78,
    name: "Parede Abyss Lightgray 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgray_5"
    }
  },
  WALL_WALL_ABYSS_LIGHTGRAY_6: {
    id: 79,
    name: "Parede Abyss Lightgray 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgray_6"
    }
  },
  WALL_WALL_ABYSS_LIGHTGRAY_7: {
    id: 80,
    name: "Parede Abyss Lightgray 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgray_7"
    }
  },
  WALL_WALL_ABYSS_LIGHTGREEN_0: {
    id: 81,
    name: "Parede Abyss Lightgreen 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgreen_0"
    }
  },
  WALL_WALL_ABYSS_LIGHTGREEN_1: {
    id: 82,
    name: "Parede Abyss Lightgreen 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgreen_1"
    }
  },
  WALL_WALL_ABYSS_LIGHTGREEN_2: {
    id: 83,
    name: "Parede Abyss Lightgreen 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgreen_2"
    }
  },
  WALL_WALL_ABYSS_LIGHTGREEN_3: {
    id: 84,
    name: "Parede Abyss Lightgreen 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgreen_3"
    }
  },
  WALL_WALL_ABYSS_LIGHTGREEN_4: {
    id: 85,
    name: "Parede Abyss Lightgreen 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgreen_4"
    }
  },
  WALL_WALL_ABYSS_LIGHTGREEN_5: {
    id: 86,
    name: "Parede Abyss Lightgreen 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgreen_5"
    }
  },
  WALL_WALL_ABYSS_LIGHTGREEN_6: {
    id: 87,
    name: "Parede Abyss Lightgreen 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgreen_6"
    }
  },
  WALL_WALL_ABYSS_LIGHTGREEN_7: {
    id: 88,
    name: "Parede Abyss Lightgreen 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightgreen_7"
    }
  },
  WALL_WALL_ABYSS_LIGHTMAGENTA_0: {
    id: 89,
    name: "Parede Abyss Lightmagenta 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightmagenta_0"
    }
  },
  WALL_WALL_ABYSS_LIGHTMAGENTA_1: {
    id: 90,
    name: "Parede Abyss Lightmagenta 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightmagenta_1"
    }
  },
  WALL_WALL_ABYSS_LIGHTMAGENTA_2: {
    id: 91,
    name: "Parede Abyss Lightmagenta 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightmagenta_2"
    }
  },
  WALL_WALL_ABYSS_LIGHTMAGENTA_3: {
    id: 92,
    name: "Parede Abyss Lightmagenta 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightmagenta_3"
    }
  },
  WALL_WALL_ABYSS_LIGHTMAGENTA_4: {
    id: 93,
    name: "Parede Abyss Lightmagenta 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightmagenta_4"
    }
  },
  WALL_WALL_ABYSS_LIGHTMAGENTA_5: {
    id: 94,
    name: "Parede Abyss Lightmagenta 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightmagenta_5"
    }
  },
  WALL_WALL_ABYSS_LIGHTMAGENTA_6: {
    id: 95,
    name: "Parede Abyss Lightmagenta 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightmagenta_6"
    }
  },
  WALL_WALL_ABYSS_LIGHTMAGENTA_7: {
    id: 96,
    name: "Parede Abyss Lightmagenta 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightmagenta_7"
    }
  },
  WALL_WALL_ABYSS_LIGHTRED_0: {
    id: 97,
    name: "Parede Abyss Lightred 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightred_0"
    }
  },
  WALL_WALL_ABYSS_LIGHTRED_1: {
    id: 98,
    name: "Parede Abyss Lightred 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightred_1"
    }
  },
  WALL_WALL_ABYSS_LIGHTRED_2: {
    id: 99,
    name: "Parede Abyss Lightred 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightred_2"
    }
  },
  WALL_WALL_ABYSS_LIGHTRED_3: {
    id: 100,
    name: "Parede Abyss Lightred 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightred_3"
    }
  },
  WALL_WALL_ABYSS_LIGHTRED_4: {
    id: 101,
    name: "Parede Abyss Lightred 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightred_4"
    }
  },
  WALL_WALL_ABYSS_LIGHTRED_5: {
    id: 102,
    name: "Parede Abyss Lightred 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightred_5"
    }
  },
  WALL_WALL_ABYSS_LIGHTRED_6: {
    id: 103,
    name: "Parede Abyss Lightred 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightred_6"
    }
  },
  WALL_WALL_ABYSS_LIGHTRED_7: {
    id: 104,
    name: "Parede Abyss Lightred 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_lightred_7"
    }
  },
  WALL_WALL_ABYSS_MAGENTA_0: {
    id: 105,
    name: "Parede Abyss Magenta 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_magenta_0"
    }
  },
  WALL_WALL_ABYSS_MAGENTA_1: {
    id: 106,
    name: "Parede Abyss Magenta 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_magenta_1"
    }
  },
  WALL_WALL_ABYSS_MAGENTA_2: {
    id: 107,
    name: "Parede Abyss Magenta 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_magenta_2"
    }
  },
  WALL_WALL_ABYSS_MAGENTA_3: {
    id: 108,
    name: "Parede Abyss Magenta 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_magenta_3"
    }
  },
  WALL_WALL_ABYSS_MAGENTA_4: {
    id: 109,
    name: "Parede Abyss Magenta 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_magenta_4"
    }
  },
  WALL_WALL_ABYSS_MAGENTA_5: {
    id: 110,
    name: "Parede Abyss Magenta 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_magenta_5"
    }
  },
  WALL_WALL_ABYSS_MAGENTA_6: {
    id: 111,
    name: "Parede Abyss Magenta 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_magenta_6"
    }
  },
  WALL_WALL_ABYSS_MAGENTA_7: {
    id: 112,
    name: "Parede Abyss Magenta 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_magenta_7"
    }
  },
  WALL_WALL_ABYSS_WHITE_0: {
    id: 113,
    name: "Parede Abyss White 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_white_0"
    }
  },
  WALL_WALL_ABYSS_WHITE_1: {
    id: 114,
    name: "Parede Abyss White 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_white_1"
    }
  },
  WALL_WALL_ABYSS_WHITE_2: {
    id: 115,
    name: "Parede Abyss White 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_white_2"
    }
  },
  WALL_WALL_ABYSS_WHITE_3: {
    id: 116,
    name: "Parede Abyss White 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_white_3"
    }
  },
  WALL_WALL_ABYSS_WHITE_4: {
    id: 117,
    name: "Parede Abyss White 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_white_4"
    }
  },
  WALL_WALL_ABYSS_WHITE_5: {
    id: 118,
    name: "Parede Abyss White 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_white_5"
    }
  },
  WALL_WALL_ABYSS_WHITE_6: {
    id: 119,
    name: "Parede Abyss White 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_white_6"
    }
  },
  WALL_WALL_ABYSS_WHITE_7: {
    id: 120,
    name: "Parede Abyss White 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_white_7"
    }
  },
  WALL_WALL_ABYSS_YELLOW_0: {
    id: 121,
    name: "Parede Abyss Yellow 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_yellow_0"
    }
  },
  WALL_WALL_ABYSS_YELLOW_1: {
    id: 122,
    name: "Parede Abyss Yellow 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_yellow_1"
    }
  },
  WALL_WALL_ABYSS_YELLOW_2: {
    id: 123,
    name: "Parede Abyss Yellow 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_yellow_2"
    }
  },
  WALL_WALL_ABYSS_YELLOW_3: {
    id: 124,
    name: "Parede Abyss Yellow 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_yellow_3"
    }
  },
  WALL_WALL_ABYSS_YELLOW_4: {
    id: 125,
    name: "Parede Abyss Yellow 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_yellow_4"
    }
  },
  WALL_WALL_ABYSS_YELLOW_5: {
    id: 126,
    name: "Parede Abyss Yellow 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_yellow_5"
    }
  },
  WALL_WALL_ABYSS_YELLOW_6: {
    id: 127,
    name: "Parede Abyss Yellow 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_yellow_6"
    }
  },
  WALL_WALL_ABYSS_YELLOW_7: {
    id: 128,
    name: "Parede Abyss Yellow 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_abyss_yellow_7"
    }
  },
  WALL_WALL_BARS_RED_1: {
    id: 129,
    name: "Parede Bars Red 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_bars_red_1"
    }
  },
  WALL_WALL_BARS_RED_2: {
    id: 130,
    name: "Parede Bars Red 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_bars_red_2"
    }
  },
  WALL_WALL_BARS_RED_3: {
    id: 131,
    name: "Parede Bars Red 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_bars_red_3"
    }
  },
  WALL_WALL_BARS_RED_4: {
    id: 132,
    name: "Parede Bars Red 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_bars_red_4"
    }
  },
  WALL_WALL_BARS_RED_5: {
    id: 133,
    name: "Parede Bars Red 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_bars_red_5"
    }
  },
  WALL_WALL_BARS_RED_6: {
    id: 134,
    name: "Parede Bars Red 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_bars_red_6"
    }
  },
  WALL_WALL_BARS_RED_7: {
    id: 135,
    name: "Parede Bars Red 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_bars_red_7"
    }
  },
  WALL_WALL_BARS_RED_8: {
    id: 136,
    name: "Parede Bars Red 8",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_bars_red_8"
    }
  },
  WALL_WALL_BEEHIVES_0: {
    id: 137,
    name: "Parede Beehives 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_beehives_0"
    }
  },
  WALL_WALL_BEEHIVES_1: {
    id: 138,
    name: "Parede Beehives 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_beehives_1"
    }
  },
  WALL_WALL_BEEHIVES_2: {
    id: 139,
    name: "Parede Beehives 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_beehives_2"
    }
  },
  WALL_WALL_BEEHIVES_3: {
    id: 140,
    name: "Parede Beehives 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_beehives_3"
    }
  },
  WALL_WALL_BEEHIVES_4: {
    id: 141,
    name: "Parede Beehives 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_beehives_4"
    }
  },
  WALL_WALL_BEEHIVES_5: {
    id: 142,
    name: "Parede Beehives 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_beehives_5"
    }
  },
  WALL_WALL_BEEHIVES_6: {
    id: 143,
    name: "Parede Beehives 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_beehives_6"
    }
  },
  WALL_WALL_BEEHIVES_7: {
    id: 144,
    name: "Parede Beehives 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_beehives_7"
    }
  },
  WALL_WALL_BEEHIVES_8: {
    id: 145,
    name: "Parede Beehives 8",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_beehives_8"
    }
  },
  WALL_WALL_BEEHIVES_9: {
    id: 146,
    name: "Parede Beehives 9",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_beehives_9"
    }
  },
  WALL_WALL_BRICK_BROWN_VINES_1: {
    id: 147,
    name: "Parede Brick Brown-Vines 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown-vines_1"
    }
  },
  WALL_WALL_BRICK_BROWN_VINES_2: {
    id: 148,
    name: "Parede Brick Brown-Vines 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown-vines_2"
    }
  },
  WALL_WALL_BRICK_BROWN_VINES_3: {
    id: 149,
    name: "Parede Brick Brown-Vines 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown-vines_3"
    }
  },
  WALL_WALL_BRICK_BROWN_VINES_4: {
    id: 150,
    name: "Parede Brick Brown-Vines 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown-vines_4"
    }
  },
  WALL_WALL_BRICK_BROWN_0: {
    id: 151,
    name: "Parede Brick Brown 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown_0"
    }
  },
  WALL_WALL_BRICK_BROWN_1: {
    id: 152,
    name: "Parede Brick Brown 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown_1"
    }
  },
  WALL_WALL_BRICK_BROWN_2: {
    id: 153,
    name: "Parede Brick Brown 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown_2"
    }
  },
  WALL_WALL_BRICK_BROWN_3: {
    id: 154,
    name: "Parede Brick Brown 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown_3"
    }
  },
  WALL_WALL_BRICK_BROWN_4: {
    id: 155,
    name: "Parede Brick Brown 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown_4"
    }
  },
  WALL_WALL_BRICK_BROWN_5: {
    id: 156,
    name: "Parede Brick Brown 5",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown_5"
    }
  },
  WALL_WALL_BRICK_BROWN_6: {
    id: 157,
    name: "Parede Brick Brown 6",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown_6"
    }
  },
  WALL_WALL_BRICK_BROWN_7: {
    id: 158,
    name: "Parede Brick Brown 7",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_brown_7"
    }
  },
  WALL_WALL_BRICK_DARK_0: {
    id: 159,
    name: "Parede Brick Dark 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_dark_0"
    }
  },
  WALL_WALL_BRICK_DARK_1: {
    id: 160,
    name: "Parede Brick Dark 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_dark_1"
    }
  },
  WALL_WALL_BRICK_DARK_2: {
    id: 161,
    name: "Parede Brick Dark 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_dark_2"
    }
  },
  WALL_WALL_BRICK_DARK_3: {
    id: 162,
    name: "Parede Brick Dark 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_dark_3"
    }
  },
  WALL_WALL_BRICK_DARK_4: {
    id: 163,
    name: "Parede Brick Dark 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_dark_4"
    }
  },
  WALL_WALL_BRICK_DARK_5: {
    id: 164,
    name: "Parede Brick Dark 5",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_dark_5"
    }
  },
  WALL_WALL_BRICK_DARK_6: {
    id: 165,
    name: "Parede Brick Dark 6",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_dark_6"
    }
  },
  WALL_WALL_BRICK_GRAY_0: {
    id: 166,
    name: "Parede Brick Gray 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_gray_0"
    }
  },
  WALL_WALL_BRICK_GRAY_1: {
    id: 167,
    name: "Parede Brick Gray 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_gray_1"
    }
  },
  WALL_WALL_BRICK_GRAY_2: {
    id: 168,
    name: "Parede Brick Gray 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_gray_2"
    }
  },
  WALL_WALL_BRICK_GRAY_3: {
    id: 169,
    name: "Parede Brick Gray 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_brick_gray_3"
    }
  },
  WALL_WALL_CATACOMBS_0: {
    id: 170,
    name: "Parede Catacombs 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_0"
    }
  },
  WALL_WALL_CATACOMBS_1: {
    id: 171,
    name: "Parede Catacombs 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_1"
    }
  },
  WALL_WALL_CATACOMBS_10: {
    id: 172,
    name: "Parede Catacombs 10",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_10"
    }
  },
  WALL_WALL_CATACOMBS_11: {
    id: 173,
    name: "Parede Catacombs 11",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_11"
    }
  },
  WALL_WALL_CATACOMBS_12: {
    id: 174,
    name: "Parede Catacombs 12",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_12"
    }
  },
  WALL_WALL_CATACOMBS_13: {
    id: 175,
    name: "Parede Catacombs 13",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_13"
    }
  },
  WALL_WALL_CATACOMBS_14: {
    id: 176,
    name: "Parede Catacombs 14",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_14"
    }
  },
  WALL_WALL_CATACOMBS_15: {
    id: 177,
    name: "Parede Catacombs 15",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_15"
    }
  },
  WALL_WALL_CATACOMBS_2: {
    id: 178,
    name: "Parede Catacombs 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_2"
    }
  },
  WALL_WALL_CATACOMBS_3: {
    id: 179,
    name: "Parede Catacombs 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_3"
    }
  },
  WALL_WALL_CATACOMBS_4: {
    id: 180,
    name: "Parede Catacombs 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_4"
    }
  },
  WALL_WALL_CATACOMBS_5: {
    id: 181,
    name: "Parede Catacombs 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_5"
    }
  },
  WALL_WALL_CATACOMBS_6: {
    id: 182,
    name: "Parede Catacombs 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_6"
    }
  },
  WALL_WALL_CATACOMBS_7: {
    id: 183,
    name: "Parede Catacombs 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_7"
    }
  },
  WALL_WALL_CATACOMBS_8: {
    id: 184,
    name: "Parede Catacombs 8",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_8"
    }
  },
  WALL_WALL_CATACOMBS_9: {
    id: 185,
    name: "Parede Catacombs 9",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_catacombs_9"
    }
  },
  WALL_WALL_CHURCH_0: {
    id: 186,
    name: "Parede Church 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_church_0"
    }
  },
  WALL_WALL_CHURCH_1: {
    id: 187,
    name: "Parede Church 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_church_1"
    }
  },
  WALL_WALL_CHURCH_2: {
    id: 188,
    name: "Parede Church 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_church_2"
    }
  },
  WALL_WALL_CHURCH_3: {
    id: 189,
    name: "Parede Church 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_church_3"
    }
  },
  WALL_WALL_CHURCH_4: {
    id: 190,
    name: "Parede Church 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_church_4"
    }
  },
  WALL_WALL_COBALT_ROCK_1: {
    id: 191,
    name: "Parede Cobalt Rock 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_rock_1"
    }
  },
  WALL_WALL_COBALT_ROCK_2: {
    id: 192,
    name: "Parede Cobalt Rock 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_rock_2"
    }
  },
  WALL_WALL_COBALT_ROCK_3: {
    id: 193,
    name: "Parede Cobalt Rock 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_rock_3"
    }
  },
  WALL_WALL_COBALT_ROCK_4: {
    id: 194,
    name: "Parede Cobalt Rock 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_rock_4"
    }
  },
  WALL_WALL_COBALT_STONE_1: {
    id: 195,
    name: "Parede Cobalt Stone 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_1"
    }
  },
  WALL_WALL_COBALT_STONE_10: {
    id: 196,
    name: "Parede Cobalt Stone 10",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_10"
    }
  },
  WALL_WALL_COBALT_STONE_11: {
    id: 197,
    name: "Parede Cobalt Stone 11",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_11"
    }
  },
  WALL_WALL_COBALT_STONE_12: {
    id: 198,
    name: "Parede Cobalt Stone 12",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_12"
    }
  },
  WALL_WALL_COBALT_STONE_2: {
    id: 199,
    name: "Parede Cobalt Stone 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_2"
    }
  },
  WALL_WALL_COBALT_STONE_3: {
    id: 200,
    name: "Parede Cobalt Stone 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_3"
    }
  },
  WALL_WALL_COBALT_STONE_4: {
    id: 201,
    name: "Parede Cobalt Stone 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_4"
    }
  },
  WALL_WALL_COBALT_STONE_5: {
    id: 202,
    name: "Parede Cobalt Stone 5",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_5"
    }
  },
  WALL_WALL_COBALT_STONE_6: {
    id: 203,
    name: "Parede Cobalt Stone 6",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_6"
    }
  },
  WALL_WALL_COBALT_STONE_7: {
    id: 204,
    name: "Parede Cobalt Stone 7",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_7"
    }
  },
  WALL_WALL_COBALT_STONE_8: {
    id: 205,
    name: "Parede Cobalt Stone 8",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_8"
    }
  },
  WALL_WALL_COBALT_STONE_9: {
    id: 206,
    name: "Parede Cobalt Stone 9",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_cobalt_stone_9"
    }
  },
  WALL_WALL_CRYSTAL_WALL_0: {
    id: 207,
    name: "Parede Crystal Wall 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_0"
    }
  },
  WALL_WALL_CRYSTAL_WALL_1: {
    id: 208,
    name: "Parede Crystal Wall 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_1"
    }
  },
  WALL_WALL_CRYSTAL_WALL_11: {
    id: 209,
    name: "Parede Crystal Wall 11",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_11"
    }
  },
  WALL_WALL_CRYSTAL_WALL_12: {
    id: 210,
    name: "Parede Crystal Wall 12",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_12"
    }
  },
  WALL_WALL_CRYSTAL_WALL_13: {
    id: 211,
    name: "Parede Crystal Wall 13",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_13"
    }
  },
  WALL_WALL_CRYSTAL_WALL_1_0: {
    id: 212,
    name: "Parede Crystal Wall 1 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_1_0"
    }
  },
  WALL_WALL_CRYSTAL_WALL_2: {
    id: 213,
    name: "Parede Crystal Wall 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_2"
    }
  },
  WALL_WALL_CRYSTAL_WALL_3: {
    id: 214,
    name: "Parede Crystal Wall 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_3"
    }
  },
  WALL_WALL_CRYSTAL_WALL_4: {
    id: 215,
    name: "Parede Crystal Wall 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_4"
    }
  },
  WALL_WALL_CRYSTAL_WALL_5: {
    id: 216,
    name: "Parede Crystal Wall 5",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_5"
    }
  },
  WALL_WALL_CRYSTAL_WALL_6: {
    id: 217,
    name: "Parede Crystal Wall 6",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_6"
    }
  },
  WALL_WALL_CRYSTAL_WALL_7: {
    id: 218,
    name: "Parede Crystal Wall 7",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_7"
    }
  },
  WALL_WALL_CRYSTAL_WALL_8: {
    id: 219,
    name: "Parede Crystal Wall 8",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_8"
    }
  },
  WALL_WALL_CRYSTAL_WALL_9: {
    id: 220,
    name: "Parede Crystal Wall 9",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_crystal_wall_9"
    }
  },
  WALL_WALL_EMERALD_1: {
    id: 236,
    name: "Parede Emerald 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_emerald_1"
    }
  },
  WALL_WALL_EMERALD_2: {
    id: 237,
    name: "Parede Emerald 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_emerald_2"
    }
  },
  WALL_WALL_EMERALD_3: {
    id: 238,
    name: "Parede Emerald 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_emerald_3"
    }
  },
  WALL_WALL_EMERALD_4: {
    id: 239,
    name: "Parede Emerald 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_emerald_4"
    }
  },
  WALL_WALL_EMERALD_5: {
    id: 240,
    name: "Parede Emerald 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_emerald_5"
    }
  },
  WALL_WALL_EMERALD_6: {
    id: 241,
    name: "Parede Emerald 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_emerald_6"
    }
  },
  WALL_WALL_EMERALD_7: {
    id: 242,
    name: "Parede Emerald 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_emerald_7"
    }
  },
  WALL_WALL_EMERALD_8: {
    id: 243,
    name: "Parede Emerald 8",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_emerald_8"
    }
  },
  WALL_WALL_HELL_1: {
    id: 245,
    name: "Parede Hell 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_1"
    }
  },
  WALL_WALL_HELL_10: {
    id: 246,
    name: "Parede Hell 10",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_10"
    }
  },
  WALL_WALL_HELL_11: {
    id: 247,
    name: "Parede Hell 11",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_11"
    }
  },
  WALL_WALL_HELL_2: {
    id: 248,
    name: "Parede Hell 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_2"
    }
  },
  WALL_WALL_HELL_3: {
    id: 249,
    name: "Parede Hell 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_3"
    }
  },
  WALL_WALL_HELL_4: {
    id: 250,
    name: "Parede Hell 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_4"
    }
  },
  WALL_WALL_HELL_5: {
    id: 251,
    name: "Parede Hell 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_5"
    }
  },
  WALL_WALL_HELL_6: {
    id: 252,
    name: "Parede Hell 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_6"
    }
  },
  WALL_WALL_HELL_7: {
    id: 253,
    name: "Parede Hell 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_7"
    }
  },
  WALL_WALL_HELL_8: {
    id: 254,
    name: "Parede Hell 8",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_8"
    }
  },
  WALL_WALL_HELL_9: {
    id: 255,
    name: "Parede Hell 9",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hell_9"
    }
  },
  WALL_WALL_HIVE_0: {
    id: 256,
    name: "Parede Hive 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hive_0"
    }
  },
  WALL_WALL_HIVE_1: {
    id: 257,
    name: "Parede Hive 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hive_1"
    }
  },
  WALL_WALL_HIVE_2: {
    id: 258,
    name: "Parede Hive 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hive_2"
    }
  },
  WALL_WALL_HIVE_3: {
    id: 259,
    name: "Parede Hive 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_hive_3"
    }
  },
  WALL_WALL_LAB_METAL_0: {
    id: 260,
    name: "Parede Lab-Metal 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-metal_0"
    }
  },
  WALL_WALL_LAB_METAL_1: {
    id: 261,
    name: "Parede Lab-Metal 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-metal_1"
    }
  },
  WALL_WALL_LAB_METAL_2: {
    id: 262,
    name: "Parede Lab-Metal 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-metal_2"
    }
  },
  WALL_WALL_LAB_METAL_3: {
    id: 263,
    name: "Parede Lab-Metal 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-metal_3"
    }
  },
  WALL_WALL_LAB_METAL_4: {
    id: 264,
    name: "Parede Lab-Metal 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-metal_4"
    }
  },
  WALL_WALL_LAB_METAL_5: {
    id: 265,
    name: "Parede Lab-Metal 5",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-metal_5"
    }
  },
  WALL_WALL_LAB_METAL_6: {
    id: 266,
    name: "Parede Lab-Metal 6",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-metal_6"
    }
  },
  WALL_WALL_LAB_ROCK_0: {
    id: 267,
    name: "Parede Lab-Rock 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-rock_0"
    }
  },
  WALL_WALL_LAB_ROCK_1: {
    id: 268,
    name: "Parede Lab-Rock 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-rock_1"
    }
  },
  WALL_WALL_LAB_ROCK_2: {
    id: 269,
    name: "Parede Lab-Rock 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-rock_2"
    }
  },
  WALL_WALL_LAB_ROCK_3: {
    id: 270,
    name: "Parede Lab-Rock 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-rock_3"
    }
  },
  WALL_WALL_LAB_STONE_0: {
    id: 271,
    name: "Parede Lab-Stone 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-stone_0"
    }
  },
  WALL_WALL_LAB_STONE_1: {
    id: 272,
    name: "Parede Lab-Stone 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-stone_1"
    }
  },
  WALL_WALL_LAB_STONE_2: {
    id: 273,
    name: "Parede Lab-Stone 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-stone_2"
    }
  },
  WALL_WALL_LAB_STONE_3: {
    id: 274,
    name: "Parede Lab-Stone 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-stone_3"
    }
  },
  WALL_WALL_LAB_STONE_4: {
    id: 275,
    name: "Parede Lab-Stone 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-stone_4"
    }
  },
  WALL_WALL_LAB_STONE_5: {
    id: 276,
    name: "Parede Lab-Stone 5",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lab-stone_5"
    }
  },
  WALL_WALL_LAIR_0: {
    id: 277,
    name: "Parede Lair 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lair_0"
    }
  },
  WALL_WALL_LAIR_1: {
    id: 278,
    name: "Parede Lair 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lair_1"
    }
  },
  WALL_WALL_LAIR_2: {
    id: 279,
    name: "Parede Lair 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lair_2"
    }
  },
  WALL_WALL_LAIR_3: {
    id: 280,
    name: "Parede Lair 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_lair_3"
    }
  },
  WALL_WALL_MARBLE_WALL_1: {
    id: 281,
    name: "Parede Marble Wall 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_1"
    }
  },
  WALL_WALL_MARBLE_WALL_10: {
    id: 282,
    name: "Parede Marble Wall 10",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_10"
    }
  },
  WALL_WALL_MARBLE_WALL_11: {
    id: 283,
    name: "Parede Marble Wall 11",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_11"
    }
  },
  WALL_WALL_MARBLE_WALL_12: {
    id: 284,
    name: "Parede Marble Wall 12",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_12"
    }
  },
  WALL_WALL_MARBLE_WALL_2: {
    id: 285,
    name: "Parede Marble Wall 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_2"
    }
  },
  WALL_WALL_MARBLE_WALL_3: {
    id: 286,
    name: "Parede Marble Wall 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_3"
    }
  },
  WALL_WALL_MARBLE_WALL_4: {
    id: 287,
    name: "Parede Marble Wall 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_4"
    }
  },
  WALL_WALL_MARBLE_WALL_5: {
    id: 288,
    name: "Parede Marble Wall 5",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_5"
    }
  },
  WALL_WALL_MARBLE_WALL_6: {
    id: 289,
    name: "Parede Marble Wall 6",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_6"
    }
  },
  WALL_WALL_MARBLE_WALL_7: {
    id: 290,
    name: "Parede Marble Wall 7",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_7"
    }
  },
  WALL_WALL_MARBLE_WALL_8: {
    id: 291,
    name: "Parede Marble Wall 8",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_8"
    }
  },
  WALL_WALL_MARBLE_WALL_9: {
    id: 292,
    name: "Parede Marble Wall 9",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_marble_wall_9"
    }
  },
  WALL_WALL_METAL_WALL: {
    id: 293,
    name: "Parede Metal Wall",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_metal_wall"
    }
  },
  WALL_WALL_METAL_WALL_BROWN: {
    id: 294,
    name: "Parede Metal Wall Brown",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_metal_wall_brown"
    }
  },
  WALL_WALL_METAL_WALL_CRACKED: {
    id: 295,
    name: "Parede Metal Wall Cracked",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_metal_wall_cracked"
    }
  },
  WALL_WALL_METAL_WALL_WHITE_0: {
    id: 296,
    name: "Parede Metal Wall White 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_metal_wall_white_0"
    }
  },
  WALL_WALL_METAL_WALL_WHITE_1: {
    id: 297,
    name: "Parede Metal Wall White 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_metal_wall_white_1"
    }
  },
  WALL_WALL_METAL_WALL_WHITE_2: {
    id: 298,
    name: "Parede Metal Wall White 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_metal_wall_white_2"
    }
  },
  WALL_WALL_MIRRORED_WALL: {
    id: 299,
    name: "Parede Mirrored Wall",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_mirrored_wall"
    }
  },
  WALL_WALL_ORC_0: {
    id: 300,
    name: "Parede Orc 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_0"
    }
  },
  WALL_WALL_ORC_1: {
    id: 301,
    name: "Parede Orc 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_1"
    }
  },
  WALL_WALL_ORC_10: {
    id: 302,
    name: "Parede Orc 10",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_10"
    }
  },
  WALL_WALL_ORC_11: {
    id: 303,
    name: "Parede Orc 11",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_11"
    }
  },
  WALL_WALL_ORC_2: {
    id: 304,
    name: "Parede Orc 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_2"
    }
  },
  WALL_WALL_ORC_3: {
    id: 305,
    name: "Parede Orc 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_3"
    }
  },
  WALL_WALL_ORC_4: {
    id: 306,
    name: "Parede Orc 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_4"
    }
  },
  WALL_WALL_ORC_5: {
    id: 307,
    name: "Parede Orc 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_5"
    }
  },
  WALL_WALL_ORC_6: {
    id: 308,
    name: "Parede Orc 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_6"
    }
  },
  WALL_WALL_ORC_7: {
    id: 309,
    name: "Parede Orc 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_7"
    }
  },
  WALL_WALL_ORC_8: {
    id: 310,
    name: "Parede Orc 8",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_8"
    }
  },
  WALL_WALL_ORC_9: {
    id: 311,
    name: "Parede Orc 9",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_orc_9"
    }
  },
  WALL_WALL_PEBBLE_RED_0: {
    id: 312,
    name: "Parede Pebble Red 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_pebble_red_0"
    }
  },
  WALL_WALL_PEBBLE_RED_1: {
    id: 313,
    name: "Parede Pebble Red 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_pebble_red_1"
    }
  },
  WALL_WALL_PEBBLE_RED_2: {
    id: 314,
    name: "Parede Pebble Red 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_pebble_red_2"
    }
  },
  WALL_WALL_PEBBLE_RED_3: {
    id: 315,
    name: "Parede Pebble Red 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_pebble_red_3"
    }
  },
  WALL_WALL_PERMAROCK_CLEAR_RED_0: {
    id: 316,
    name: "Parede Permarock Clear Red 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_permarock_clear_red_0"
    }
  },
  WALL_WALL_PERMAROCK_RED_0: {
    id: 317,
    name: "Parede Permarock Red 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_permarock_red_0"
    }
  },
  WALL_WALL_RELIEF_0: {
    id: 318,
    name: "Parede Relief 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_relief_0"
    }
  },
  WALL_WALL_RELIEF_1: {
    id: 319,
    name: "Parede Relief 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_relief_1"
    }
  },
  WALL_WALL_RELIEF_2: {
    id: 320,
    name: "Parede Relief 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_relief_2"
    }
  },
  WALL_WALL_RELIEF_3: {
    id: 321,
    name: "Parede Relief 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_relief_3"
    }
  },
  WALL_WALL_RELIEF_BROWN_0: {
    id: 322,
    name: "Parede Relief Brown 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_relief_brown_0"
    }
  },
  WALL_WALL_RELIEF_BROWN_1: {
    id: 323,
    name: "Parede Relief Brown 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_relief_brown_1"
    }
  },
  WALL_WALL_RELIEF_BROWN_2: {
    id: 324,
    name: "Parede Relief Brown 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_relief_brown_2"
    }
  },
  WALL_WALL_RELIEF_BROWN_3: {
    id: 325,
    name: "Parede Relief Brown 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_relief_brown_3"
    }
  },
  WALL_WALL_SHOALS_WALL_1: {
    id: 350,
    name: "Parede Shoals Wall 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_shoals_wall_1"
    }
  },
  WALL_WALL_SHOALS_WALL_2: {
    id: 351,
    name: "Parede Shoals Wall 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_shoals_wall_2"
    }
  },
  WALL_WALL_SHOALS_WALL_3: {
    id: 352,
    name: "Parede Shoals Wall 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_shoals_wall_3"
    }
  },
  WALL_WALL_SHOALS_WALL_4: {
    id: 353,
    name: "Parede Shoals Wall 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_shoals_wall_4"
    }
  },
  WALL_WALL_SLIME_0: {
    id: 355,
    name: "Parede Slime 0",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_0"
    }
  },
  WALL_WALL_SLIME_1: {
    id: 356,
    name: "Parede Slime 1",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_1"
    }
  },
  WALL_WALL_SLIME_2: {
    id: 357,
    name: "Parede Slime 2",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_2"
    }
  },
  WALL_WALL_SLIME_3: {
    id: 358,
    name: "Parede Slime 3",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_3"
    }
  },
  WALL_WALL_SLIME_4: {
    id: 359,
    name: "Parede Slime 4",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_4"
    }
  },
  WALL_WALL_SLIME_5: {
    id: 360,
    name: "Parede Slime 5",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_5"
    }
  },
  WALL_WALL_SLIME_6: {
    id: 361,
    name: "Parede Slime 6",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_6"
    }
  },
  WALL_WALL_SLIME_7: {
    id: 362,
    name: "Parede Slime 7",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_7"
    }
  },
  WALL_WALL_SLIME_STONE_0: {
    id: 363,
    name: "Parede Slime Stone 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_stone_0"
    }
  },
  WALL_WALL_SLIME_STONE_1: {
    id: 364,
    name: "Parede Slime Stone 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_stone_1"
    }
  },
  WALL_WALL_SLIME_STONE_2: {
    id: 365,
    name: "Parede Slime Stone 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_slime_stone_2"
    }
  },
  WALL_WALL_SNAKE_0: {
    id: 366,
    name: "Parede Snake 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_snake_0"
    }
  },
  WALL_WALL_SNAKE_1: {
    id: 367,
    name: "Parede Snake 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_snake_1"
    }
  },
  WALL_WALL_SNAKE_2: {
    id: 368,
    name: "Parede Snake 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_snake_2"
    }
  },
  WALL_WALL_SNAKE_3: {
    id: 369,
    name: "Parede Snake 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_snake_3"
    }
  },
  WALL_WALL_SNAKE_4: {
    id: 370,
    name: "Parede Snake 4",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_snake_4"
    }
  },
  WALL_WALL_SNAKE_5: {
    id: 371,
    name: "Parede Snake 5",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_snake_5"
    }
  },
  WALL_WALL_SNAKE_6: {
    id: 372,
    name: "Parede Snake 6",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_snake_6"
    }
  },
  WALL_WALL_SNAKE_7: {
    id: 373,
    name: "Parede Snake 7",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_snake_7"
    }
  },
  WALL_WALL_SNAKE_8: {
    id: 374,
    name: "Parede Snake 8",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_snake_8"
    }
  },
  WALL_WALL_SNAKE_9: {
    id: 375,
    name: "Parede Snake 9",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_snake_9"
    }
  },
  WALL_WALL_STONE_BLACK_MARKED_0: {
    id: 394,
    name: "Parede Stone Black Marked 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_black_marked_0"
    }
  },
  WALL_WALL_STONE_BLACK_MARKED_1: {
    id: 395,
    name: "Parede Stone Black Marked 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_black_marked_1"
    }
  },
  WALL_WALL_STONE_BLACK_MARKED_2: {
    id: 396,
    name: "Parede Stone Black Marked 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_black_marked_2"
    }
  },
  WALL_WALL_STONE_BLACK_MARKED_3: {
    id: 397,
    name: "Parede Stone Black Marked 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_black_marked_3"
    }
  },
  WALL_WALL_STONE_BLACK_MARKED_4: {
    id: 398,
    name: "Parede Stone Black Marked 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_black_marked_4"
    }
  },
  WALL_WALL_STONE_BLACK_MARKED_5: {
    id: 399,
    name: "Parede Stone Black Marked 5",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_black_marked_5"
    }
  },
  WALL_WALL_STONE_BLACK_MARKED_6: {
    id: 400,
    name: "Parede Stone Black Marked 6",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_black_marked_6"
    }
  },
  WALL_WALL_STONE_BLACK_MARKED_7: {
    id: 401,
    name: "Parede Stone Black Marked 7",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_black_marked_7"
    }
  },
  WALL_WALL_STONE_BLACK_MARKED_8: {
    id: 402,
    name: "Parede Stone Black Marked 8",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_black_marked_8"
    }
  },
  WALL_WALL_STONE_BRICK_1: {
    id: 403,
    name: "Parede Stone Brick 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_1"
    }
  },
  WALL_WALL_STONE_BRICK_10: {
    id: 404,
    name: "Parede Stone Brick 10",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_10"
    }
  },
  WALL_WALL_STONE_BRICK_11: {
    id: 405,
    name: "Parede Stone Brick 11",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_11"
    }
  },
  WALL_WALL_STONE_BRICK_12: {
    id: 406,
    name: "Parede Stone Brick 12",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_12"
    }
  },
  WALL_WALL_STONE_BRICK_2: {
    id: 407,
    name: "Parede Stone Brick 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_2"
    }
  },
  WALL_WALL_STONE_BRICK_3: {
    id: 408,
    name: "Parede Stone Brick 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_3"
    }
  },
  WALL_WALL_STONE_BRICK_4: {
    id: 409,
    name: "Parede Stone Brick 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_4"
    }
  },
  WALL_WALL_STONE_BRICK_5: {
    id: 410,
    name: "Parede Stone Brick 5",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_5"
    }
  },
  WALL_WALL_STONE_BRICK_6: {
    id: 411,
    name: "Parede Stone Brick 6",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_6"
    }
  },
  WALL_WALL_STONE_BRICK_7: {
    id: 412,
    name: "Parede Stone Brick 7",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_7"
    }
  },
  WALL_WALL_STONE_BRICK_8: {
    id: 413,
    name: "Parede Stone Brick 8",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_8"
    }
  },
  WALL_WALL_STONE_BRICK_9: {
    id: 414,
    name: "Parede Stone Brick 9",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_stone_brick_9"
    }
  },
  WALL_WALL_TOMB_0: {
    id: 423,
    name: "Parede Tomb 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_tomb_0"
    }
  },
  WALL_WALL_TOMB_1: {
    id: 424,
    name: "Parede Tomb 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_tomb_1"
    }
  },
  WALL_WALL_TOMB_2: {
    id: 425,
    name: "Parede Tomb 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_tomb_2"
    }
  },
  WALL_WALL_TOMB_3: {
    id: 426,
    name: "Parede Tomb 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_tomb_3"
    }
  },
  WALL_WALL_VAULT_0: {
    id: 438,
    name: "Parede Vault 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_vault_0"
    }
  },
  WALL_WALL_VAULT_1: {
    id: 439,
    name: "Parede Vault 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_vault_1"
    }
  },
  WALL_WALL_VAULT_2: {
    id: 440,
    name: "Parede Vault 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_vault_2"
    }
  },
  WALL_WALL_VAULT_3: {
    id: 441,
    name: "Parede Vault 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_vault_3"
    }
  },
  WALL_WALL_VOLCANIC_WALL_0: {
    id: 442,
    name: "Parede Volcanic Wall 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_volcanic_wall_0"
    }
  },
  WALL_WALL_VOLCANIC_WALL_1: {
    id: 443,
    name: "Parede Volcanic Wall 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_volcanic_wall_1"
    }
  },
  WALL_WALL_VOLCANIC_WALL_2: {
    id: 444,
    name: "Parede Volcanic Wall 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_volcanic_wall_2"
    }
  },
  WALL_WALL_VOLCANIC_WALL_3: {
    id: 445,
    name: "Parede Volcanic Wall 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_volcanic_wall_3"
    }
  },
  WALL_WALL_VOLCANIC_WALL_4: {
    id: 446,
    name: "Parede Volcanic Wall 4",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_volcanic_wall_4"
    }
  },
  WALL_WALL_VOLCANIC_WALL_5: {
    id: 447,
    name: "Parede Volcanic Wall 5",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_volcanic_wall_5"
    }
  },
  WALL_WALL_VOLCANIC_WALL_6: {
    id: 448,
    name: "Parede Volcanic Wall 6",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_volcanic_wall_6"
    }
  },
  WALL_WALL_WALL_FLESH_0: {
    id: 449,
    name: "Parede Wall Flesh 0",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_flesh_0"
    }
  },
  WALL_WALL_WALL_FLESH_1: {
    id: 450,
    name: "Parede Wall Flesh 1",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_flesh_1"
    }
  },
  WALL_WALL_WALL_FLESH_2: {
    id: 451,
    name: "Parede Wall Flesh 2",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_flesh_2"
    }
  },
  WALL_WALL_WALL_FLESH_3: {
    id: 452,
    name: "Parede Wall Flesh 3",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_flesh_3"
    }
  },
  WALL_WALL_WALL_FLESH_4: {
    id: 453,
    name: "Parede Wall Flesh 4",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_flesh_4"
    }
  },
  WALL_WALL_WALL_FLESH_5: {
    id: 454,
    name: "Parede Wall Flesh 5",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_flesh_5"
    }
  },
  WALL_WALL_WALL_FLESH_6: {
    id: 455,
    name: "Parede Wall Flesh 6",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_flesh_6"
    }
  },
  WALL_WALL_WALL_VINES_0: {
    id: 456,
    name: "Parede Wall Vines 0",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_vines_0"
    }
  },
  WALL_WALL_WALL_VINES_1: {
    id: 457,
    name: "Parede Wall Vines 1",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_vines_1"
    }
  },
  WALL_WALL_WALL_VINES_2: {
    id: 458,
    name: "Parede Wall Vines 2",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_vines_2"
    }
  },
  WALL_WALL_WALL_VINES_3: {
    id: 459,
    name: "Parede Wall Vines 3",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_vines_3"
    }
  },
  WALL_WALL_WALL_VINES_4: {
    id: 460,
    name: "Parede Wall Vines 4",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_vines_4"
    }
  },
  WALL_WALL_WALL_VINES_5: {
    id: 461,
    name: "Parede Wall Vines 5",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_vines_5"
    }
  },
  WALL_WALL_WALL_VINES_6: {
    id: 462,
    name: "Parede Wall Vines 6",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_vines_6"
    }
  },
  WALL_WALL_WALL_YELLOW_ROCK_0: {
    id: 463,
    name: "Parede Wall Yellow Rock 0",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_yellow_rock_0"
    }
  },
  WALL_WALL_WALL_YELLOW_ROCK_1: {
    id: 464,
    name: "Parede Wall Yellow Rock 1",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_yellow_rock_1"
    }
  },
  WALL_WALL_WALL_YELLOW_ROCK_2: {
    id: 465,
    name: "Parede Wall Yellow Rock 2",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_yellow_rock_2"
    }
  },
  WALL_WALL_WALL_YELLOW_ROCK_3: {
    id: 466,
    name: "Parede Wall Yellow Rock 3",
    solid: true,
    maxHP: 100,
    breakDamage: 12,
    bulletSpeed: 0.24,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wall_yellow_rock_3"
    }
  },
  WALL_WALL_WAX_WALL: {
    id: 467,
    name: "Parede Wax Wall",
    solid: true,
    maxHP: 70,
    breakDamage: 8,
    bulletSpeed: 0.26,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_wax_wall"
    }
  },
  WALL_WALL_ZOT_BLUE_0: {
    id: 468,
    name: "Parede Zot Blue 0",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_zot_blue_0"
    }
  },
  WALL_WALL_ZOT_BLUE_1: {
    id: 469,
    name: "Parede Zot Blue 1",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_zot_blue_1"
    }
  },
  WALL_WALL_ZOT_BLUE_2: {
    id: 470,
    name: "Parede Zot Blue 2",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_zot_blue_2"
    }
  },
  WALL_WALL_ZOT_BLUE_3: {
    id: 471,
    name: "Parede Zot Blue 3",
    solid: true,
    maxHP: 140,
    breakDamage: 16,
    bulletSpeed: 0.22,
    bulletLifetime: 40,
    isFloor: false,
    opacity: 1,
    droppable: true,
    textures: {
      all: "wall_zot_blue_3"
    }
  },
  FLOOR_FLOOR_ACIDIC_FLOOR_0: {
    id: 472,
    name: "Chao Acidic Floor 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_acidic_floor_0"
    }
  },
  FLOOR_FLOOR_ACIDIC_FLOOR_1: {
    id: 473,
    name: "Chao Acidic Floor 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_acidic_floor_1"
    }
  },
  FLOOR_FLOOR_ACIDIC_FLOOR_2: {
    id: 474,
    name: "Chao Acidic Floor 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_acidic_floor_2"
    }
  },
  FLOOR_FLOOR_ACIDIC_FLOOR_3: {
    id: 475,
    name: "Chao Acidic Floor 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_acidic_floor_3"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_1: {
    id: 476,
    name: "Chao Black Cobalt 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_1"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_10: {
    id: 477,
    name: "Chao Black Cobalt 10",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_10"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_11: {
    id: 478,
    name: "Chao Black Cobalt 11",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_11"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_12: {
    id: 479,
    name: "Chao Black Cobalt 12",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_12"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_2: {
    id: 480,
    name: "Chao Black Cobalt 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_2"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_3: {
    id: 481,
    name: "Chao Black Cobalt 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_3"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_4: {
    id: 482,
    name: "Chao Black Cobalt 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_4"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_5: {
    id: 483,
    name: "Chao Black Cobalt 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_5"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_6: {
    id: 484,
    name: "Chao Black Cobalt 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_6"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_7: {
    id: 485,
    name: "Chao Black Cobalt 7",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_7"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_8: {
    id: 486,
    name: "Chao Black Cobalt 8",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_8"
    }
  },
  FLOOR_FLOOR_BLACK_COBALT_9: {
    id: 487,
    name: "Chao Black Cobalt 9",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_black_cobalt_9"
    }
  },
  FLOOR_FLOOR_BOG_GREEN_0: {
    id: 488,
    name: "Chao Bog Green 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_bog_green_0"
    }
  },
  FLOOR_FLOOR_BOG_GREEN_1: {
    id: 489,
    name: "Chao Bog Green 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_bog_green_1"
    }
  },
  FLOOR_FLOOR_BOG_GREEN_2: {
    id: 490,
    name: "Chao Bog Green 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_bog_green_2"
    }
  },
  FLOOR_FLOOR_BOG_GREEN_3: {
    id: 491,
    name: "Chao Bog Green 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_bog_green_3"
    }
  },
  FLOOR_FLOOR_CAGE_0: {
    id: 492,
    name: "Chao Cage 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cage_0"
    }
  },
  FLOOR_FLOOR_CAGE_1: {
    id: 493,
    name: "Chao Cage 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cage_1"
    }
  },
  FLOOR_FLOOR_CAGE_2: {
    id: 494,
    name: "Chao Cage 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cage_2"
    }
  },
  FLOOR_FLOOR_CAGE_3: {
    id: 495,
    name: "Chao Cage 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cage_3"
    }
  },
  FLOOR_FLOOR_CAGE_4: {
    id: 496,
    name: "Chao Cage 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cage_4"
    }
  },
  FLOOR_FLOOR_CAGE_5: {
    id: 497,
    name: "Chao Cage 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cage_5"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_10: {
    id: 498,
    name: "Chao Cobble Blood 10",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_10"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_11: {
    id: 499,
    name: "Chao Cobble Blood 11",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_11"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_12: {
    id: 500,
    name: "Chao Cobble Blood 12",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_12"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_1: {
    id: 501,
    name: "Chao Cobble Blood 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_1"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_2: {
    id: 502,
    name: "Chao Cobble Blood 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_2"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_3: {
    id: 503,
    name: "Chao Cobble Blood 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_3"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_4: {
    id: 504,
    name: "Chao Cobble Blood 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_4"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_5: {
    id: 505,
    name: "Chao Cobble Blood 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_5"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_6: {
    id: 506,
    name: "Chao Cobble Blood 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_6"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_7: {
    id: 507,
    name: "Chao Cobble Blood 7",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_7"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_8: {
    id: 508,
    name: "Chao Cobble Blood 8",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_8"
    }
  },
  FLOOR_FLOOR_COBBLE_BLOOD_9: {
    id: 509,
    name: "Chao Cobble Blood 9",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_cobble_blood_9"
    }
  },
  FLOOR_FLOOR_CRYPT_10: {
    id: 510,
    name: "Chao Crypt 10",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_10"
    }
  },
  FLOOR_FLOOR_CRYPT_11: {
    id: 511,
    name: "Chao Crypt 11",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_11"
    }
  },
  FLOOR_FLOOR_CRYPT_DOMINO_1A: {
    id: 512,
    name: "Chao Crypt Domino 1A",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_domino_1a"
    }
  },
  FLOOR_FLOOR_CRYPT_DOMINO_1B: {
    id: 513,
    name: "Chao Crypt Domino 1B",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_domino_1b"
    }
  },
  FLOOR_FLOOR_CRYPT_DOMINO_2A: {
    id: 514,
    name: "Chao Crypt Domino 2A",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_domino_2a"
    }
  },
  FLOOR_FLOOR_CRYPT_DOMINO_3A: {
    id: 515,
    name: "Chao Crypt Domino 3A",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_domino_3a"
    }
  },
  FLOOR_FLOOR_CRYPT_DOMINO_4A: {
    id: 516,
    name: "Chao Crypt Domino 4A",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_domino_4a"
    }
  },
  FLOOR_FLOOR_CRYPT_DOMINO_4B: {
    id: 517,
    name: "Chao Crypt Domino 4B",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_domino_4b"
    }
  },
  FLOOR_FLOOR_CRYPT_DOMINO_5A: {
    id: 518,
    name: "Chao Crypt Domino 5A",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_domino_5a"
    }
  },
  FLOOR_FLOOR_CRYPT_DOMINO_6A: {
    id: 519,
    name: "Chao Crypt Domino 6A",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_domino_6a"
    }
  },
  FLOOR_FLOOR_CRYPT_DOMINO_7A: {
    id: 520,
    name: "Chao Crypt Domino 7A",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_domino_7a"
    }
  },
  FLOOR_FLOOR_CRYPT_DOMINO_8A: {
    id: 521,
    name: "Chao Crypt Domino 8A",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crypt_domino_8a"
    }
  },
  FLOOR_FLOOR_CRYSTAL_FLOOR_0: {
    id: 522,
    name: "Chao Crystal Floor 0",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crystal_floor_0"
    }
  },
  FLOOR_FLOOR_CRYSTAL_FLOOR_1: {
    id: 523,
    name: "Chao Crystal Floor 1",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crystal_floor_1"
    }
  },
  FLOOR_FLOOR_CRYSTAL_FLOOR_2: {
    id: 524,
    name: "Chao Crystal Floor 2",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crystal_floor_2"
    }
  },
  FLOOR_FLOOR_CRYSTAL_FLOOR_3: {
    id: 525,
    name: "Chao Crystal Floor 3",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crystal_floor_3"
    }
  },
  FLOOR_FLOOR_CRYSTAL_FLOOR_4: {
    id: 526,
    name: "Chao Crystal Floor 4",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crystal_floor_4"
    }
  },
  FLOOR_FLOOR_CRYSTAL_FLOOR_5: {
    id: 527,
    name: "Chao Crystal Floor 5",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_crystal_floor_5"
    }
  },
  FLOOR_FLOOR_DEMONIC_RED_1: {
    id: 528,
    name: "Chao Demonic Red 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_demonic_red_1"
    }
  },
  FLOOR_FLOOR_DEMONIC_RED_2: {
    id: 529,
    name: "Chao Demonic Red 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_demonic_red_2"
    }
  },
  FLOOR_FLOOR_DEMONIC_RED_3: {
    id: 530,
    name: "Chao Demonic Red 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_demonic_red_3"
    }
  },
  FLOOR_FLOOR_DEMONIC_RED_4: {
    id: 531,
    name: "Chao Demonic Red 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_demonic_red_4"
    }
  },
  FLOOR_FLOOR_DEMONIC_RED_5: {
    id: 532,
    name: "Chao Demonic Red 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_demonic_red_5"
    }
  },
  FLOOR_FLOOR_DEMONIC_RED_6: {
    id: 533,
    name: "Chao Demonic Red 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_demonic_red_6"
    }
  },
  FLOOR_FLOOR_DEMONIC_RED_7: {
    id: 534,
    name: "Chao Demonic Red 7",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_demonic_red_7"
    }
  },
  FLOOR_FLOOR_DEMONIC_RED_8: {
    id: 535,
    name: "Chao Demonic Red 8",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_demonic_red_8"
    }
  },
  FLOOR_FLOOR_DEMONIC_RED_9: {
    id: 536,
    name: "Chao Demonic Red 9",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_demonic_red_9"
    }
  },
  FLOOR_FLOOR_DIRT_0: {
    id: 537,
    name: "Chao Dirt 0",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_0"
    }
  },
  FLOOR_FLOOR_DIRT_1: {
    id: 538,
    name: "Chao Dirt 1",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_1"
    }
  },
  FLOOR_FLOOR_DIRT_2: {
    id: 539,
    name: "Chao Dirt 2",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_2"
    }
  },
  FLOOR_FLOOR_DIRT_EAST: {
    id: 540,
    name: "Chao Dirt East",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_east"
    }
  },
  FLOOR_FLOOR_DIRT_FULL: {
    id: 541,
    name: "Chao Dirt Full",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_full"
    }
  },
  FLOOR_FLOOR_DIRT_NORTH: {
    id: 542,
    name: "Chao Dirt North",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_north"
    }
  },
  FLOOR_FLOOR_DIRT_NORTHEAST: {
    id: 543,
    name: "Chao Dirt Northeast",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_northeast"
    }
  },
  FLOOR_FLOOR_DIRT_NORTHWEST: {
    id: 544,
    name: "Chao Dirt Northwest",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_northwest"
    }
  },
  FLOOR_FLOOR_DIRT_SOUTH: {
    id: 545,
    name: "Chao Dirt South",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_south"
    }
  },
  FLOOR_FLOOR_DIRT_SOUTHEAST: {
    id: 546,
    name: "Chao Dirt Southeast",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_southeast"
    }
  },
  FLOOR_FLOOR_DIRT_SOUTHWEST: {
    id: 547,
    name: "Chao Dirt Southwest",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_southwest"
    }
  },
  FLOOR_FLOOR_DIRT_WEST: {
    id: 548,
    name: "Chao Dirt West",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_dirt_west"
    }
  },
  FLOOR_FLOOR_ETCHED_0: {
    id: 549,
    name: "Chao Etched 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_etched_0"
    }
  },
  FLOOR_FLOOR_ETCHED_1: {
    id: 550,
    name: "Chao Etched 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_etched_1"
    }
  },
  FLOOR_FLOOR_ETCHED_2: {
    id: 551,
    name: "Chao Etched 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_etched_2"
    }
  },
  FLOOR_FLOOR_ETCHED_3: {
    id: 552,
    name: "Chao Etched 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_etched_3"
    }
  },
  FLOOR_FLOOR_ETCHED_4: {
    id: 553,
    name: "Chao Etched 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_etched_4"
    }
  },
  FLOOR_FLOOR_ETCHED_5: {
    id: 554,
    name: "Chao Etched 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_etched_5"
    }
  },
  FLOOR_FLOOR_FLOOR_NERVES_0: {
    id: 555,
    name: "Chao Floor Nerves 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_nerves_0"
    }
  },
  FLOOR_FLOOR_FLOOR_NERVES_1: {
    id: 556,
    name: "Chao Floor Nerves 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_nerves_1"
    }
  },
  FLOOR_FLOOR_FLOOR_NERVES_2: {
    id: 557,
    name: "Chao Floor Nerves 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_nerves_2"
    }
  },
  FLOOR_FLOOR_FLOOR_NERVES_3: {
    id: 558,
    name: "Chao Floor Nerves 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_nerves_3"
    }
  },
  FLOOR_FLOOR_FLOOR_NERVES_4: {
    id: 559,
    name: "Chao Floor Nerves 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_nerves_4"
    }
  },
  FLOOR_FLOOR_FLOOR_NERVES_5: {
    id: 560,
    name: "Chao Floor Nerves 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_nerves_5"
    }
  },
  FLOOR_FLOOR_FLOOR_NERVES_6: {
    id: 561,
    name: "Chao Floor Nerves 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_nerves_6"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_ROCK_0: {
    id: 562,
    name: "Chao Floor Sand Rock 0",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_rock_0"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_ROCK_1: {
    id: 563,
    name: "Chao Floor Sand Rock 1",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_rock_1"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_ROCK_2: {
    id: 564,
    name: "Chao Floor Sand Rock 2",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_rock_2"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_ROCK_3: {
    id: 565,
    name: "Chao Floor Sand Rock 3",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_rock_3"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_STONE_0: {
    id: 566,
    name: "Chao Floor Sand Stone 0",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_stone_0"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_STONE_1: {
    id: 567,
    name: "Chao Floor Sand Stone 1",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_stone_1"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_STONE_2: {
    id: 568,
    name: "Chao Floor Sand Stone 2",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_stone_2"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_STONE_3: {
    id: 569,
    name: "Chao Floor Sand Stone 3",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_stone_3"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_STONE_4: {
    id: 570,
    name: "Chao Floor Sand Stone 4",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_stone_4"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_STONE_5: {
    id: 571,
    name: "Chao Floor Sand Stone 5",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_stone_5"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_STONE_6: {
    id: 572,
    name: "Chao Floor Sand Stone 6",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_stone_6"
    }
  },
  FLOOR_FLOOR_FLOOR_SAND_STONE_7: {
    id: 573,
    name: "Chao Floor Sand Stone 7",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_sand_stone_7"
    }
  },
  FLOOR_FLOOR_FLOOR_VINES_0: {
    id: 574,
    name: "Chao Floor Vines 0",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_vines_0"
    }
  },
  FLOOR_FLOOR_FLOOR_VINES_1: {
    id: 575,
    name: "Chao Floor Vines 1",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_vines_1"
    }
  },
  FLOOR_FLOOR_FLOOR_VINES_2: {
    id: 576,
    name: "Chao Floor Vines 2",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_vines_2"
    }
  },
  FLOOR_FLOOR_FLOOR_VINES_3: {
    id: 577,
    name: "Chao Floor Vines 3",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_vines_3"
    }
  },
  FLOOR_FLOOR_FLOOR_VINES_4: {
    id: 578,
    name: "Chao Floor Vines 4",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_vines_4"
    }
  },
  FLOOR_FLOOR_FLOOR_VINES_5: {
    id: 579,
    name: "Chao Floor Vines 5",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_vines_5"
    }
  },
  FLOOR_FLOOR_FLOOR_VINES_6: {
    id: 580,
    name: "Chao Floor Vines 6",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_floor_vines_6"
    }
  },
  FLOOR_FLOOR_FROZEN_0: {
    id: 581,
    name: "Chao Frozen 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_0"
    }
  },
  FLOOR_FLOOR_FROZEN_1: {
    id: 582,
    name: "Chao Frozen 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_1"
    }
  },
  FLOOR_FLOOR_FROZEN_10: {
    id: 583,
    name: "Chao Frozen 10",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_10"
    }
  },
  FLOOR_FLOOR_FROZEN_11: {
    id: 584,
    name: "Chao Frozen 11",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_11"
    }
  },
  FLOOR_FLOOR_FROZEN_12: {
    id: 585,
    name: "Chao Frozen 12",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_12"
    }
  },
  FLOOR_FLOOR_FROZEN_2: {
    id: 586,
    name: "Chao Frozen 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_2"
    }
  },
  FLOOR_FLOOR_FROZEN_3: {
    id: 587,
    name: "Chao Frozen 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_3"
    }
  },
  FLOOR_FLOOR_FROZEN_4: {
    id: 588,
    name: "Chao Frozen 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_4"
    }
  },
  FLOOR_FLOOR_FROZEN_5: {
    id: 589,
    name: "Chao Frozen 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_5"
    }
  },
  FLOOR_FLOOR_FROZEN_6: {
    id: 590,
    name: "Chao Frozen 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_6"
    }
  },
  FLOOR_FLOOR_FROZEN_7: {
    id: 591,
    name: "Chao Frozen 7",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_7"
    }
  },
  FLOOR_FLOOR_FROZEN_8: {
    id: 592,
    name: "Chao Frozen 8",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_8"
    }
  },
  FLOOR_FLOOR_FROZEN_9: {
    id: 593,
    name: "Chao Frozen 9",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_frozen_9"
    }
  },
  FLOOR_FLOOR_GRASS0_DIRT_MIX_1: {
    id: 594,
    name: "Chao Grass0-Dirt-Mix 1",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass0-dirt-mix_1"
    }
  },
  FLOOR_FLOOR_GRASS0_DIRT_MIX_2: {
    id: 595,
    name: "Chao Grass0-Dirt-Mix 2",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass0-dirt-mix_2"
    }
  },
  FLOOR_FLOOR_GRASS0_DIRT_MIX_3: {
    id: 596,
    name: "Chao Grass0-Dirt-Mix 3",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass0-dirt-mix_3"
    }
  },
  FLOOR_FLOOR_GRASS_0: {
    id: 597,
    name: "Chao Grass 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_0"
    }
  },
  FLOOR_FLOOR_GRASS_1: {
    id: 598,
    name: "Chao Grass 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_1"
    }
  },
  FLOOR_FLOOR_GRASS_2: {
    id: 599,
    name: "Chao Grass 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_2"
    }
  },
  FLOOR_FLOOR_GRASS_EAST: {
    id: 600,
    name: "Chao Grass East",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_east"
    }
  },
  FLOOR_FLOOR_GRASS_FLOWERS_BLUE_1: {
    id: 601,
    name: "Chao Grass Flowers Blue 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_flowers_blue_1"
    }
  },
  FLOOR_FLOOR_GRASS_FLOWERS_BLUE_2: {
    id: 602,
    name: "Chao Grass Flowers Blue 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_flowers_blue_2"
    }
  },
  FLOOR_FLOOR_GRASS_FLOWERS_BLUE_3: {
    id: 603,
    name: "Chao Grass Flowers Blue 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_flowers_blue_3"
    }
  },
  FLOOR_FLOOR_GRASS_FLOWERS_RED_1: {
    id: 604,
    name: "Chao Grass Flowers Red 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_flowers_red_1"
    }
  },
  FLOOR_FLOOR_GRASS_FLOWERS_RED_2: {
    id: 605,
    name: "Chao Grass Flowers Red 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_flowers_red_2"
    }
  },
  FLOOR_FLOOR_GRASS_FLOWERS_RED_3: {
    id: 606,
    name: "Chao Grass Flowers Red 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_flowers_red_3"
    }
  },
  FLOOR_FLOOR_GRASS_FLOWERS_YELLOW_1: {
    id: 607,
    name: "Chao Grass Flowers Yellow 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_flowers_yellow_1"
    }
  },
  FLOOR_FLOOR_GRASS_FLOWERS_YELLOW_2: {
    id: 608,
    name: "Chao Grass Flowers Yellow 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_flowers_yellow_2"
    }
  },
  FLOOR_FLOOR_GRASS_FLOWERS_YELLOW_3: {
    id: 609,
    name: "Chao Grass Flowers Yellow 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_flowers_yellow_3"
    }
  },
  FLOOR_FLOOR_GRASS_FULL: {
    id: 610,
    name: "Chao Grass Full",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_full"
    }
  },
  FLOOR_FLOOR_GRASS_NORTH: {
    id: 611,
    name: "Chao Grass North",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_north"
    }
  },
  FLOOR_FLOOR_GRASS_NORTHEAST: {
    id: 612,
    name: "Chao Grass Northeast",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_northeast"
    }
  },
  FLOOR_FLOOR_GRASS_NORTHWEST: {
    id: 613,
    name: "Chao Grass Northwest",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_northwest"
    }
  },
  FLOOR_FLOOR_GRASS_SOUTH: {
    id: 614,
    name: "Chao Grass South",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_south"
    }
  },
  FLOOR_FLOOR_GRASS_SOUTHEAST: {
    id: 615,
    name: "Chao Grass Southeast",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_southeast"
    }
  },
  FLOOR_FLOOR_GRASS_SOUTHWEST: {
    id: 616,
    name: "Chao Grass Southwest",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_southwest"
    }
  },
  FLOOR_FLOOR_GRASS_WEST: {
    id: 617,
    name: "Chao Grass West",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grass_west"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_1: {
    id: 618,
    name: "Chao Green Bones 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_1"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_10: {
    id: 619,
    name: "Chao Green Bones 10",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_10"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_11: {
    id: 620,
    name: "Chao Green Bones 11",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_11"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_12: {
    id: 621,
    name: "Chao Green Bones 12",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_12"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_2: {
    id: 622,
    name: "Chao Green Bones 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_2"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_3: {
    id: 623,
    name: "Chao Green Bones 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_3"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_4: {
    id: 624,
    name: "Chao Green Bones 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_4"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_5: {
    id: 625,
    name: "Chao Green Bones 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_5"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_6: {
    id: 626,
    name: "Chao Green Bones 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_6"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_7: {
    id: 627,
    name: "Chao Green Bones 7",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_7"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_8: {
    id: 628,
    name: "Chao Green Bones 8",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_8"
    }
  },
  FLOOR_FLOOR_GREEN_BONES_9: {
    id: 629,
    name: "Chao Green Bones 9",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_green_bones_9"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_0: {
    id: 630,
    name: "Chao Grey Dirt 0",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_0"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_1: {
    id: 631,
    name: "Chao Grey Dirt 1",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_1"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_2: {
    id: 632,
    name: "Chao Grey Dirt 2",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_2"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_3: {
    id: 633,
    name: "Chao Grey Dirt 3",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_3"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_4: {
    id: 634,
    name: "Chao Grey Dirt 4",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_4"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_5: {
    id: 635,
    name: "Chao Grey Dirt 5",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_5"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_6: {
    id: 636,
    name: "Chao Grey Dirt 6",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_6"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_7: {
    id: 637,
    name: "Chao Grey Dirt 7",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_7"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_B_0: {
    id: 638,
    name: "Chao Grey Dirt B 0",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_b_0"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_B_1: {
    id: 639,
    name: "Chao Grey Dirt B 1",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_b_1"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_B_2: {
    id: 640,
    name: "Chao Grey Dirt B 2",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_b_2"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_B_3: {
    id: 641,
    name: "Chao Grey Dirt B 3",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_b_3"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_B_4: {
    id: 642,
    name: "Chao Grey Dirt B 4",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_b_4"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_B_5: {
    id: 643,
    name: "Chao Grey Dirt B 5",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_b_5"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_B_6: {
    id: 644,
    name: "Chao Grey Dirt B 6",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_b_6"
    }
  },
  FLOOR_FLOOR_GREY_DIRT_B_7: {
    id: 645,
    name: "Chao Grey Dirt B 7",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_grey_dirt_b_7"
    }
  },
  FLOOR_FLOOR_HIVE_0: {
    id: 646,
    name: "Chao Hive 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_hive_0"
    }
  },
  FLOOR_FLOOR_HIVE_1: {
    id: 647,
    name: "Chao Hive 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_hive_1"
    }
  },
  FLOOR_FLOOR_HIVE_2: {
    id: 648,
    name: "Chao Hive 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_hive_2"
    }
  },
  FLOOR_FLOOR_HIVE_3: {
    id: 649,
    name: "Chao Hive 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_hive_3"
    }
  },
  FLOOR_FLOOR_ICE_0: {
    id: 650,
    name: "Chao Ice 0",
    solid: true,
    maxHP: 35,
    breakDamage: 3,
    bulletSpeed: 0.28,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_ice_0"
    }
  },
  FLOOR_FLOOR_ICE_1: {
    id: 651,
    name: "Chao Ice 1",
    solid: true,
    maxHP: 35,
    breakDamage: 3,
    bulletSpeed: 0.28,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_ice_1"
    }
  },
  FLOOR_FLOOR_ICE_2: {
    id: 652,
    name: "Chao Ice 2",
    solid: true,
    maxHP: 35,
    breakDamage: 3,
    bulletSpeed: 0.28,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_ice_2"
    }
  },
  FLOOR_FLOOR_ICE_3: {
    id: 653,
    name: "Chao Ice 3",
    solid: true,
    maxHP: 35,
    breakDamage: 3,
    bulletSpeed: 0.28,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_ice_3"
    }
  },
  FLOOR_FLOOR_INFERNAL_1: {
    id: 654,
    name: "Chao Infernal 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_1"
    }
  },
  FLOOR_FLOOR_INFERNAL_10: {
    id: 655,
    name: "Chao Infernal 10",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_10"
    }
  },
  FLOOR_FLOOR_INFERNAL_11: {
    id: 656,
    name: "Chao Infernal 11",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_11"
    }
  },
  FLOOR_FLOOR_INFERNAL_12: {
    id: 657,
    name: "Chao Infernal 12",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_12"
    }
  },
  FLOOR_FLOOR_INFERNAL_13: {
    id: 658,
    name: "Chao Infernal 13",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_13"
    }
  },
  FLOOR_FLOOR_INFERNAL_14: {
    id: 659,
    name: "Chao Infernal 14",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_14"
    }
  },
  FLOOR_FLOOR_INFERNAL_15: {
    id: 660,
    name: "Chao Infernal 15",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_15"
    }
  },
  FLOOR_FLOOR_INFERNAL_2: {
    id: 661,
    name: "Chao Infernal 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_2"
    }
  },
  FLOOR_FLOOR_INFERNAL_3: {
    id: 662,
    name: "Chao Infernal 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_3"
    }
  },
  FLOOR_FLOOR_INFERNAL_4: {
    id: 663,
    name: "Chao Infernal 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_4"
    }
  },
  FLOOR_FLOOR_INFERNAL_5: {
    id: 664,
    name: "Chao Infernal 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_5"
    }
  },
  FLOOR_FLOOR_INFERNAL_6: {
    id: 665,
    name: "Chao Infernal 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_6"
    }
  },
  FLOOR_FLOOR_INFERNAL_7: {
    id: 666,
    name: "Chao Infernal 7",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_7"
    }
  },
  FLOOR_FLOOR_INFERNAL_8: {
    id: 667,
    name: "Chao Infernal 8",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_8"
    }
  },
  FLOOR_FLOOR_INFERNAL_9: {
    id: 668,
    name: "Chao Infernal 9",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_9"
    }
  },
  FLOOR_FLOOR_INFERNAL_BLANK: {
    id: 669,
    name: "Chao Infernal Blank",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_infernal_blank"
    }
  },
  FLOOR_FLOOR_LABYRINTH_0: {
    id: 670,
    name: "Chao Labyrinth 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_labyrinth_0"
    }
  },
  FLOOR_FLOOR_LABYRINTH_1: {
    id: 671,
    name: "Chao Labyrinth 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_labyrinth_1"
    }
  },
  FLOOR_FLOOR_LABYRINTH_2: {
    id: 672,
    name: "Chao Labyrinth 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_labyrinth_2"
    }
  },
  FLOOR_FLOOR_LABYRINTH_3: {
    id: 673,
    name: "Chao Labyrinth 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_labyrinth_3"
    }
  },
  FLOOR_FLOOR_LAIR0B: {
    id: 674,
    name: "Chao Lair0B",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair0b"
    }
  },
  FLOOR_FLOOR_LAIR1B: {
    id: 675,
    name: "Chao Lair1B",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair1b"
    }
  },
  FLOOR_FLOOR_LAIR2B: {
    id: 676,
    name: "Chao Lair2B",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair2b"
    }
  },
  FLOOR_FLOOR_LAIR3B: {
    id: 677,
    name: "Chao Lair3B",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair3b"
    }
  },
  FLOOR_FLOOR_LAIR4B: {
    id: 678,
    name: "Chao Lair4B",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair4b"
    }
  },
  FLOOR_FLOOR_LAIR5B: {
    id: 679,
    name: "Chao Lair5B",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair5b"
    }
  },
  FLOOR_FLOOR_LAIR6B: {
    id: 680,
    name: "Chao Lair6B",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair6b"
    }
  },
  FLOOR_FLOOR_LAIR7B: {
    id: 681,
    name: "Chao Lair7B",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair7b"
    }
  },
  FLOOR_FLOOR_LAIR_0: {
    id: 682,
    name: "Chao Lair 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair_0"
    }
  },
  FLOOR_FLOOR_LAIR_1: {
    id: 683,
    name: "Chao Lair 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair_1"
    }
  },
  FLOOR_FLOOR_LAIR_2: {
    id: 684,
    name: "Chao Lair 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair_2"
    }
  },
  FLOOR_FLOOR_LAIR_3: {
    id: 685,
    name: "Chao Lair 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair_3"
    }
  },
  FLOOR_FLOOR_LAIR_4: {
    id: 686,
    name: "Chao Lair 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair_4"
    }
  },
  FLOOR_FLOOR_LAIR_5: {
    id: 687,
    name: "Chao Lair 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair_5"
    }
  },
  FLOOR_FLOOR_LAIR_6: {
    id: 688,
    name: "Chao Lair 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair_6"
    }
  },
  FLOOR_FLOOR_LAIR_7: {
    id: 689,
    name: "Chao Lair 7",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lair_7"
    }
  },
  FLOOR_FLOOR_LAVA_0: {
    id: 690,
    name: "Chao Lava 0",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lava_0"
    }
  },
  FLOOR_FLOOR_LAVA_1: {
    id: 691,
    name: "Chao Lava 1",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lava_1"
    }
  },
  FLOOR_FLOOR_LAVA_2: {
    id: 692,
    name: "Chao Lava 2",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lava_2"
    }
  },
  FLOOR_FLOOR_LAVA_3: {
    id: 693,
    name: "Chao Lava 3",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lava_3"
    }
  },
  FLOOR_FLOOR_LAVA: {
    id: 694,
    name: "Chao Lava",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_lava"
    }
  },
  FLOOR_FLOOR_LIMESTONE_0: {
    id: 695,
    name: "Chao Limestone 0",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_limestone_0"
    }
  },
  FLOOR_FLOOR_LIMESTONE_1: {
    id: 696,
    name: "Chao Limestone 1",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_limestone_1"
    }
  },
  FLOOR_FLOOR_LIMESTONE_2: {
    id: 697,
    name: "Chao Limestone 2",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_limestone_2"
    }
  },
  FLOOR_FLOOR_LIMESTONE_3: {
    id: 698,
    name: "Chao Limestone 3",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_limestone_3"
    }
  },
  FLOOR_FLOOR_LIMESTONE_4: {
    id: 699,
    name: "Chao Limestone 4",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_limestone_4"
    }
  },
  FLOOR_FLOOR_LIMESTONE_5: {
    id: 700,
    name: "Chao Limestone 5",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_limestone_5"
    }
  },
  FLOOR_FLOOR_LIMESTONE_6: {
    id: 701,
    name: "Chao Limestone 6",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_limestone_6"
    }
  },
  FLOOR_FLOOR_LIMESTONE_7: {
    id: 702,
    name: "Chao Limestone 7",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_limestone_7"
    }
  },
  FLOOR_FLOOR_LIMESTONE_8: {
    id: 703,
    name: "Chao Limestone 8",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_limestone_8"
    }
  },
  FLOOR_FLOOR_LIMESTONE_9: {
    id: 704,
    name: "Chao Limestone 9",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_limestone_9"
    }
  },
  FLOOR_FLOOR_MARBLE_FLOOR_1: {
    id: 705,
    name: "Chao Marble Floor 1",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_marble_floor_1"
    }
  },
  FLOOR_FLOOR_MARBLE_FLOOR_2: {
    id: 706,
    name: "Chao Marble Floor 2",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_marble_floor_2"
    }
  },
  FLOOR_FLOOR_MARBLE_FLOOR_3: {
    id: 707,
    name: "Chao Marble Floor 3",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_marble_floor_3"
    }
  },
  FLOOR_FLOOR_MARBLE_FLOOR_4: {
    id: 708,
    name: "Chao Marble Floor 4",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_marble_floor_4"
    }
  },
  FLOOR_FLOOR_MARBLE_FLOOR_5: {
    id: 709,
    name: "Chao Marble Floor 5",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_marble_floor_5"
    }
  },
  FLOOR_FLOOR_MARBLE_FLOOR_6: {
    id: 710,
    name: "Chao Marble Floor 6",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_marble_floor_6"
    }
  },
  FLOOR_FLOOR_MESH_0: {
    id: 711,
    name: "Chao Mesh 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mesh_0"
    }
  },
  FLOOR_FLOOR_MESH_1: {
    id: 712,
    name: "Chao Mesh 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mesh_1"
    }
  },
  FLOOR_FLOOR_MESH_2: {
    id: 713,
    name: "Chao Mesh 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mesh_2"
    }
  },
  FLOOR_FLOOR_MESH_3: {
    id: 714,
    name: "Chao Mesh 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mesh_3"
    }
  },
  FLOOR_FLOOR_MOSAIC_0: {
    id: 715,
    name: "Chao Mosaic 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_0"
    }
  },
  FLOOR_FLOOR_MOSAIC_1: {
    id: 716,
    name: "Chao Mosaic 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_1"
    }
  },
  FLOOR_FLOOR_MOSAIC_10: {
    id: 717,
    name: "Chao Mosaic 10",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_10"
    }
  },
  FLOOR_FLOOR_MOSAIC_11: {
    id: 718,
    name: "Chao Mosaic 11",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_11"
    }
  },
  FLOOR_FLOOR_MOSAIC_12: {
    id: 719,
    name: "Chao Mosaic 12",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_12"
    }
  },
  FLOOR_FLOOR_MOSAIC_13: {
    id: 720,
    name: "Chao Mosaic 13",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_13"
    }
  },
  FLOOR_FLOOR_MOSAIC_14: {
    id: 721,
    name: "Chao Mosaic 14",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_14"
    }
  },
  FLOOR_FLOOR_MOSAIC_15: {
    id: 722,
    name: "Chao Mosaic 15",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_15"
    }
  },
  FLOOR_FLOOR_MOSAIC_2: {
    id: 723,
    name: "Chao Mosaic 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_2"
    }
  },
  FLOOR_FLOOR_MOSAIC_3: {
    id: 724,
    name: "Chao Mosaic 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_3"
    }
  },
  FLOOR_FLOOR_MOSAIC_4: {
    id: 725,
    name: "Chao Mosaic 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_4"
    }
  },
  FLOOR_FLOOR_MOSAIC_5: {
    id: 726,
    name: "Chao Mosaic 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_5"
    }
  },
  FLOOR_FLOOR_MOSAIC_6: {
    id: 727,
    name: "Chao Mosaic 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_6"
    }
  },
  FLOOR_FLOOR_MOSAIC_7: {
    id: 728,
    name: "Chao Mosaic 7",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_7"
    }
  },
  FLOOR_FLOOR_MOSAIC_8: {
    id: 729,
    name: "Chao Mosaic 8",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_8"
    }
  },
  FLOOR_FLOOR_MOSAIC_9: {
    id: 730,
    name: "Chao Mosaic 9",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mosaic_9"
    }
  },
  FLOOR_FLOOR_MOSS_0: {
    id: 731,
    name: "Chao Moss 0",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_moss_0"
    }
  },
  FLOOR_FLOOR_MOSS_1: {
    id: 732,
    name: "Chao Moss 1",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_moss_1"
    }
  },
  FLOOR_FLOOR_MOSS_2: {
    id: 733,
    name: "Chao Moss 2",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_moss_2"
    }
  },
  FLOOR_FLOOR_MOSS_3: {
    id: 734,
    name: "Chao Moss 3",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_moss_3"
    }
  },
  FLOOR_FLOOR_MUD_0: {
    id: 735,
    name: "Chao Mud 0",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mud_0"
    }
  },
  FLOOR_FLOOR_MUD_1: {
    id: 736,
    name: "Chao Mud 1",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mud_1"
    }
  },
  FLOOR_FLOOR_MUD_2: {
    id: 737,
    name: "Chao Mud 2",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mud_2"
    }
  },
  FLOOR_FLOOR_MUD_3: {
    id: 738,
    name: "Chao Mud 3",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_mud_3"
    }
  },
  FLOOR_FLOOR_ORC_0: {
    id: 739,
    name: "Chao Orc 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_orc_0"
    }
  },
  FLOOR_FLOOR_ORC_1: {
    id: 740,
    name: "Chao Orc 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_orc_1"
    }
  },
  FLOOR_FLOOR_ORC_2: {
    id: 741,
    name: "Chao Orc 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_orc_2"
    }
  },
  FLOOR_FLOOR_ORC_3: {
    id: 742,
    name: "Chao Orc 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_orc_3"
    }
  },
  FLOOR_FLOOR_ORC_4: {
    id: 743,
    name: "Chao Orc 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_orc_4"
    }
  },
  FLOOR_FLOOR_ORC_5: {
    id: 744,
    name: "Chao Orc 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_orc_5"
    }
  },
  FLOOR_FLOOR_ORC_6: {
    id: 745,
    name: "Chao Orc 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_orc_6"
    }
  },
  FLOOR_FLOOR_ORC_7: {
    id: 746,
    name: "Chao Orc 7",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_orc_7"
    }
  },
  FLOOR_FLOOR_PEBBLE_BROWN_0: {
    id: 747,
    name: "Chao Pebble Brown 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_pebble_brown_0"
    }
  },
  FLOOR_FLOOR_PEBBLE_BROWN_1: {
    id: 748,
    name: "Chao Pebble Brown 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_pebble_brown_1"
    }
  },
  FLOOR_FLOOR_PEBBLE_BROWN_2: {
    id: 749,
    name: "Chao Pebble Brown 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_pebble_brown_2"
    }
  },
  FLOOR_FLOOR_PEBBLE_BROWN_3: {
    id: 750,
    name: "Chao Pebble Brown 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_pebble_brown_3"
    }
  },
  FLOOR_FLOOR_PEBBLE_BROWN_4: {
    id: 751,
    name: "Chao Pebble Brown 4",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_pebble_brown_4"
    }
  },
  FLOOR_FLOOR_PEBBLE_BROWN_5: {
    id: 752,
    name: "Chao Pebble Brown 5",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_pebble_brown_5"
    }
  },
  FLOOR_FLOOR_PEBBLE_BROWN_6: {
    id: 753,
    name: "Chao Pebble Brown 6",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_pebble_brown_6"
    }
  },
  FLOOR_FLOOR_PEDESTAL_FULL: {
    id: 757,
    name: "Chao Pedestal Full",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_pedestal_full"
    }
  },
  FLOOR_FLOOR_RECT_GRAY_0: {
    id: 765,
    name: "Chao Rect Gray 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_rect_gray_0"
    }
  },
  FLOOR_FLOOR_RECT_GRAY_1: {
    id: 766,
    name: "Chao Rect Gray 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_rect_gray_1"
    }
  },
  FLOOR_FLOOR_RECT_GRAY_2: {
    id: 767,
    name: "Chao Rect Gray 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_rect_gray_2"
    }
  },
  FLOOR_FLOOR_RECT_GRAY_3: {
    id: 768,
    name: "Chao Rect Gray 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_rect_gray_3"
    }
  },
  FLOOR_FLOOR_ROUGH_RED_0: {
    id: 769,
    name: "Chao Rough Red 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_rough_red_0"
    }
  },
  FLOOR_FLOOR_ROUGH_RED_1: {
    id: 770,
    name: "Chao Rough Red 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_rough_red_1"
    }
  },
  FLOOR_FLOOR_ROUGH_RED_2: {
    id: 771,
    name: "Chao Rough Red 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_rough_red_2"
    }
  },
  FLOOR_FLOOR_ROUGH_RED_3: {
    id: 772,
    name: "Chao Rough Red 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_rough_red_3"
    }
  },
  FLOOR_FLOOR_SAND_1: {
    id: 773,
    name: "Chao Sand 1",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sand_1"
    }
  },
  FLOOR_FLOOR_SAND_2: {
    id: 774,
    name: "Chao Sand 2",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sand_2"
    }
  },
  FLOOR_FLOOR_SAND_3: {
    id: 775,
    name: "Chao Sand 3",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sand_3"
    }
  },
  FLOOR_FLOOR_SAND_4: {
    id: 776,
    name: "Chao Sand 4",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sand_4"
    }
  },
  FLOOR_FLOOR_SAND_5: {
    id: 777,
    name: "Chao Sand 5",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sand_5"
    }
  },
  FLOOR_FLOOR_SAND_6: {
    id: 778,
    name: "Chao Sand 6",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sand_6"
    }
  },
  FLOOR_FLOOR_SAND_7: {
    id: 779,
    name: "Chao Sand 7",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sand_7"
    }
  },
  FLOOR_FLOOR_SAND_8: {
    id: 780,
    name: "Chao Sand 8",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sand_8"
    }
  },
  FLOOR_FLOOR_SIGIL_ALGIZ_LEFT: {
    id: 791,
    name: "Chao Sigil Algiz Left",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_algiz_left"
    }
  },
  FLOOR_FLOOR_SIGIL_ALGIZ_RIGHT: {
    id: 792,
    name: "Chao Sigil Algiz Right",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_algiz_right"
    }
  },
  FLOOR_FLOOR_SIGIL_CIRCLE: {
    id: 793,
    name: "Chao Sigil Circle",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_circle"
    }
  },
  FLOOR_FLOOR_SIGIL_CROSS: {
    id: 794,
    name: "Chao Sigil Cross",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_cross"
    }
  },
  FLOOR_FLOOR_SIGIL_CURVE_NORTH_EAST: {
    id: 795,
    name: "Chao Sigil Curve North East",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_curve_north_east"
    }
  },
  FLOOR_FLOOR_SIGIL_CURVE_NORTH_WEST: {
    id: 796,
    name: "Chao Sigil Curve North West",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_curve_north_west"
    }
  },
  FLOOR_FLOOR_SIGIL_CURVE_SOUTH_EAST: {
    id: 797,
    name: "Chao Sigil Curve South East",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_curve_south_east"
    }
  },
  FLOOR_FLOOR_SIGIL_CURVE_SOUTH_WEST: {
    id: 798,
    name: "Chao Sigil Curve South West",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_curve_south_west"
    }
  },
  FLOOR_FLOOR_SIGIL_RHOMBUS: {
    id: 799,
    name: "Chao Sigil Rhombus",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_rhombus"
    }
  },
  FLOOR_FLOOR_SIGIL_SHARP_EAST_NORTHEAST: {
    id: 800,
    name: "Chao Sigil Sharp East Northeast",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_sharp_east_northeast"
    }
  },
  FLOOR_FLOOR_SIGIL_SHARP_WEST_SOUTHWEST: {
    id: 801,
    name: "Chao Sigil Sharp West Southwest",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_sharp_west_southwest"
    }
  },
  FLOOR_FLOOR_SIGIL_STRAIGHT_EAST_NORTHEAST_SOUTHWEST: {
    id: 802,
    name: "Chao Sigil Straight East Northeast Southwest",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_straight_east_northeast_southwest"
    }
  },
  FLOOR_FLOOR_SIGIL_STRAIGHT_EAST_WEST: {
    id: 803,
    name: "Chao Sigil Straight East West",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_straight_east_west"
    }
  },
  FLOOR_FLOOR_SIGIL_STRAIGHT_EAST_WEST_NORTHEAST_NORTHWEST: {
    id: 804,
    name: "Chao Sigil Straight East West Northeast Northwest",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_straight_east_west_northeast_northwest"
    }
  },
  FLOOR_FLOOR_SIGIL_STRAIGHT_NORTH_SOUTH: {
    id: 805,
    name: "Chao Sigil Straight North South",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_straight_north_south"
    }
  },
  FLOOR_FLOOR_SIGIL_STRAIGHT_NORTHEAST_SOUTHWEST: {
    id: 806,
    name: "Chao Sigil Straight Northeast Southwest",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_straight_northeast_southwest"
    }
  },
  FLOOR_FLOOR_SIGIL_STRAIGHT_NORTHWEST_SOUTHEAST: {
    id: 807,
    name: "Chao Sigil Straight Northwest Southeast",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_straight_northwest_southeast"
    }
  },
  FLOOR_FLOOR_SIGIL_WIDE_EAST_NORTHWEST: {
    id: 808,
    name: "Chao Sigil Wide East Northwest",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_wide_east_northwest"
    }
  },
  FLOOR_FLOOR_SIGIL_WIDE_EAST_SOUTHWEST: {
    id: 809,
    name: "Chao Sigil Wide East Southwest",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_wide_east_southwest"
    }
  },
  FLOOR_FLOOR_SIGIL_WIDE_NORTH_SOUTHEAST: {
    id: 810,
    name: "Chao Sigil Wide North Southeast",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_wide_north_southeast"
    }
  },
  FLOOR_FLOOR_SIGIL_WIDE_NORTH_SOUTHWEST: {
    id: 811,
    name: "Chao Sigil Wide North Southwest",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_wide_north_southwest"
    }
  },
  FLOOR_FLOOR_SIGIL_WIDE_SOUTH_NORTHEAST: {
    id: 812,
    name: "Chao Sigil Wide South Northeast",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_wide_south_northeast"
    }
  },
  FLOOR_FLOOR_SIGIL_WIDE_SOUTH_NORTHWEST: {
    id: 813,
    name: "Chao Sigil Wide South Northwest",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_wide_south_northwest"
    }
  },
  FLOOR_FLOOR_SIGIL_WIDE_WEST_NORTHEAST: {
    id: 814,
    name: "Chao Sigil Wide West Northeast",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_wide_west_northeast"
    }
  },
  FLOOR_FLOOR_SIGIL_WIDE_WEST_SOUTHEAST: {
    id: 815,
    name: "Chao Sigil Wide West Southeast",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_wide_west_southeast"
    }
  },
  FLOOR_FLOOR_SIGIL_Y_EAST: {
    id: 816,
    name: "Chao Sigil Y East",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_y_east"
    }
  },
  FLOOR_FLOOR_SIGIL_Y_LEFT: {
    id: 817,
    name: "Chao Sigil Y Left",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_y_left"
    }
  },
  FLOOR_FLOOR_SIGIL_Y_NORTH: {
    id: 818,
    name: "Chao Sigil Y North",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_y_north"
    }
  },
  FLOOR_FLOOR_SIGIL_Y_RIGHT: {
    id: 819,
    name: "Chao Sigil Y Right",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_y_right"
    }
  },
  FLOOR_FLOOR_SIGIL_Y_SOUTH: {
    id: 820,
    name: "Chao Sigil Y South",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_y_south"
    }
  },
  FLOOR_FLOOR_SIGIL_Y_WEST: {
    id: 821,
    name: "Chao Sigil Y West",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_sigil_y_west"
    }
  },
  FLOOR_FLOOR_SNAKE_A_0: {
    id: 830,
    name: "Chao Snake-A 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-a_0"
    }
  },
  FLOOR_FLOOR_SNAKE_A_1: {
    id: 831,
    name: "Chao Snake-A 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-a_1"
    }
  },
  FLOOR_FLOOR_SNAKE_A_2: {
    id: 832,
    name: "Chao Snake-A 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-a_2"
    }
  },
  FLOOR_FLOOR_SNAKE_A_3: {
    id: 833,
    name: "Chao Snake-A 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-a_3"
    }
  },
  FLOOR_FLOOR_SNAKE_C_0: {
    id: 834,
    name: "Chao Snake-C 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-c_0"
    }
  },
  FLOOR_FLOOR_SNAKE_C_1: {
    id: 835,
    name: "Chao Snake-C 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-c_1"
    }
  },
  FLOOR_FLOOR_SNAKE_C_2: {
    id: 836,
    name: "Chao Snake-C 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-c_2"
    }
  },
  FLOOR_FLOOR_SNAKE_C_3: {
    id: 837,
    name: "Chao Snake-C 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-c_3"
    }
  },
  FLOOR_FLOOR_SNAKE_D_0: {
    id: 838,
    name: "Chao Snake-D 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-d_0"
    }
  },
  FLOOR_FLOOR_SNAKE_D_1: {
    id: 839,
    name: "Chao Snake-D 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-d_1"
    }
  },
  FLOOR_FLOOR_SNAKE_D_2: {
    id: 840,
    name: "Chao Snake-D 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-d_2"
    }
  },
  FLOOR_FLOOR_SNAKE_D_3: {
    id: 841,
    name: "Chao Snake-D 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake-d_3"
    }
  },
  FLOOR_FLOOR_SNAKE_0: {
    id: 842,
    name: "Chao Snake 0",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake_0"
    }
  },
  FLOOR_FLOOR_SNAKE_1: {
    id: 843,
    name: "Chao Snake 1",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake_1"
    }
  },
  FLOOR_FLOOR_SNAKE_2: {
    id: 844,
    name: "Chao Snake 2",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake_2"
    }
  },
  FLOOR_FLOOR_SNAKE_3: {
    id: 845,
    name: "Chao Snake 3",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_snake_3"
    }
  },
  FLOOR_FLOOR_SWAMP_0: {
    id: 846,
    name: "Chao Swamp 0",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_swamp_0"
    }
  },
  FLOOR_FLOOR_SWAMP_1: {
    id: 847,
    name: "Chao Swamp 1",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_swamp_1"
    }
  },
  FLOOR_FLOOR_SWAMP_2: {
    id: 848,
    name: "Chao Swamp 2",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_swamp_2"
    }
  },
  FLOOR_FLOOR_SWAMP_3: {
    id: 849,
    name: "Chao Swamp 3",
    solid: true,
    maxHP: 50,
    breakDamage: 4,
    bulletSpeed: 0.26,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_swamp_3"
    }
  },
  FLOOR_FLOOR_TOMB_0: {
    id: 850,
    name: "Chao Tomb 0",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_tomb_0"
    }
  },
  FLOOR_FLOOR_TOMB_1: {
    id: 851,
    name: "Chao Tomb 1",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_tomb_1"
    }
  },
  FLOOR_FLOOR_TOMB_2: {
    id: 852,
    name: "Chao Tomb 2",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_tomb_2"
    }
  },
  FLOOR_FLOOR_TOMB_3: {
    id: 853,
    name: "Chao Tomb 3",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_tomb_3"
    }
  },
  FLOOR_FLOOR_TUTORIAL_PAD: {
    id: 854,
    name: "Chao Tutorial Pad",
    solid: true,
    maxHP: 70,
    breakDamage: 6,
    bulletSpeed: 0.24,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_tutorial_pad"
    }
  },
  FLOOR_FLOOR_VOLCANIC_FLOOR_0: {
    id: 855,
    name: "Chao Volcanic Floor 0",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_volcanic_floor_0"
    }
  },
  FLOOR_FLOOR_VOLCANIC_FLOOR_1: {
    id: 856,
    name: "Chao Volcanic Floor 1",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_volcanic_floor_1"
    }
  },
  FLOOR_FLOOR_VOLCANIC_FLOOR_2: {
    id: 857,
    name: "Chao Volcanic Floor 2",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_volcanic_floor_2"
    }
  },
  FLOOR_FLOOR_VOLCANIC_FLOOR_3: {
    id: 858,
    name: "Chao Volcanic Floor 3",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_volcanic_floor_3"
    }
  },
  FLOOR_FLOOR_VOLCANIC_FLOOR_4: {
    id: 859,
    name: "Chao Volcanic Floor 4",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_volcanic_floor_4"
    }
  },
  FLOOR_FLOOR_VOLCANIC_FLOOR_5: {
    id: 860,
    name: "Chao Volcanic Floor 5",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_volcanic_floor_5"
    }
  },
  FLOOR_FLOOR_VOLCANIC_FLOOR_6: {
    id: 861,
    name: "Chao Volcanic Floor 6",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_volcanic_floor_6"
    }
  },
  FLOOR_FLOOR_WHITE_MARBLE_0: {
    id: 862,
    name: "Chao White Marble 0",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_white_marble_0"
    }
  },
  FLOOR_FLOOR_WHITE_MARBLE_1: {
    id: 863,
    name: "Chao White Marble 1",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_white_marble_1"
    }
  },
  FLOOR_FLOOR_WHITE_MARBLE_2: {
    id: 864,
    name: "Chao White Marble 2",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_white_marble_2"
    }
  },
  FLOOR_FLOOR_WHITE_MARBLE_3: {
    id: 865,
    name: "Chao White Marble 3",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_white_marble_3"
    }
  },
  FLOOR_FLOOR_WHITE_MARBLE_4: {
    id: 866,
    name: "Chao White Marble 4",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_white_marble_4"
    }
  },
  FLOOR_FLOOR_WHITE_MARBLE_5: {
    id: 867,
    name: "Chao White Marble 5",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_white_marble_5"
    }
  },
  FLOOR_FLOOR_WHITE_MARBLE_6: {
    id: 868,
    name: "Chao White Marble 6",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_white_marble_6"
    }
  },
  FLOOR_FLOOR_WHITE_MARBLE_7: {
    id: 869,
    name: "Chao White Marble 7",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_white_marble_7"
    }
  },
  FLOOR_FLOOR_WHITE_MARBLE_8: {
    id: 870,
    name: "Chao White Marble 8",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_white_marble_8"
    }
  },
  FLOOR_FLOOR_WHITE_MARBLE_9: {
    id: 871,
    name: "Chao White Marble 9",
    solid: true,
    maxHP: 90,
    breakDamage: 8,
    bulletSpeed: 0.22,
    bulletLifetime: 35,
    isFloor: true,
    opacity: 1,
    droppable: true,
    textures: {
      all: "floor_white_marble_9"
    }
  },
  DOOR_DOOR_FLESHY_ORIFICE_CLOSED: {
    id: 874,
    name: "Porta Fleshy Orifice Closed",
    solid: true,
    maxHP: 60,
    breakDamage: 8,
    bulletSpeed: 0.18,
    bulletLifetime: 16,
    isFloor: false,
    opacity: 1,
    droppable: false,
    textures: {
      all: "door_fleshy_orifice_closed"
    },
    onUse: function(world, block, creature) {
    const isOpening = block.userData.solid;
    const targetSolid = !isOpening;
    const visited = new Set();
    const queue = [{ x: block.userData.x, y: block.userData.y, z: block.userData.z }];
    while (queue.length > 0) {
        const current = queue.shift();
        const key = `${current.x},${current.y},${current.z}`;
        if (visited.has(key)) continue;
        visited.add(key);
        const targetBlock = world.blocks.find((b) =>
            Math.abs(b.x - current.x) < 0.01 &&
            Math.abs(b.y - current.y) < 0.01 &&
            Math.abs(b.z - current.z) < 0.01 &&
            b.type && b.type.onUse === DOOR_USE
        );
        if (!targetBlock) continue;
        targetBlock.solid = targetSolid;
        if (block.userData &&
            Math.abs(block.userData.x - current.x) < 0.01 &&
            Math.abs(block.userData.y - current.y) < 0.01 &&
            Math.abs(block.userData.z - current.z) < 0.01) {
            block.userData.solid = targetSolid;
        }
        if (targetBlock.mesh && Array.isArray(targetBlock.mesh.material)) {
            targetBlock.mesh.material.forEach(mat => {
                mat.opacity = targetSolid ? (targetBlock.type.opacity ?? 1) : 0.35;
                mat.transparent = mat.opacity < 1;
            });
        }
        const neighbors = [
            { x: current.x + 1, y: current.y, z: current.z },
            { x: current.x - 1, y: current.y, z: current.z },
            { x: current.x, y: current.y, z: current.z + 1 },
            { x: current.x, y: current.y, z: current.z - 1 },
            { x: current.x, y: current.y + 1, z: current.z },
            { x: current.x, y: current.y - 1, z: current.z }
        ];
        queue.push(...neighbors);
    }
    if (world && typeof world.markTerrainDirty === 'function') {
        world.markTerrainDirty();
    }
}
  },
  DOOR_DOOR_GATE_SEALED_LEFT: {
    id: 884,
    name: "Porta Gate Sealed Left",
    solid: true,
    maxHP: 60,
    breakDamage: 8,
    bulletSpeed: 0.18,
    bulletLifetime: 16,
    isFloor: false,
    opacity: 1,
    droppable: false,
    textures: {
      all: "door_gate_sealed_left"
    },
    onUse: function(world, block, creature) {
    const isOpening = block.userData.solid;
    const targetSolid = !isOpening;
    const visited = new Set();
    const queue = [{ x: block.userData.x, y: block.userData.y, z: block.userData.z }];
    while (queue.length > 0) {
        const current = queue.shift();
        const key = `${current.x},${current.y},${current.z}`;
        if (visited.has(key)) continue;
        visited.add(key);
        const targetBlock = world.blocks.find((b) =>
            Math.abs(b.x - current.x) < 0.01 &&
            Math.abs(b.y - current.y) < 0.01 &&
            Math.abs(b.z - current.z) < 0.01 &&
            b.type && b.type.onUse === DOOR_USE
        );
        if (!targetBlock) continue;
        targetBlock.solid = targetSolid;
        if (block.userData &&
            Math.abs(block.userData.x - current.x) < 0.01 &&
            Math.abs(block.userData.y - current.y) < 0.01 &&
            Math.abs(block.userData.z - current.z) < 0.01) {
            block.userData.solid = targetSolid;
        }
        if (targetBlock.mesh && Array.isArray(targetBlock.mesh.material)) {
            targetBlock.mesh.material.forEach(mat => {
                mat.opacity = targetSolid ? (targetBlock.type.opacity ?? 1) : 0.35;
                mat.transparent = mat.opacity < 1;
            });
        }
        const neighbors = [
            { x: current.x + 1, y: current.y, z: current.z },
            { x: current.x - 1, y: current.y, z: current.z },
            { x: current.x, y: current.y, z: current.z + 1 },
            { x: current.x, y: current.y, z: current.z - 1 },
            { x: current.x, y: current.y + 1, z: current.z },
            { x: current.x, y: current.y - 1, z: current.z }
        ];
        queue.push(...neighbors);
    }
    if (world && typeof world.markTerrainDirty === 'function') {
        world.markTerrainDirty();
    }
}
  },
  DOOR_DOOR_GATE_SEALED_MIDDLE: {
    id: 885,
    name: "Porta Gate Sealed Middle",
    solid: true,
    maxHP: 60,
    breakDamage: 8,
    bulletSpeed: 0.18,
    bulletLifetime: 16,
    isFloor: false,
    opacity: 1,
    droppable: false,
    textures: {
      all: "door_gate_sealed_middle"
    },
    onUse: function(world, block, creature) {
    const isOpening = block.userData.solid;
    const targetSolid = !isOpening;
    const visited = new Set();
    const queue = [{ x: block.userData.x, y: block.userData.y, z: block.userData.z }];
    while (queue.length > 0) {
        const current = queue.shift();
        const key = `${current.x},${current.y},${current.z}`;
        if (visited.has(key)) continue;
        visited.add(key);
        const targetBlock = world.blocks.find((b) =>
            Math.abs(b.x - current.x) < 0.01 &&
            Math.abs(b.y - current.y) < 0.01 &&
            Math.abs(b.z - current.z) < 0.01 &&
            b.type && b.type.onUse === DOOR_USE
        );
        if (!targetBlock) continue;
        targetBlock.solid = targetSolid;
        if (block.userData &&
            Math.abs(block.userData.x - current.x) < 0.01 &&
            Math.abs(block.userData.y - current.y) < 0.01 &&
            Math.abs(block.userData.z - current.z) < 0.01) {
            block.userData.solid = targetSolid;
        }
        if (targetBlock.mesh && Array.isArray(targetBlock.mesh.material)) {
            targetBlock.mesh.material.forEach(mat => {
                mat.opacity = targetSolid ? (targetBlock.type.opacity ?? 1) : 0.35;
                mat.transparent = mat.opacity < 1;
            });
        }
        const neighbors = [
            { x: current.x + 1, y: current.y, z: current.z },
            { x: current.x - 1, y: current.y, z: current.z },
            { x: current.x, y: current.y, z: current.z + 1 },
            { x: current.x, y: current.y, z: current.z - 1 },
            { x: current.x, y: current.y + 1, z: current.z },
            { x: current.x, y: current.y - 1, z: current.z }
        ];
        queue.push(...neighbors);
    }
    if (world && typeof world.markTerrainDirty === 'function') {
        world.markTerrainDirty();
    }
}
  },
  DOOR_DOOR_GATE_SEALED_RIGHT: {
    id: 886,
    name: "Porta Gate Sealed Right",
    solid: true,
    maxHP: 60,
    breakDamage: 8,
    bulletSpeed: 0.18,
    bulletLifetime: 16,
    isFloor: false,
    opacity: 1,
    droppable: false,
    textures: {
      all: "door_gate_sealed_right"
    },
    onUse: function(world, block, creature) {
    const isOpening = block.userData.solid;
    const targetSolid = !isOpening;
    const visited = new Set();
    const queue = [{ x: block.userData.x, y: block.userData.y, z: block.userData.z }];
    while (queue.length > 0) {
        const current = queue.shift();
        const key = `${current.x},${current.y},${current.z}`;
        if (visited.has(key)) continue;
        visited.add(key);
        const targetBlock = world.blocks.find((b) =>
            Math.abs(b.x - current.x) < 0.01 &&
            Math.abs(b.y - current.y) < 0.01 &&
            Math.abs(b.z - current.z) < 0.01 &&
            b.type && b.type.onUse === DOOR_USE
        );
        if (!targetBlock) continue;
        targetBlock.solid = targetSolid;
        if (block.userData &&
            Math.abs(block.userData.x - current.x) < 0.01 &&
            Math.abs(block.userData.y - current.y) < 0.01 &&
            Math.abs(block.userData.z - current.z) < 0.01) {
            block.userData.solid = targetSolid;
        }
        if (targetBlock.mesh && Array.isArray(targetBlock.mesh.material)) {
            targetBlock.mesh.material.forEach(mat => {
                mat.opacity = targetSolid ? (targetBlock.type.opacity ?? 1) : 0.35;
                mat.transparent = mat.opacity < 1;
            });
        }
        const neighbors = [
            { x: current.x + 1, y: current.y, z: current.z },
            { x: current.x - 1, y: current.y, z: current.z },
            { x: current.x, y: current.y, z: current.z + 1 },
            { x: current.x, y: current.y, z: current.z - 1 },
            { x: current.x, y: current.y + 1, z: current.z },
            { x: current.x, y: current.y - 1, z: current.z }
        ];
        queue.push(...neighbors);
    }
    if (world && typeof world.markTerrainDirty === 'function') {
        world.markTerrainDirty();
    }
}
  },
  DOOR_DOOR_SEALED_DOOR: {
    id: 889,
    name: "Porta Sealed Door",
    solid: true,
    maxHP: 60,
    breakDamage: 8,
    bulletSpeed: 0.18,
    bulletLifetime: 16,
    isFloor: false,
    opacity: 1,
    droppable: false,
    textures: {
      all: "door_sealed_door"
    },
    onUse: function(world, block, creature) {
    const isOpening = block.userData.solid;
    const targetSolid = !isOpening;
    const visited = new Set();
    const queue = [{ x: block.userData.x, y: block.userData.y, z: block.userData.z }];
    while (queue.length > 0) {
        const current = queue.shift();
        const key = `${current.x},${current.y},${current.z}`;
        if (visited.has(key)) continue;
        visited.add(key);
        const targetBlock = world.blocks.find((b) =>
            Math.abs(b.x - current.x) < 0.01 &&
            Math.abs(b.y - current.y) < 0.01 &&
            Math.abs(b.z - current.z) < 0.01 &&
            b.type && b.type.onUse === DOOR_USE
        );
        if (!targetBlock) continue;
        targetBlock.solid = targetSolid;
        if (block.userData &&
            Math.abs(block.userData.x - current.x) < 0.01 &&
            Math.abs(block.userData.y - current.y) < 0.01 &&
            Math.abs(block.userData.z - current.z) < 0.01) {
            block.userData.solid = targetSolid;
        }
        if (targetBlock.mesh && Array.isArray(targetBlock.mesh.material)) {
            targetBlock.mesh.material.forEach(mat => {
                mat.opacity = targetSolid ? (targetBlock.type.opacity ?? 1) : 0.35;
                mat.transparent = mat.opacity < 1;
            });
        }
        const neighbors = [
            { x: current.x + 1, y: current.y, z: current.z },
            { x: current.x - 1, y: current.y, z: current.z },
            { x: current.x, y: current.y, z: current.z + 1 },
            { x: current.x, y: current.y, z: current.z - 1 },
            { x: current.x, y: current.y + 1, z: current.z },
            { x: current.x, y: current.y - 1, z: current.z }
        ];
        queue.push(...neighbors);
    }
    if (world && typeof world.markTerrainDirty === 'function') {
        world.markTerrainDirty();
    }
}
  },
  DOOR_DOOR_VGATE_SEALED_DOWN: {
    id: 899,
    name: "Porta Vgate Sealed Down",
    solid: true,
    maxHP: 60,
    breakDamage: 8,
    bulletSpeed: 0.18,
    bulletLifetime: 16,
    isFloor: false,
    opacity: 1,
    droppable: false,
    textures: {
      all: "door_vgate_sealed_down"
    },
    onUse: function(world, block, creature) {
    const isOpening = block.userData.solid;
    const targetSolid = !isOpening;
    const visited = new Set();
    const queue = [{ x: block.userData.x, y: block.userData.y, z: block.userData.z }];
    while (queue.length > 0) {
        const current = queue.shift();
        const key = `${current.x},${current.y},${current.z}`;
        if (visited.has(key)) continue;
        visited.add(key);
        const targetBlock = world.blocks.find((b) =>
            Math.abs(b.x - current.x) < 0.01 &&
            Math.abs(b.y - current.y) < 0.01 &&
            Math.abs(b.z - current.z) < 0.01 &&
            b.type && b.type.onUse === DOOR_USE
        );
        if (!targetBlock) continue;
        targetBlock.solid = targetSolid;
        if (block.userData &&
            Math.abs(block.userData.x - current.x) < 0.01 &&
            Math.abs(block.userData.y - current.y) < 0.01 &&
            Math.abs(block.userData.z - current.z) < 0.01) {
            block.userData.solid = targetSolid;
        }
        if (targetBlock.mesh && Array.isArray(targetBlock.mesh.material)) {
            targetBlock.mesh.material.forEach(mat => {
                mat.opacity = targetSolid ? (targetBlock.type.opacity ?? 1) : 0.35;
                mat.transparent = mat.opacity < 1;
            });
        }
        const neighbors = [
            { x: current.x + 1, y: current.y, z: current.z },
            { x: current.x - 1, y: current.y, z: current.z },
            { x: current.x, y: current.y, z: current.z + 1 },
            { x: current.x, y: current.y, z: current.z - 1 },
            { x: current.x, y: current.y + 1, z: current.z },
            { x: current.x, y: current.y - 1, z: current.z }
        ];
        queue.push(...neighbors);
    }
    if (world && typeof world.markTerrainDirty === 'function') {
        world.markTerrainDirty();
    }
}
  },
  DOOR_DOOR_VGATE_SEALED_MIDDLE: {
    id: 900,
    name: "Porta Vgate Sealed Middle",
    solid: true,
    maxHP: 60,
    breakDamage: 8,
    bulletSpeed: 0.18,
    bulletLifetime: 16,
    isFloor: false,
    opacity: 1,
    droppable: false,
    textures: {
      all: "door_vgate_sealed_middle"
    },
    onUse: function(world, block, creature) {
    const isOpening = block.userData.solid;
    const targetSolid = !isOpening;
    const visited = new Set();
    const queue = [{ x: block.userData.x, y: block.userData.y, z: block.userData.z }];
    while (queue.length > 0) {
        const current = queue.shift();
        const key = `${current.x},${current.y},${current.z}`;
        if (visited.has(key)) continue;
        visited.add(key);
        const targetBlock = world.blocks.find((b) =>
            Math.abs(b.x - current.x) < 0.01 &&
            Math.abs(b.y - current.y) < 0.01 &&
            Math.abs(b.z - current.z) < 0.01 &&
            b.type && b.type.onUse === DOOR_USE
        );
        if (!targetBlock) continue;
        targetBlock.solid = targetSolid;
        if (block.userData &&
            Math.abs(block.userData.x - current.x) < 0.01 &&
            Math.abs(block.userData.y - current.y) < 0.01 &&
            Math.abs(block.userData.z - current.z) < 0.01) {
            block.userData.solid = targetSolid;
        }
        if (targetBlock.mesh && Array.isArray(targetBlock.mesh.material)) {
            targetBlock.mesh.material.forEach(mat => {
                mat.opacity = targetSolid ? (targetBlock.type.opacity ?? 1) : 0.35;
                mat.transparent = mat.opacity < 1;
            });
        }
        const neighbors = [
            { x: current.x + 1, y: current.y, z: current.z },
            { x: current.x - 1, y: current.y, z: current.z },
            { x: current.x, y: current.y, z: current.z + 1 },
            { x: current.x, y: current.y, z: current.z - 1 },
            { x: current.x, y: current.y + 1, z: current.z },
            { x: current.x, y: current.y - 1, z: current.z }
        ];
        queue.push(...neighbors);
    }
    if (world && typeof world.markTerrainDirty === 'function') {
        world.markTerrainDirty();
    }
}
  },
  DOOR_DOOR_VGATE_SEALED_UP: {
    id: 901,
    name: "Porta Vgate Sealed Up",
    solid: true,
    maxHP: 60,
    breakDamage: 8,
    bulletSpeed: 0.18,
    bulletLifetime: 16,
    isFloor: false,
    opacity: 1,
    droppable: false,
    textures: {
      all: "door_vgate_sealed_up"
    },
    onUse: function(world, block, creature) {
    const isOpening = block.userData.solid;
    const targetSolid = !isOpening;
    const visited = new Set();
    const queue = [{ x: block.userData.x, y: block.userData.y, z: block.userData.z }];
    while (queue.length > 0) {
        const current = queue.shift();
        const key = `${current.x},${current.y},${current.z}`;
        if (visited.has(key)) continue;
        visited.add(key);
        const targetBlock = world.blocks.find((b) =>
            Math.abs(b.x - current.x) < 0.01 &&
            Math.abs(b.y - current.y) < 0.01 &&
            Math.abs(b.z - current.z) < 0.01 &&
            b.type && b.type.onUse === DOOR_USE
        );
        if (!targetBlock) continue;
        targetBlock.solid = targetSolid;
        if (block.userData &&
            Math.abs(block.userData.x - current.x) < 0.01 &&
            Math.abs(block.userData.y - current.y) < 0.01 &&
            Math.abs(block.userData.z - current.z) < 0.01) {
            block.userData.solid = targetSolid;
        }
        if (targetBlock.mesh && Array.isArray(targetBlock.mesh.material)) {
            targetBlock.mesh.material.forEach(mat => {
                mat.opacity = targetSolid ? (targetBlock.type.opacity ?? 1) : 0.35;
                mat.transparent = mat.opacity < 1;
            });
        }
        const neighbors = [
            { x: current.x + 1, y: current.y, z: current.z },
            { x: current.x - 1, y: current.y, z: current.z },
            { x: current.x, y: current.y, z: current.z + 1 },
            { x: current.x, y: current.y, z: current.z - 1 },
            { x: current.x, y: current.y + 1, z: current.z },
            { x: current.x, y: current.y - 1, z: current.z }
        ];
        queue.push(...neighbors);
    }
    if (world && typeof world.markTerrainDirty === 'function') {
        world.markTerrainDirty();
    }
}
  },
  PLANT_PLANT_BUSH_2: {
    id: 902,
    name: "Planta Bush 2",
    solid: false,
    maxHP: 12,
    breakDamage: 3,
    bulletSpeed: 0.28,
    bulletLifetime: 28,
    isFloor: false,
    opacity: 1,
    droppable: true,
    render: "cross",
    textures: {
      all: "plant_bush_2"
    }
  },
  PLANT_PLANT_BUSH_3: {
    id: 903,
    name: "Planta Bush 3",
    solid: false,
    maxHP: 12,
    breakDamage: 3,
    bulletSpeed: 0.28,
    bulletLifetime: 28,
    isFloor: false,
    opacity: 1,
    droppable: true,
    render: "cross",
    textures: {
      all: "plant_bush_3"
    }
  },
  PLANT_PLANT_BUSH_4: {
    id: 904,
    name: "Planta Bush 4",
    solid: false,
    maxHP: 12,
    breakDamage: 3,
    bulletSpeed: 0.28,
    bulletLifetime: 28,
    isFloor: false,
    opacity: 1,
    droppable: true,
    render: "cross",
    textures: {
      all: "plant_bush_4"
    }
  }
};
